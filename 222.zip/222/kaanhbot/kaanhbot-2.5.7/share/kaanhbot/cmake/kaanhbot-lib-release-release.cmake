#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "kaanhbot::release::kaanhbot_lib" for configuration "Release"
set_property(TARGET kaanhbot::release::kaanhbot_lib APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(kaanhbot::release::kaanhbot_lib PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/release/libkaanhbot_lib.so"
  IMPORTED_SONAME_RELEASE "libkaanhbot_lib.so"
  )

list(APPEND _IMPORT_CHECK_TARGETS kaanhbot::release::kaanhbot_lib )
list(APPEND _IMPORT_CHECK_FILES_FOR_kaanhbot::release::kaanhbot_lib "${_IMPORT_PREFIX}/lib/release/libkaanhbot_lib.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
