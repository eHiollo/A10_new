#ifndef KAANHBOT_ROBOT_ROBOT_HPP_
#define KAANHBOT_ROBOT_ROBOT_HPP_

#include <memory>

#include "kaanh/module/middle_module.hpp"
#include "kaanh/general/macro.hpp"
#include "kaanhbot_lib_export.h"

namespace kaanhbot::robot {

class KAANHBOT_API Robot : public kaanh::module::MiddleModule {
public:
    auto virtual init()->void override;

    auto virtual execute(const std::string &str, std::function<void(std::string)> send_ret) noexcept->std::pair<std::string, std::string> override;

    static auto instanceInCs()->Robot&;
private:
    struct Imp;
    std::unique_ptr<Imp> imp_;

public:
    Robot();
    virtual ~Robot();
    KAANH_DELETE_BIG_FOUR(Robot)

};

}   // namespace kaanhbot::robot

#endif  // KAANHBOT_ROBOT_ROBOT_HPP_
