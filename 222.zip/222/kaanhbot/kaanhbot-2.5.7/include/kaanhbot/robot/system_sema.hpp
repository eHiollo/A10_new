#ifndef KAANHBOT_ROBOT_SYSTEM_SEMA_HPP_
#define KAANHBOT_ROBOT_SYSTEM_SEMA_HPP_


#include "aris/core/reflection.hpp"
#include "kaanh/module/pgm_controller.hpp"
#include "kaanhbot/semaphore/semaphore.hpp"
#include "kaanh/log/log.hpp"



namespace kaanhbot::robot {

#ifndef SYSTEM_SEMA_MAX_SLAVE_NUM
#define SYSTEM_SEMA_MAX_SLAVE_NUM 50
#endif
    template <typename T>
    struct atomicid
    {
    std::atomic<T> _a{};

    atomicid()
    :_a(){}

    atomicid(const std::atomic<T> &a)
        :_a(a.load()){}

    atomicid(const atomicid &other)
        :_a(other._a.load()){}

    T load(){
        return _a.load();
    }
    T load()const{
        return _a.load();
    }
    void store(const T& a){
        _a.store(a);
    }

    atomicid &operator=(const atomicid &other)
    {
        _a.store(other._a.load());
    }
};

    enum class GroupType:int{
        kNull = 0,
        kIO=1,
        kModbusTcp=2 
    };
    enum class SemaDataType:int{
        kBoolean = 1,
        kInt8,
        kUint8,
        kInt16,
        kUint16,
        kInt32,
        kUint32,
        kInt64,
        kUint64,
        kFloat,
        kDouble,
        //kString,
    };
    NLOHMANN_JSON_SERIALIZE_ENUM(GroupType, {
        {GroupType::kIO, "IO"},
        {GroupType::kModbusTcp, "ModbusTcp"}
    })
    NLOHMANN_JSON_SERIALIZE_ENUM(SemaDataType, {
        {SemaDataType::kBoolean, "Bool"},
        {SemaDataType::kInt8, "Int8"},
        {SemaDataType::kUint8, "Int8"},
        {SemaDataType::kInt16, "Int16"},
        {SemaDataType::kUint16, "Int16"},
        {SemaDataType::kInt32, "Int32"},
        {SemaDataType::kUint32, "Int32"},
        {SemaDataType::kInt64, "Int64"},
        {SemaDataType::kUint64, "Int64"},
        {SemaDataType::kFloat, "Float"},
        {SemaDataType::kDouble, "Double"}
    })

class KAANHBOT_API SemaConfig{
public:
    SemaConfig();
    ~SemaConfig();
    SemaConfig(GroupType gtype,bool canchangebinded=false,int group_id=0,int channel_id=-1){
        grouptype_=gtype;
        canchangebinded_ = canchangebinded;
        group_id_.store(group_id);
        channel_id_.store(channel_id);
    }
    auto setGroupType(GroupType grouptype)->void{grouptype_ = grouptype;}
    auto setGroupTypeStr(const std::string & grouptype)->void{
        if(grouptype=="IO") grouptype_=GroupType::kIO;
        else if(grouptype=="Modbus") grouptype_=GroupType::kModbusTcp;
    }
    auto groupType()const->GroupType{return grouptype_;}
    auto groupTypeStr()const->std::string{
        if(grouptype_==GroupType::kIO) return "IO";
        else if(grouptype_==GroupType::kModbusTcp) return "Modbus";
        return "null";
    }

    //auto setDataType(SemaDataType datatype)->void{datatype_ = datatype;}
    // auto setDataTypeStr(const std::string & datatype)->void{
    //     datatype_ = SemaDataType::kBoolean;
    // }
    //auto dataType()const->SemaDataType{return datatype_;}
    // auto dataTypeStr()const->std::string{
    //     return "Bool";
    // }

    auto setGroupId(int groupid)->void{group_id_.store(groupid);}
    auto groupId()const->int{return group_id_.load();}

    auto setCanChangeBinded(bool canchangebinded)->void{canchangebinded_ = canchangebinded;}
    auto canChangeBinded()const->bool{return canchangebinded_;}

    auto binded()const->bool{return channel_id_.load() != -1;}

    auto setChannelId(int channel_id)->void{channel_id_.store(channel_id);}
    auto channelId()const->int{return channel_id_.load();}
private:
    GroupType grouptype_{GroupType::kIO};//组类型
    atomicid<int> group_id_{0};//组号，IO：groupid,Modbus:1-只写区,2-只读区,3-读写区,参考protocol的MtcpSlaveGroupType
    bool canchangebinded_{false};//能否改绑
    atomicid<int> channel_id_{-1};//通道号，-1代表未绑定
};
void to_json(nlohmann::json& j, const SemaConfig& cell);

//1.建立bool int float 型的输入信号 输出信号的基类
class KAANHBOT_API SystemBoolInputSema : public kaanhbot::semaphore::InputSema<bool> {
public:
    auto rtCollect()->void;
    auto groupId(GroupType gtype)const->int;
    auto setGroupId(GroupType gtype,int groupid)->void;
    auto channelId(GroupType gtype) const ->int;
    auto setChannelId(GroupType gtype,int channel_id)->void;
    auto binded(GroupType gtype)const->bool;
    auto setEffectType(GroupType etype)->void;
    auto effectType()->GroupType;
    auto setEffectTypeStr(const std::string& etype)->void;
    auto effectTypeStr()->std::string;
    auto canChangeBinded(GroupType gtype)const->bool;
    auto setCanChangeBinded(GroupType gtype,bool canchangebinded)->void;
    auto setSemaConfigVec(aris::core::PointerArray<SemaConfig>* semaconfigvec)->void;
    auto semaConfigVec()const->aris::core::PointerArray<SemaConfig>&;
private:
    GroupType effect_type;//生效类型
    std::unique_ptr<aris::core::PointerArray<SemaConfig>> semaconfigVec_{new aris::core::PointerArray<SemaConfig>};//
public:
    SystemBoolInputSema(const std::string &name="") : kaanhbot::semaphore::InputSema<bool>(name) {}
    virtual ~SystemBoolInputSema() = default;
};


class KAANHBOT_API SystemBoolOutputSema : public kaanhbot::semaphore::OutputSema<bool> {
public:
    auto rtExport()->void;
    auto groupId(GroupType gtype)const->int;
    auto setGroupId(GroupType gtype,int groupid)->void;
    auto channelId(GroupType gtype) const ->int;
    auto setChannelId(GroupType gtype,int channel_id)->void;
    auto binded(GroupType gtype)const->bool;
    auto canChangeBinded(GroupType gtype)const->bool;
    auto setCanChangeBinded(GroupType gtype,bool canchangebinded)->void;
    auto setSemaConfigVec(aris::core::PointerArray<SemaConfig>* semaconfigvec)->void;
    auto semaConfigVec()const->const aris::core::PointerArray<SemaConfig>&;
private:
    std::unique_ptr<aris::core::PointerArray<SemaConfig>> semaconfigVec_{new aris::core::PointerArray<SemaConfig>};//
public:
    SystemBoolOutputSema(const std::string &name="") : kaanhbot::semaphore::OutputSema<bool>(name) {}
    virtual ~SystemBoolOutputSema() = default;
};



class KAANHBOT_API SystemIntInputSema : public kaanhbot::semaphore::InputSema<int> {
public:
    auto rtCollect()->void override;
    auto groupId(GroupType gtype)const->int{
        for(auto & semaconfig:*semaconfigVec_){
            if(semaconfig.groupType() == gtype){
                return semaconfig.groupId();
            }
        }
        return -1;
    }
    auto setGroupId(GroupType gtype,int groupid)->void{
        for(auto & semaconfig:*semaconfigVec_){
            if(semaconfig.groupType() == gtype){
                semaconfig.setGroupId(groupid);
            }
        }
        //semaconfigVec_.push_back(SemaConfig(gtype,false,groupid,-1));
    }
    auto channelId(GroupType gtype) const ->int{
        for(auto & semaconfig:*semaconfigVec_){
            if(semaconfig.groupType() == gtype){
                return semaconfig.channelId();
            }
        }
        return -1;
    }
    auto setChannelId(GroupType gtype,int channel_id)->void{
        for(auto & semaconfig:*semaconfigVec_){
            if(semaconfig.groupType() == gtype){
                semaconfig.setChannelId(channel_id);
            }
        }
    }
    auto binded(GroupType gtype)const->bool{
        for(auto & semaconfig:*semaconfigVec_){
            if(semaconfig.groupType() == gtype){
                return semaconfig.binded();
            }
        }
        return false;
    }
    auto canChangeBinded(GroupType gtype)const->bool{
        for(auto & semaconfig:*semaconfigVec_){
            if(semaconfig.groupType() == gtype){
                return semaconfig.canChangeBinded();
            }
        }
        return false;
    }
    auto setCanChangeBinded(GroupType gtype,bool canchangebinded)->void{
        for(auto & semaconfig:*semaconfigVec_){
            if(semaconfig.groupType() == gtype){
                semaconfig.setCanChangeBinded(canchangebinded);
                return;
            }
        }
    }
    auto setSemaConfigVec(aris::core::PointerArray<SemaConfig>* semaconfigvec)->void{assert(semaconfigvec);semaconfigVec_.reset(semaconfigvec);}
    auto semaConfigVec()const->aris::core::PointerArray<SemaConfig>&{return *semaconfigVec_;}
    
    auto setEffectType(GroupType etype)->void{effect_type = etype;}
    auto effectType()->GroupType{return effect_type;}
    auto setEffectTypeStr(const std::string& etype)->void{
        if(etype == "Null"){
            effect_type = GroupType::kNull;
        }else if(etype == "IO"){
            effect_type = GroupType::kIO;
        }else if(etype == "ModbusTcp"){
            effect_type = GroupType::kModbusTcp;
        }
        effect_type = GroupType::kNull;
    }
    auto effectTypeStr()->std::string{
        if(effect_type == GroupType::kNull){
            return "Null";
        }else if(effect_type == GroupType::kIO){
            return "IO";
        }else if(effect_type == GroupType::kModbusTcp){
            return "ModbusTcp";
        }
        return "Null";
    }

private:
    GroupType effect_type;//生效类型
    std::unique_ptr<aris::core::PointerArray<SemaConfig>> semaconfigVec_{new aris::core::PointerArray<SemaConfig>};
public:
    SystemIntInputSema(const std::string &name="") : kaanhbot::semaphore::InputSema<int>(name) {}
    virtual ~SystemIntInputSema() = default;
};

class KAANHBOT_API SystemIntOutputSema : public kaanhbot::semaphore::OutputSema<int> {
public:
    auto rtExport()->void override;
    auto groupId(GroupType gtype)const->int{
        for(auto & semaconfig:*semaconfigVec_){
            if(semaconfig.groupType() == gtype){
                return semaconfig.groupId();
            }
        }
        return -1;
    }
    auto setGroupId(GroupType gtype,int groupid)->void{
        for(auto & semaconfig:*semaconfigVec_){
            if(semaconfig.groupType() == gtype){
                semaconfig.setGroupId(groupid);
            }
        }
        //semaconfigVec_.push_back(SemaConfig(gtype,false,groupid,-1));
    }
    auto channelId(GroupType gtype) const ->int{
        for(auto & semaconfig:*semaconfigVec_){
            if(semaconfig.groupType() == gtype){
                return semaconfig.channelId();
            }
        }
        return -1;
    }
    auto setChannelId(GroupType gtype,int channel_id)->void{
        for(auto & semaconfig:*semaconfigVec_){
            if(semaconfig.groupType() == gtype){
                semaconfig.setChannelId(channel_id);
            }
        }
    }
    auto binded(GroupType gtype)const->bool{
        for(auto & semaconfig:*semaconfigVec_){
            if(semaconfig.groupType() == gtype){
                return semaconfig.binded();
            }
        }
        return false;
    }
    auto canChangeBinded(GroupType gtype)const->bool{
        for(auto & semaconfig:*semaconfigVec_){
            if(semaconfig.groupType() == gtype){
                return semaconfig.canChangeBinded();
            }
        }
        return false;
    }
    auto setCanChangeBinded(GroupType gtype,bool canchangebinded)->void{
        for(auto & semaconfig:*semaconfigVec_){
            if(semaconfig.groupType() == gtype){
                semaconfig.setCanChangeBinded(canchangebinded);
                return;
            }
        }
    }
    auto setSemaConfigVec(aris::core::PointerArray<SemaConfig>* semaconfigvec)->void{assert(semaconfigvec);semaconfigVec_.reset(semaconfigvec);}
    auto semaConfigVec()const->aris::core::PointerArray<SemaConfig>&{return *semaconfigVec_;}

private:
    std::unique_ptr<aris::core::PointerArray<SemaConfig>> semaconfigVec_{new aris::core::PointerArray<SemaConfig>};
public:
    SystemIntOutputSema(const std::string &name="") : kaanhbot::semaphore::OutputSema<int>(name) {}
    virtual ~SystemIntOutputSema() = default;
};


class KAANHBOT_API SystemFloatInputSema : public kaanhbot::semaphore::InputSema<float> {
public:
    auto rtCollect()->void override;
    auto groupId(GroupType gtype)const->int{
        for(auto & semaconfig:*semaconfigVec_){
            if(semaconfig.groupType() == gtype){
                return semaconfig.groupId();
            }
        }
        return -1;
    }
    auto setGroupId(GroupType gtype,int groupid)->void{
        for(auto & semaconfig:*semaconfigVec_){
            if(semaconfig.groupType() == gtype){
                semaconfig.setGroupId(groupid);
            }
        }
        //semaconfigVec_.push_back(SemaConfig(gtype,false,groupid,-1));
    }
    auto channelId(GroupType gtype) const ->int{
        for(auto & semaconfig:*semaconfigVec_){
            if(semaconfig.groupType() == gtype){
                return semaconfig.channelId();
            }
        }
        return -1;
    }
    auto setChannelId(GroupType gtype,int channel_id)->void{
        for(auto & semaconfig:*semaconfigVec_){
            if(semaconfig.groupType() == gtype){
                semaconfig.setChannelId(channel_id);
            }
        }
    }
    auto binded(GroupType gtype)const->bool{
        for(auto & semaconfig:*semaconfigVec_){
            if(semaconfig.groupType() == gtype){
                return semaconfig.binded();
            }
        }
        return false;
    }
    auto canChangeBinded(GroupType gtype)const->bool{
        for(auto & semaconfig:*semaconfigVec_){
            if(semaconfig.groupType() == gtype){
                return semaconfig.canChangeBinded();
            }
        }
        return false;
    }
    auto setCanChangeBinded(GroupType gtype,bool canchangebinded)->void{
        for(auto & semaconfig:*semaconfigVec_){
            if(semaconfig.groupType() == gtype){
                semaconfig.setCanChangeBinded(canchangebinded);
                return;
            }
        }
    }
    auto setSemaConfigVec(aris::core::PointerArray<SemaConfig>* semaconfigvec)->void{assert(semaconfigvec);semaconfigVec_.reset(semaconfigvec);}
    auto semaConfigVec()const->aris::core::PointerArray<SemaConfig>&{return *semaconfigVec_;}
    
    auto setEffectType(GroupType etype)->void{effect_type = etype;}
    auto effectType()->GroupType{return effect_type;}
    auto setEffectTypeStr(const std::string& etype)->void{
        if(etype == "Null"){
            effect_type = GroupType::kNull;
        }else if(etype == "IO"){
            effect_type = GroupType::kIO;
        }else if(etype == "ModbusTcp"){
            effect_type = GroupType::kModbusTcp;
        }
        effect_type = GroupType::kNull;
    }
    auto effectTypeStr()->std::string{
        if(effect_type == GroupType::kNull){
            return "Null";
        }else if(effect_type == GroupType::kIO){
            return "IO";
        }else if(effect_type == GroupType::kModbusTcp){
            return "ModbusTcp";
        }
        return "Null";
    }

private:
    GroupType effect_type;//生效类型
    std::unique_ptr<aris::core::PointerArray<SemaConfig>> semaconfigVec_{new aris::core::PointerArray<SemaConfig>};
public:
    SystemFloatInputSema(const std::string &name="") : kaanhbot::semaphore::InputSema<float>(name) {}
    virtual ~SystemFloatInputSema() = default;
};

class KAANHBOT_API SystemFloatOutputSema : public kaanhbot::semaphore::OutputSema<float> {
public:
    auto rtExport()->void override;
    auto groupId(GroupType gtype)const->int{
        for(auto & semaconfig:*semaconfigVec_){
            if(semaconfig.groupType() == gtype){
                return semaconfig.groupId();
            }
        }
        return -1;
    }
    auto setGroupId(GroupType gtype,int groupid)->void{
        for(auto & semaconfig:*semaconfigVec_){
            if(semaconfig.groupType() == gtype){
                semaconfig.setGroupId(groupid);
            }
        }
        //semaconfigVec_.push_back(SemaConfig(gtype,false,groupid,-1));
    }
    auto channelId(GroupType gtype) const ->int{
        for(auto & semaconfig:*semaconfigVec_){
            if(semaconfig.groupType() == gtype){
                return semaconfig.channelId();
            }
        }
        return -1;
    }
    auto setChannelId(GroupType gtype,int channel_id)->void{
        for(auto & semaconfig:*semaconfigVec_){
            if(semaconfig.groupType() == gtype){
                semaconfig.setChannelId(channel_id);
            }
        }
    }
    auto binded(GroupType gtype)const->bool{
        for(auto & semaconfig:*semaconfigVec_){
            if(semaconfig.groupType() == gtype){
                return semaconfig.binded();
            }
        }
        return false;
    }
    auto canChangeBinded(GroupType gtype)const->bool{
        for(auto & semaconfig:*semaconfigVec_){
            if(semaconfig.groupType() == gtype){
                return semaconfig.canChangeBinded();
            }
        }
        return false;
    }
    auto setCanChangeBinded(GroupType gtype,bool canchangebinded)->void{
        for(auto & semaconfig:*semaconfigVec_){
            if(semaconfig.groupType() == gtype){
                semaconfig.setCanChangeBinded(canchangebinded);
                return;
            }
        }
    }
    auto setSemaConfigVec(aris::core::PointerArray<SemaConfig>* semaconfigvec)->void{assert(semaconfigvec);semaconfigVec_.reset(semaconfigvec);}
    auto semaConfigVec()const->aris::core::PointerArray<SemaConfig>&{return *semaconfigVec_;}

private:
    std::unique_ptr<aris::core::PointerArray<SemaConfig>> semaconfigVec_{new aris::core::PointerArray<SemaConfig>};

public:
    SystemFloatOutputSema(const std::string &name="") : kaanhbot::semaphore::OutputSema<float>(name) {};
    virtual ~SystemFloatOutputSema() = default;
};


// 2.建立bool型输入信号 int型输入信号

//！三位开关使能
class InputManulEnSema  : public SystemBoolInputSema {
public:
    auto rtExecuteAfterCollect()->void override;
public:
    InputManulEnSema(const std::string &name="") :SystemBoolInputSema(name) {}
    ~InputManulEnSema() = default;
private:
    int counter_ = 0;
    bool last_val = false;
};



//！示教器急停
class InputTeacherEMGSema  : public SystemBoolInputSema {
public:
    auto rtExecuteAfterCollect()->void override;
public:
    InputTeacherEMGSema(const std::string &name="") :SystemBoolInputSema(name) {}
    ~InputTeacherEMGSema() = default;
};

//！外部急停
class InputExternalEMGSema  : public SystemBoolInputSema {
public:
    auto rtExecuteAfterCollect()->void override;
public:
    InputExternalEMGSema(const std::string &name="") :SystemBoolInputSema(name) {}
    ~InputExternalEMGSema() = default;
};

//！光栅
class InputRasterSema  : public SystemBoolInputSema {
public:
    auto rtExecuteAfterCollect()->void override;
public:
    InputRasterSema(const std::string &name="") :SystemBoolInputSema(name) {}
    ~InputRasterSema() = default;
};

//！安全门
class InputGateSema  : public SystemBoolInputSema {
public:
    auto rtExecuteAfterCollect()->void override;
public:
    InputGateSema(const std::string &name="") :SystemBoolInputSema(name) {}
    ~InputGateSema() = default;
};






//!使能状态输出
class OutputENSema  : public SystemBoolOutputSema {
public:
    auto rtExecutebeforeExport()->void override;
private:
    std::atomic_bool last_load{false};
public:
    OutputENSema(const std::string &name="") : SystemBoolOutputSema(name) {}
    ~OutputENSema() = default;
};


//!驱动器STO输出
class OutputDriverEMGSema  : public SystemBoolOutputSema {
public:
    auto rtExecutebeforeExport()->void override;
private:
    std::atomic_bool last_load{false};
public:
    OutputDriverEMGSema(const std::string &name="") : SystemBoolOutputSema(name) {}
    ~OutputDriverEMGSema() = default;
};

//!示教器急停输出/门和光栅
class OutputTeacherRasterGateEMGSema  : public SystemBoolOutputSema {
public:
    auto rtExecutebeforeExport()->void override;
private:
    std::atomic_bool last_load{false};
public:
    OutputTeacherRasterGateEMGSema(const std::string &name="") : SystemBoolOutputSema(name) {}
    ~OutputTeacherRasterGateEMGSema() = default;
};

//!外部急停输出
class OutputExternalEMGSema  : public SystemBoolOutputSema {
public:
    auto rtExecutebeforeExport()->void override;
private:
    std::atomic_bool last_load{false};
public:
    OutputExternalEMGSema(const std::string &name="") : SystemBoolOutputSema(name) {}
    ~OutputExternalEMGSema() = default;
};

//！加载输出
class OutputLoadingSema  : public SystemBoolOutputSema {
public:
    auto rtExecutebeforeExport()->void override;
private:
    std::atomic_bool last_load{false};
public:
    OutputLoadingSema(const std::string &name="") : SystemBoolOutputSema(name) {}
    ~OutputLoadingSema() = default;
};

//！程序复位输出
class OutputProRestSema  : public SystemBoolOutputSema {
public:
    auto rtExecutebeforeExport()->void override;
private:
    std::atomic_bool last_load{false};
public:
    OutputProRestSema(const std::string &name="") : SystemBoolOutputSema(name) {}
    ~OutputProRestSema() = default;
};

//！程序运行输出
class OutputProRunningSema  : public SystemBoolOutputSema {
public:
    auto rtExecutebeforeExport()->void override;
private:
    std::atomic_bool last_load{false};
public:
    OutputProRunningSema(const std::string &name="") : SystemBoolOutputSema(name) {}
    ~OutputProRunningSema() = default;
};

//！心跳状态输出
class OutputControllerRunningSema  : public SystemBoolOutputSema {
public:
    auto rtExecutebeforeExport()->void override;
private:
    std::atomic_bool last_load{false};
public:
    OutputControllerRunningSema(const std::string &name="") : SystemBoolOutputSema(name) {}
    ~OutputControllerRunningSema() = default;
};


//!外部自动状态输出
class OutputAutoModeSema  : public SystemBoolOutputSema {
public:
    auto rtExecutebeforeExport()->void override;
private:
    std::atomic_bool last_load{false};
public:
    OutputAutoModeSema(const std::string &name="") : SystemBoolOutputSema(name) {}
    ~OutputAutoModeSema() = default;
};

//!报警状态输出
class OutputAlarmSema  : public SystemBoolOutputSema {
public:
    auto rtExecutebeforeExport()->void override;
private:
    std::atomic_bool last_load{false};
public:
    OutputAlarmSema(const std::string &name="") : SystemBoolOutputSema(name) {}
    ~OutputAlarmSema() = default;
};





//当前全局速度输出
class OutputGlobalSpeedSema  : public SystemIntOutputSema {
public:
    auto rtExecutebeforeExport()->void override;
private:
    std::atomic_bool last_load{false};
public:
    OutputGlobalSpeedSema(const std::string &name="") : SystemIntOutputSema(name) {}
    ~OutputGlobalSpeedSema() = default;
};



//！区域输入 继承自actualBoolInputSema 不能绑定modbus
class InputAreaSema : public SystemBoolInputSema{
public:
    auto rtExecuteAfterCollect()->void override;
    auto areaNum()->const int{return ATOMIC_LOAD(area_num_);}
    auto setAreaNum(int area_num)->void{ATOMIC_STORE(area_num_, area_num);}
    static auto resizeAreaStatus(int size)->void{area_status.resize(size,false);}

private:
    static std::vector<bool> area_status;
    std::atomic_int area_num_{0};
public:
    InputAreaSema(const std::string &name=""):SystemBoolInputSema(name){}
    ~InputAreaSema()=default;
};




//!区域输出sema的父类
class KAANHBOT_API OutputAreaBoolSema : public SystemBoolOutputSema {
public:
    auto rtExport()->void override;
    auto rtExecutebeforeExport()->void override;
    auto areaNum()->const int{return ATOMIC_LOAD(area_num_);}
    auto setAreaNum(int area_num)->void{ATOMIC_STORE(area_num_, area_num);}
private:
    std::atomic_int area_num_{0};
public:
    OutputAreaBoolSema(const std::string &name="") : SystemBoolOutputSema(name) {}
    virtual ~OutputAreaBoolSema() = default;
};

//坐标点位的输出 根据指定坐标系号获取，所以需要开放坐标系号的绑定，可以在程序中设置
class KAANHBOT_API OutPutPosFloatSema: public SystemFloatOutputSema{
public:
    auto rtExecutebeforeExport()->void override;
    auto setPoseDimension(int dimension)->void{ATOMIC_STORE(pose_dimension_,dimension);}
    auto getPoseDimension()const -> int{return ATOMIC_LOAD(pose_dimension_);}
private:
    std::atomic_int pose_dimension_{0};

};

//力传感器补偿值的输出 根据指定坐标系号获取，所以需要开放坐标系号的绑定，可以在程序中设置
class KAANHBOT_API OutputForceCompensatePosFloatSema: public SystemFloatOutputSema{
public:
    auto rtExecutebeforeExport()->void override;
    auto setPoseDimension(int dimension)->void{ATOMIC_STORE(pose_dimension_,dimension);}
    auto getPoseDimension()const -> int{return ATOMIC_LOAD(pose_dimension_);}

private:
    std::atomic_int pose_dimension_{0};

};

//规划器规划位置输出
class KAANHBOT_API OutputTrajectoryPosSema: public SystemFloatOutputSema{
public:
    auto rtExecutebeforeExport()->void override;
    auto setPoseDimension(int dimension)->void{ATOMIC_STORE(pose_dimension_,dimension);}
    auto getPoseDimension()const -> int{return ATOMIC_LOAD(pose_dimension_);}
private:
    std::atomic_int pose_dimension_{0};

};


//力传感器则需要指定工具工件号，工具工件号也可以在程序中设置（是否兼容外部工具/外部轴耦合工具)

class KAANHBOT_API OutPutForceDataFloatSema: public SystemFloatOutputSema{
public:
    auto rtExecutebeforeExport()->void override;
    auto setForceDataDimension(int force_data_dimension)->void{ATOMIC_STORE(force_data_dimension_,force_data_dimension);}
    auto getForceDataDimension()const -> int{return ATOMIC_LOAD(force_data_dimension_);}
    auto setFsID(int fs_id)->void{ATOMIC_STORE(fs_id_,fs_id);}
    auto getFsID()const -> int{return ATOMIC_LOAD(fs_id_);}
private:
    std::atomic_int force_data_dimension_{0};
    std::atomic_int fs_id_{0};
};

//SystemSema

class KAANHBOT_API SystemSema : public kaanh::module::MiddleModule {
public:
    auto init()->void override;

    auto  execute(const std::string &str, std::function<void(std::string)> send_ret) noexcept->std::pair<std::string, std::string> override;



    auto teacherEmgVal() const->bool { return ATOMIC_LOAD(teacher_emg_); }
    auto setTeacherEmgVal(bool teacher_emg)->void { ATOMIC_STORE(teacher_emg_, teacher_emg); }

    auto externalEmgVal() const->bool { return ATOMIC_LOAD(external_emg_); }
    auto setExternalEmgVal(bool external_emg)->void { ATOMIC_STORE(external_emg_, external_emg); }

    auto rasterVal() const->bool { return ATOMIC_LOAD(raster_); }
    auto setRasterVal(bool raster)->void { ATOMIC_STORE(raster_, raster); }

    auto gateVal() const->bool { return ATOMIC_LOAD(gate_); }
    auto setGateVal(bool gate)->void { ATOMIC_STORE(gate_, gate); }


    auto gEnable() const->bool { return ATOMIC_LOAD(g_enable_); }
    auto setgEnable(bool g_enable)->void { ATOMIC_STORE(g_enable_, g_enable); }

    auto gDisnable() const->bool { return ATOMIC_LOAD(g_disable_); }
    auto setgDisable(bool g_disable)->void { ATOMIC_STORE(g_disable_, g_disable); }

    auto gIsEnabled() const->bool { return ATOMIC_LOAD(g_is_enabled_); }
    auto setgIsEnabled(bool g_is_enabled)->void { ATOMIC_STORE(g_is_enabled_, g_is_enabled); }

    auto setHwEnableMode(int hw_enable_mode)->void { ATOMIC_STORE(hw_enable_mode_, hw_enable_mode); }

    auto en()->void;

    //程序
    auto programGateShield() const->bool { return ATOMIC_LOAD(gate_shield_); }
    auto setProgramGateShield(bool program_gate_shield)->void { ATOMIC_STORE(gate_shield_, program_gate_shield); }


    auto programRasterShield() const->bool { return ATOMIC_LOAD(raster_shield_); }
    auto setProgramRasterShield(bool program_raster_shield)->void { ATOMIC_STORE(raster_shield_, program_raster_shield); }



    //配置映射
    auto gateShield() const->bool { return ATOMIC_LOAD(gate_shield_); }
    auto setGateShield(bool gate_shield)->void { ATOMIC_STORE(gate_shield_, gate_shield); }



    auto rasterShield() const->bool { return ATOMIC_LOAD(raster_shield_); }
    auto setRasterShield(bool raster_shield)->void { ATOMIC_STORE(raster_shield_, raster_shield); }



    auto modbusDisconnectAlarmShield() const->bool { return ATOMIC_LOAD(modbus_disconnect_alarm_shield_); }
    auto setModbusDisconnectAlarmShield(bool modbus_disconnect_alarm_shield)->void { ATOMIC_STORE(modbus_disconnect_alarm_shield_, modbus_disconnect_alarm_shield); }


    auto startCheck() const->bool { return ATOMIC_LOAD(start_check_); }
    auto setStartCheck(bool start_check)->void { ATOMIC_STORE(start_check_, start_check); }

    static auto registerBreakControlRelease(const std::function<int(int&)> break_control_release)->void;

    static auto registerBreakControlRestore(const std::function<void()> break_control_restore)->void;

    auto getBreakControlRelease()const->const std::function<int(int&)>& {return  break_control_release_;}

    auto getBreakControlRestore()const->const std::function<void()>& {return  break_control_restore_;}


//    int pos_sema_tool_num_{0};
//    int pos_sema_wobj_num_{0};

//    //显示力传感器信号
//    int force_sensor_sema_tool_num_{0};
//    int force_sensor_sema_wobj_num_{0};
//    bool is_ref_tool_{false};



    auto  setPosSeamToolNum(int num)->void{pos_sema_tool_num_=num;}
    auto  getPosSeamToolNum()const->int{return pos_sema_tool_num_;}

    auto  setPosSeamWobjNum(int num)->void{force_sensor_sema_wobj_num_=num;}
    auto  getPosSeamWobjNum()const->int{return force_sensor_sema_wobj_num_;}


    auto  setFsSeamToolNum(int num)->void{force_sensor_sema_tool_num_=num;}
    auto  getFsSeamToolNum()const->int{return force_sensor_sema_tool_num_;}

    auto  setFsSeamWobjNum(int num)->void{force_sensor_sema_wobj_num_=num;}
    auto  getFsSeamWobjNum()const->int{return force_sensor_sema_wobj_num_;}

    auto  setIsRefTool(bool is_ref_tool)->void{is_ref_tool_=is_ref_tool;}
    auto  getIsRefTool()const->bool{return is_ref_tool_;}

    static auto instanceInCs()->SystemSema&;
    std::atomic_int64_t g_en_counter_{0};
    std::atomic_int64_t g_ds_counter_{0};
    std::atomic_bool hw_enable_now_{false};     //当前硬件使能信号
    std::atomic_bool hw_enable_last_{false};    //上次硬件使能信号状态

    std::atomic_bool g_enable_last_{false};     //上次执行使能

    std::atomic_int32_t hw_enable_mode_ {0};	//0:md;1:en;2:rc;3:default
    std::atomic_bool ex_enable_now_{false};    //当前外部使能信号
    std::atomic_bool ex_enable_last_{false};     //上次外部使能信号

    std::atomic_bool motion_is_virtual_{false};

    std::atomic_bool motion_virtual_on_{false};

    std::atomic_bool auto_on_{false};
    //手动指令使能变量
    std::atomic_bool manual_on_{false};
    std::atomic_bool manual_en_now_{false};
    std::atomic_bool manual_en_last_{false};

    // 软使能延时处理
    std::chrono::time_point<std::chrono::system_clock> last_en_time_;
    std::chrono::time_point<std::chrono::system_clock> last_ds_time_;



private:
    aris::control::EthercatMaster::SlaveLinkState slavestate[SYSTEM_SEMA_MAX_SLAVE_NUM];
    aris::control::EthercatMaster::SlaveLinkState oldslavestate[SYSTEM_SEMA_MAX_SLAVE_NUM];
    bool onlineErr{false};
    bool slaveErr{false};
    //配置里屏蔽门
    std::atomic_bool  gate_shield_{false};
    //在程序里面屏蔽门   如果程序卸载自动恢复
//    std::atomic_bool  program_gate_shield_{false};
    //屏蔽光栅
    std::atomic_bool  raster_shield_{false};
    //在程序里面屏蔽光栅 如果程序卸载自动恢复
//    std::atomic_bool  program_raster_shield_{false};

    //modbus连接断开报警
    std::atomic_bool  modbus_disconnect_alarm_shield_{false};

    std::atomic_bool teacher_emg_{false};
    std::atomic_bool external_emg_{false};
    std::atomic_bool raster_{false};
    std::atomic_bool gate_{false};

    std::atomic_bool g_enable_ {false};			// 执行使能


    std::atomic_bool g_disable_ {false};			// 执行去使能
    std::atomic_bool g_is_enabled_ {false};      //使能成功


    std::atomic_bool start_check_{false};


    static std::function<int(int &)> break_control_release_;
    int break_release_count_{-1};

    static std::function<void()> break_control_restore_;


    //显示点位信号的坐标系
    int pos_sema_tool_num_{0};
    int pos_sema_wobj_num_{0};

    //显示力传感器信号
    int force_sensor_sema_tool_num_{0};
    int force_sensor_sema_wobj_num_{0};
    bool is_ref_tool_{false};


    struct Imp;
    std::unique_ptr<Imp> imp_;
public:
    SystemSema();
    virtual ~SystemSema();
    KAANH_DELETE_BIG_FOUR(SystemSema)
};

}
#endif
