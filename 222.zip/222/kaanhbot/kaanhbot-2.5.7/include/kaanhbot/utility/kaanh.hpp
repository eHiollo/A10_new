﻿#ifndef KAANHBOT_UTILITY_KAANH_HPP_ 
#define KAANHBOT_UTILITY_KAANH_HPP_

#include <kaanh/general/general.hpp>
#include <kaanh/middleware/middleware.hpp>
#include <kaanh/program/program.hpp>
#include <kaanh/robot/robot.hpp>
#include <kaanh/module/pgm_controller.hpp>
#include <kaanh/algorithm/planfuns.hpp>
#include <kaanhbot/calibration/calibration.hpp>
#include <kaanhbot/config/kaanhconfig.hpp>
#include <kaanhbot/config/ethercat_io.hpp>
#include <kaanhbot/config/ethercat_motor2.hpp>
#include <kaanhbot/config/external_axis.hpp>
#include "kaanhbot/protocol/modbus_tcp_server.hpp"
#include "kaanhbot/motion/move_find.hpp"
#include "kaanh/package/force_module.hpp"
#include <kaanh/log/log.hpp>
#include <kaanh/middleware/shell.hpp>
#include <string_view>
#include <any>
#include <aris/dynamic/dynamic.hpp>
#include <aris/plan/plan.hpp>
#include "kaanhbot_lib_export.h"

using namespace aris::dynamic;
using namespace aris::plan;


namespace kaanhbot::general
{
	constexpr double PI = 3.141592653589793;
	struct SetActiveMotor { std::vector<int> active_motor; };
	struct SetInputMovement
	{
		std::vector<double> axis_begin_pos_vec;
		std::vector<double> axis_pos_vec;
		std::vector<double> axis_vel_vec;
		std::vector<double> axis_acc_vec;
		std::vector<double> axis_dec_vec;
		std::vector<double> axis_jerk_vec;
	};

KAANHBOT_API	auto set_active_motor(const std::map<std::string_view, std::string_view> &cmd_params, Plan &plan, SetActiveMotor &param)->void;


KAANHBOT_API auto update_state(aris::server::ControlServer &cs)->void;

	class KAANHBOT_API DeleteFile : public aris::core::CloneObject<DeleteFile, aris::plan::Plan>
	{
	public:
		auto virtual prepareNrt()->void override;
		virtual ~DeleteFile();
		explicit DeleteFile(const std::string &name = "DeleteFile_plan");
	};

	class KAANHBOT_API Clear : public aris::core::CloneObject<Clear, aris::plan::Plan>
	{
	public:
		auto virtual prepareNrt()->void override;

		virtual ~Clear() = default;
		explicit Clear(const std::string &name = "clear_plan");
		ARIS_DEFINE_BIG_FOUR(Clear);
	};

	class KAANHBOT_API Mode : public aris::core::CloneObject<Mode, aris::plan::Plan>
	{
	public:
		auto virtual prepareNrt()->void override;
		auto virtual executeRT()->int override;

		virtual ~Mode();
		explicit Mode(const std::string &name = "mode_plan");
		ARIS_DECLARE_BIG_FOUR(Mode);

	private:
		struct Imp;
		aris::core::ImpPtr<Imp> imp_;
	};

	class KAANHBOT_API CancelEStop : public aris::core::CloneObject<CancelEStop, aris::plan::Plan>
	{
	public:
		auto virtual prepareNrt()->void override;
		explicit CancelEStop(const std::string &name = "CancelEStop");
	};

	class KAANHBOT_API SaveHome : public aris::core::CloneObject<SaveHome, aris::plan::Plan>
	{
	public:
		auto virtual prepareNrt()->void override;
		explicit SaveHome(const std::string &name = "SaveHome_plan");
	};

    class FindHome : public aris::core::CloneObject<FindHome, aris::plan::Plan>
    {
    public:
        auto virtual prepareNrt()->void override;
        auto virtual executeRT()->int override;
        auto virtual collectNrt()->void override;
        virtual ~FindHome();
        explicit FindHome(const std::string &name = "FindHome");
        ARIS_DECLARE_BIG_FOUR(FindHome);

    private:
        struct Imp;
        aris::core::ImpPtr<Imp> imp_;
    };

	class KAANHBOT_API Reset :public aris::core::CloneObject<Reset,Plan>
	{
	public:
		auto virtual prepareNrt()->void override;
		auto virtual executeRT()->int override;
		auto virtual collectNrt()->void override;
		explicit Reset(const std::string &name = "Reset");
		Reset(const Reset& other);
		virtual ~Reset();
	private:
		struct Imp;
		aris::core::ImpPtr<Imp> imp_;
	};

    class KAANHBOT_API ManualStop :public aris::core::CloneObject<ManualStop, aris::plan::Plan>
    {
    public:
        auto virtual prepareNrt()->void override;

        virtual ~ManualStop();
        explicit ManualStop(const std::string &name = "ManualStop");
    };


	class KAANHBOT_API Recover : public aris::core::CloneObject<Recover, aris::plan::Plan>
	{
	public:
		auto virtual prepareNrt()->void override;
		auto virtual executeRT()->int override;
		auto virtual collectNrt()->void override;

		virtual ~Recover();
		explicit Recover(const std::string &name = "recover_plan");
		ARIS_DECLARE_BIG_FOUR(Recover);
	};

	class KAANHBOT_API Sleep : public aris::core::CloneObject<Sleep, aris::plan::Plan>
	{
	public:
		auto virtual prepareNrt()->void override;
		auto virtual executeRT()->int override;

		virtual ~Sleep();
		explicit Sleep(const std::string &name = "sleep");
		ARIS_DECLARE_BIG_FOUR(Sleep);

	private:
		struct Imp;
		aris::core::ImpPtr<Imp> imp_;
	};

	class KAANHBOT_API SetDH : public aris::core::CloneObject<SetDH, aris::plan::Plan>
	{
	public:
		auto virtual prepareNrt()->void override;
		explicit SetDH(const std::string &name = "SetDH_plan");
	};

	class KAANHBOT_API SaveXml : public aris::core::CloneObject<SaveXml, aris::plan::Plan>
	{
	public:
		auto virtual prepareNrt()->void override;
		explicit SaveXml(const std::string &name = "SaveXml_plan");
	};

	class KAANHBOT_API SetPdo : public aris::core::CloneObject<SetPdo, aris::plan::Plan>
	{
	public:
		auto virtual prepareNrt()->void override;
		auto virtual executeRT()->int override;
		auto virtual collectNrt()->void override;
		explicit SetPdo(const std::string &name = "SetPdo_plan");
	};

	class SetMultiPdo : public aris::core::CloneObject<SetMultiPdo, aris::plan::Plan>
	{
	public:
		auto virtual prepareNrt()->void override;
		auto virtual executeRT()->int override;
		auto virtual collectNrt()->void override;
		explicit SetMultiPdo(const std::string &name = "SetMultiPdo_plan");
	private:
		struct Imp;
		aris::core::ImpPtr<Imp> imp_; 
	};

	class KAANHBOT_API GetPdo : public aris::core::CloneObject<GetPdo, aris::plan::Plan>
	{
	public:
		auto virtual prepareNrt()->void override;
		auto virtual executeRT()->int override;
		auto virtual collectNrt()->void override;
		explicit GetPdo(const std::string &name = "GetPdo_plan");
	};


	class KAANHBOT_API ScanSlave : public aris::core::CloneObject<ScanSlave, aris::plan::Plan>
	{
	public:
		auto virtual prepareNrt()->void override;
		explicit ScanSlave(const std::string &name = "ScanSlave_plan");
	};

	class KAANHBOT_API GetXml :public aris::core::CloneObject<GetXml, aris::plan::Plan>
	{
	public:
		auto virtual prepareNrt()->void override;

		virtual ~GetXml();
		explicit GetXml(const std::string &name = "GetXml");
	};

    class KAANHBOT_API SetXml :public aris::core::CloneObject<SetXml, aris::plan::Plan>
    {
    public:
        auto virtual prepareNrt()->void override;

        virtual ~SetXml();
        explicit SetXml(const std::string &name = "SetXml");
    };

	class KAANHBOT_API Start :public aris::core::CloneObject<Start, aris::plan::Plan>
	{
	public:
		auto virtual prepareNrt()->void override;

		virtual ~Start();
		explicit Start(const std::string &name = "Start");
	};

	class KAANHBOT_API Stop :public aris::core::CloneObject<Stop, aris::plan::Plan>
	{
	public:
		auto virtual prepareNrt()->void override;

		virtual ~Stop();
		explicit Stop(const std::string &name = "Stop");
	};

	class KAANHBOT_API SetJogVel : public aris::core::CloneObject<SetJogVel, aris::plan::Plan>
	{
	public:
		auto virtual prepareNrt()->void override;
		explicit SetJogVel(const std::string &name = "SetJogVel");
	};

	class KAANHBOT_API SetPgmVel : public aris::core::CloneObject<SetPgmVel, aris::plan::Plan>
	{
	public:
		auto virtual prepareNrt()->void override;
		explicit SetPgmVel(const std::string &name = "SetPgmVel");
	};

	class KAANHBOT_API SetTool : public aris::core::CloneObject<SetTool, aris::plan::Plan>
	{
	public:
		auto virtual prepareNrt()->void override;
		explicit SetTool(const std::string &name = "SetTool_plan");
	};

	class KAANHBOT_API SetWobj : public aris::core::CloneObject<SetWobj, aris::plan::Plan>
	{
	public:
		auto virtual prepareNrt()->void override;
		explicit SetWobj(const std::string &name = "SetWobj_plan");
	};

    class KAANHBOT_API GetPe : public aris::core::CloneObject<GetPe, aris::plan::Plan>
    {
    public:
        auto virtual prepareNrt()->void override;
        explicit GetPe(const std::string &name = "GetPe");
    };

	class KAANHBOT_API SetJogCoordinate : public aris::core::CloneObject<SetJogCoordinate, aris::plan::Plan>
	{
	public:
		auto virtual prepareNrt()->void override;
		explicit SetJogCoordinate(const std::string &name = "SetJogCoordinate_plan");
	};

	class KAANHBOT_API SetJogRunMode : public aris::core::CloneObject<SetJogRunMode, aris::plan::Plan>
	{
	public:
		auto virtual prepareNrt()->void override;
		explicit SetJogRunMode(const std::string &name = "SetJogRunMode");
	};

	class KAANHBOT_API SetToolMode : public aris::core::CloneObject<SetToolMode, aris::plan::Plan>
	{
	public:
		auto virtual prepareNrt()->void override;
		explicit SetToolMode(const std::string &name = "SetToolMode");
	};

	class KAANHBOT_API SetRobotOpMode : public aris::core::CloneObject<SetRobotOpMode, aris::plan::Plan>
	{
	public:
		auto virtual prepareNrt()->void override;
		explicit SetRobotOpMode(const std::string &name = "SetRobotOpMode");
	};
}

#endif	// KAANHBOT_UTILITY_KAANH_HPP_
