#ifndef KAANHBOT_UTILITY_TOOL_API_HPP_
#define KAANHBOT_UTILITY_TOOL_API_HPP_

#include <cstddef>
#include "kaanhbot_lib_export.h"
namespace kaanhbot::utility {

KAANHBOT_API auto saveCs()->void;

KAANHBOT_API auto s_mm2m(double *v, std::size_t len)->void;

KAANHBOT_API auto s_m2mm(double *v, std::size_t len)->void;

KAANHBOT_API auto s_deg2rad(double *v, std::size_t len)->void;

KAANHBOT_API auto s_rad2deg(double *v, std::size_t len)->void;

}

#endif  // KAANHBOT_UTILITY_TOOL_API_HPP_
