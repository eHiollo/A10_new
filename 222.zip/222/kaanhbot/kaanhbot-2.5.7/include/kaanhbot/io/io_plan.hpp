#ifndef KAANHBOT_IO_IO_PLAN_
#define KAANHBOT_IO_IO_PLAN_

#include "aris/plan/plan.hpp"
#include "kaanh/program/pgm_calculator.hpp"
#include "kaanhbot/io/io_manager.hpp"
#include "kaanhbot_lib_export.h"
namespace kaanhbot::io {

class KAANHBOT_API Pulse : public aris::core::CloneObject<Pulse, aris::plan::Plan> {
public:
    auto prepareNrt()->void override;
    auto executeRT()->int override;
    auto collectNrt()->void override;

private:
    int id_{-1};
    bool val_{false};
    bool last_val_{false};
    int count_{1};
    bool is_normal_{false};

    OutputChannel<bool> *channel_{nullptr};

public:
    Pulse();
};



class KAANHBOT_API SetDOPlan : public aris::core::CloneObject<SetDOPlan, aris::plan::Plan> {
public:
    auto prepareNrt()->void override;
    auto executeRT()->int override;

private:
    int id_{-1};
    bool val_{false};

    OutputChannel<bool> *channel_{nullptr};

public:
    SetDOPlan();
};

class KAANHBOT_API SetDOsPlan : public aris::core::CloneObject<SetDOsPlan, aris::plan::Plan> {
public:
    auto prepareNrt()->void override;
    auto executeRT()->int override;

private:
    int start_id_{-1};
    int end_id_{-1};
    int32_t val_{false};

    OutputChannel<bool> *channel_{nullptr};

public:
    SetDOsPlan();
};


class KAANHBOT_API WaitDi : public aris::core::CloneObject<WaitDi, aris::plan::Plan> {
public:
    auto prepareNrt()->void override;
    auto executeRT()->int override;

private:
    int id_{-1};
    bool val_{false};
    int count_{-1};     // <0:一直等待 0:不等待 >0:等待对应周期数

    InputChannel<bool> *channel_{nullptr};

public:
    WaitDi();
};

class KAANHBOT_API ManualSetDo : public aris::core::CloneObject<ManualSetDo, aris::plan::Plan> {
public:
    auto prepareNrt()->void override;

public:
    ManualSetDo();
    ~ManualSetDo();
};

}   // namespace kaanhbot::io

#endif  // KAANHBOT_IO_IO_PLAN_
