#ifndef KAANHBOT_IO_IO_CHANNEL_HPP_
#define KAANHBOT_IO_IO_CHANNEL_HPP_

#include <atomic>

#include "kaanh/general/macro.hpp"
#include "kaanhbot_lib_export.h"

namespace kaanhbot::io {

template<class Val>
class KAANHBOT_API IoChannel {
public:
    virtual auto isInput() const->bool = 0;
    virtual auto isOutput() const->bool { return !isInput(); }

    virtual auto id() const->int { return id_; }
    virtual auto setId(int id)->void { id_ = id; }
    virtual auto description() const->const std::string& { return description_; }
    virtual auto setDescription(const std::string &description)->void { description_ = description; }
    virtual auto editable() const->bool { return ATOMIC_LOAD(editable_); }
    virtual auto setEditable(bool editable)->void { ATOMIC_STORE(editable_, editable); }

    virtual auto enforcable() const->bool { return ATOMIC_LOAD(enforcable_); }
    virtual auto setEnforcable(bool enforcable)->void { 
        ATOMIC_STORE(enforcable_, enforcable);
        if (!enforcable) unforce();
    }
    virtual auto enforce(const Val &val)->void { ATOMIC_STORE(is_enforced_, true); ATOMIC_STORE(enforced_val_, val); }
    virtual auto unforce()->void { ATOMIC_STORE(is_enforced_, false); ATOMIC_STORE(enforced_val_, Val()); }
    virtual auto isEnforced() const->bool { return ATOMIC_LOAD(is_enforced_); }
    virtual auto enforcedVal() const->Val { return ATOMIC_LOAD(enforced_val_); }

private:
    int id_{0};
    std::string description_;
    std::atomic_bool editable_{true};
    std::atomic_bool enforcable_{true};
    std::atomic_bool is_enforced_{false};
    std::atomic<Val> enforced_val_{Val()};

public:
    IoChannel(int id=0, const std::string &description="") : id_(id), description_(description) {}
    virtual ~IoChannel() = default;

    KAANH_DEFINE_BIG_FOUR(IoChannel)
};

template<class Val>
class KAANHBOT_API InputChannel : public IoChannel<Val> {
public:
    auto isInput() const->bool override { return true; }

    virtual auto getInputVal() const->Val = 0;
    virtual auto rtSetVal(bool val)->void = 0;

public:
    InputChannel(int id=0, const std::string &description="") : IoChannel<Val>(id, description) {}
    virtual ~InputChannel() = default;

    KAANH_DEFINE_BIG_FOUR(InputChannel)
};

template<class Val>
class KAANHBOT_API OutputChannel : public IoChannel<Val> {
public:
    auto isInput() const->bool override { return false; }

    virtual auto getOutputVal() const->Val = 0;
    virtual auto setOutputVal(const Val &val)->void = 0;

    virtual auto rtSetVal(bool val)->void = 0;
    virtual auto rtGetVal() const->bool = 0;

public:
    OutputChannel(int id=0, const std::string &description="") : IoChannel<Val>(id, description) {}
    virtual ~OutputChannel() = default;

    KAANH_DEFINE_BIG_FOUR(OutputChannel)
};

class KAANHBOT_API ActualDiChannel : public InputChannel<bool> {
public:
    auto getInputVal() const->bool override;

    auto rtSetVal(bool val)->void override;

private:
    std::atomic_bool val_{false};

public:
    ActualDiChannel(int id=0, const std::string &description="") : InputChannel<bool>(id, description) {}
    ~ActualDiChannel() = default;

    KAANH_DEFINE_BIG_FOUR(ActualDiChannel)
};

class KAANHBOT_API ActualDoChannel : public OutputChannel<bool> {
public:
    auto getOutputVal() const->bool override;
    auto setOutputVal(const bool &val)->void override;

    auto rtSetVal(bool val)->void override;
    auto rtGetVal() const->bool override;

private:
    std::atomic_bool ival_{false};
    std::atomic_bool oval_{false};

public:
    ActualDoChannel(int id=0, const std::string &description="") : OutputChannel<bool>(id, description) {}
    ~ActualDoChannel() = default;

    KAANH_DEFINE_BIG_FOUR(ActualDoChannel)
};

}   // namespace kaanhbot::io

#endif  // KAANHBOT_IO_IO_CHANNEL_HPP_
