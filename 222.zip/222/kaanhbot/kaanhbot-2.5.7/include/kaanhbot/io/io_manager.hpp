#ifndef KAANHBOT_IO_IO_MANAGER_
#define KAANHBOT_IO_IO_MANAGER_

#include <string>
#include <functional>
#include <memory>

#include "kaanh/module/middle_module.hpp"
#include "kaanhbot/io/io_group.hpp"

namespace kaanhbot::io {

struct DigitalIoChannelAttr {
    std::string description;
    bool editable;
    bool enforcable;
    bool enforced;
    NLOHMANN_DEFINE_TYPE_INTRUSIVE(DigitalIoChannelAttr, description, editable, enforcable, enforced)
};

struct DigitalIoGroupAttr {
    std::string name;
    std::vector<DigitalIoChannelAttr> di_attrs;
    std::vector<DigitalIoChannelAttr> do_attrs;
    NLOHMANN_DEFINE_TYPE_INTRUSIVE(DigitalIoGroupAttr, name, di_attrs, do_attrs)
};

class KAANHBOT_API IoManager : public kaanh::module::MiddleModule {
public:
    auto init()->void override;
    auto execute(const std::string &str, std::function<void(std::string)> send_ret) noexcept->std::pair<std::string, std::string> override;
    
    auto digitalIoGroupPool()->aris::core::PointerArray<IoGroup<bool>>&;
    auto digitalIoGroupPool() const->const aris::core::PointerArray<IoGroup<bool>>& { return  const_cast<std::decay_t<decltype(*this)> *>(this)->digitalIoGroupPool(); }
    auto resetDigitalIoGroupPool(aris::core::PointerArray<IoGroup<bool>> *pool)->void;

    auto analogIoGroupPool()->aris::core::PointerArray<IoGroup<int>>&;
    auto analogIoGroupPool() const->const aris::core::PointerArray<IoGroup<int>>& { return  const_cast<std::decay_t<decltype(*this)> *>(this)->analogIoGroupPool(); }
    auto resetAnalogIoGroupPool(aris::core::PointerArray<IoGroup<int>> *pool)->void;

    auto rtRead()->void;
    auto rtWrite()->void;

    static auto instanceInCs()->IoManager&;

private:
    struct Imp;
    std::unique_ptr<Imp> imp_;
    
public:
    IoManager();
    ~IoManager();

    KAANH_DELETE_BIG_FOUR(IoManager)
};

}   // namespace kaanhbot::io

#endif  // KAANHBOT_IO_IO_MANAGER_
