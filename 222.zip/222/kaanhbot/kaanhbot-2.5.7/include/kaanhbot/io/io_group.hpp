#ifndef KAANHBOT_IO_IO_GROUP_HPP_
#define KAANHBOT_IO_IO_GROUP_HPP_

#include <memory>
#include <cassert>

#include "aris/core/object.hpp"
#include "kaanh/general/macro.hpp"
#include "kaanh/module/middle_module.hpp"
#include "kaanhbot/io/io_channel.hpp"
#include "kaanhbot_lib_export.h"

namespace kaanhbot::io {

template<class Val>
class KAANHBOT_API IoGroup {
public:
    auto id() const noexcept->int { return id_; }
    auto setId(int id)->void { id_ = id; }
    auto name() const noexcept->const std::string& { return name_; }
    auto setName(const std::string &name)->void { name_ = name; }

    auto inputChannelPool()->aris::core::PointerArray<InputChannel<Val>>& { return *ichans_; }
    auto inputChannelPool() const->const aris::core::PointerArray<InputChannel<Val>>& { return const_cast<std::decay_t<decltype(*this)> *>(this)->inputChannelPool(); }
    auto resetInputChannelPool(aris::core::PointerArray<InputChannel<Val>> *pool)->void { assert(pool); ichans_.reset(pool); }

    auto outputChannelPool()->aris::core::PointerArray<OutputChannel<Val>>& { return *ochans_; }
    auto outputChannelPool() const->const aris::core::PointerArray<OutputChannel<Val>>& { return const_cast<std::decay_t<decltype(*this)> *>(this)->outputChannelPool(); }
    auto resetOutputChannelPool(aris::core::PointerArray<OutputChannel<Val>> *pool)->void { assert(pool); ochans_.reset(pool); }

    virtual auto rtRead()->void = 0;
    virtual auto rtWrite()->void = 0;

private:
    int id_{0};
    std::string name_;
    std::unique_ptr<aris::core::PointerArray<InputChannel<Val>>> ichans_;
    std::unique_ptr<aris::core::PointerArray<OutputChannel<Val>>> ochans_;

public:
    IoGroup(int id=0, const std::string &name="") : id_(id), name_(name) {}
    virtual ~IoGroup() = default;

    KAANH_DEFINE_BIG_FOUR(IoGroup)
};

class KAANHBOT_API ActualDigitalIoGroup : public IoGroup<bool> {
public:
    auto rtRead()->void override;
    auto rtWrite()->void override;

public:
    ActualDigitalIoGroup(int group_id=0, const std::string &group_name="") : IoGroup<bool>(group_id, group_name) {}
    ~ActualDigitalIoGroup() = default;

    KAANH_DEFINE_BIG_FOUR(ActualDigitalIoGroup)

};

}   // namespace kaanhbot::io

#endif  // KAANHBOT_IO_IO_GROUP_HPP_
