#ifndef KAANHBOT_PROTOCOL_MODBUS_RTU_POLL_HPP_
#define KAANHBOT_PROTOCOL_MODBUS_RTU_POLL_HPP_

#include <memory>
#include <vector>
#include <string>

#include "aris/control/controller_motion.hpp"
#include "kaanh/module/middle_module.hpp"
#include "kaanh/general/modbus-rtu.h"
#include "kaanh/general/macro.hpp"
#include "kaanh/general/json.hpp"
#include "kaanhbot_lib_export.h"

namespace kaanhbot::protocol {

    template <typename T>
    struct atomwrapper
    {
    std::atomic<T> _a;

    atomwrapper()
    :_a()
    {}

    atomwrapper(const std::atomic<T> &a)
        :_a(a.load())
    {}
    T load(){
        return _a.load();
    }
    void store(const T& a){
        _a.store(a);
    }
    atomwrapper(const atomwrapper &other)
        :_a(other._a.load())
    {}

    atomwrapper &operator=(const atomwrapper &other)
    {
        _a.store(other._a.load());
    }
};





// 控制器是客户端，没用到  是个例子
class KAANHBOT_API ModbusRtuPoll{
public:
    auto DeviceName() const noexcept->const std::string&;
    auto resetDeviceName(const std::string &ip) noexcept->void;
    auto SlaveID() const noexcept->int;\
    auto setSlaveID(int Slave_id)->void;
    auto rtuConnect()->bool;
    auto setBaud(int Baud)->void;
    auto setDatabit(int Data_bit)->void;
    auto setStopbit(int Stop_bit)->void;
    auto setParitybit(char Parity_bit)->void;
    auto setDebug(bool Flag)->void;
    auto isConnected()->bool;
    auto WriteOneRegister(uint16_t addr,uint16_t value)->bool;
    auto WriteRegisters(uint16_t addr,uint16_t nb,const uint16_t * data)->bool;
    auto ReadOneRegister(uint16_t addr,uint16_t * data)->bool;
    auto ReadRegisters(uint16_t addr,uint16_t nb,uint16_t * data)->bool;
private:
    struct Imp;
    std::unique_ptr<Imp> imp_;
public:
    ModbusRtuPoll(std::string Device_name,bool Flag,int Slave_id,int Baud,int Data_bit,int Stop_bit,char Parity_bit);
    ~ModbusRtuPoll();
};

class KAANHBOT_API InputRegister{
public:
    auto getName() const noexcept->const std::string&{return name_;}
    auto setName(const std::string& name)->void{name_ = name;}
    auto getAddr()const -> uint16_t{return addr_.load();}
    auto setAddr(const uint16_t& addr)->void{addr_.store(addr);}
    // 读多个寄存器
    auto getLength()const -> uint16_t{return length_.load();}
    auto setLength(const uint16_t& length)->void{length_.store(length);value_.resize(length);}
    // 读写不能连续   需间隔一定时间  单位：ms
    auto setCounts(const int & count)->void{count_ = count;}
    auto getCounts()const ->int{return count_;}
    auto setValue(int n,int value)->void{value_[n].store(value);}
    auto getValue(int n)->int{return value_[n].load();}
private:
    std::string name_{};
    int count_{};
    std::atomic<uint16_t> length_{};
    std::atomic<uint16_t> addr_{0x0000};
    std::vector<atomwrapper<int>> value_{};
public:
    InputRegister(const std::string& name=""):name_(name){};
    virtual ~InputRegister();
};
class KAANHBOT_API HoldRegister{
public:
    auto getName() const noexcept->const std::string&{return name_;}
    auto setName(const std::string& name)->void{name_ = name;}
    auto getAddr()const -> uint16_t{return addr_.load();}
    auto setAddr(const uint16_t& addr)->void{addr_.store(addr);}
    auto getLength()const -> uint16_t{return length_.load();}
    auto setLength(const uint16_t& length)->void{
        length_.store(length);
        wvalue_.resize(length);
        for(auto & data:wvalue_){
            data.store(0xffff);
        }
        rvalue_.resize(length);
        for(auto & data:rvalue_){
            data.store(0xffff);
        }
    }
    // 暂时没用到
    auto getVal()const -> uint16_t{return val_.load();}
    auto setVal(const uint16_t& val)->void{val_.store(val);}
    // 示教器会写   也会从主板去读  存在同时更新变量值的情况    此接口暂无没用到  修改波特率等参数使用
    auto getFlag()const -> uint16_t{return changeflag_.load();}
    auto setFlag(const uint16_t& changeflag)->void{changeflag_.store(changeflag);}
    auto setCounts(const int & count)->void{count_ = count;}
    auto getCounts()const ->int{return count_;}
    // 一个线程读  一个写  
    auto setValue(int n,int value)->void{rvalue_[n].store(value);}
    auto settValue(int n,int value)->void{wvalue_[n].store(value);}
    auto getValue(int n)->int{return rvalue_[n].load();}
    auto gettValue(int n)->int{return wvalue_[n].load();}
private:
    std::string name_{};
    std::atomic<uint16_t> length_{};
    std::atomic<uint16_t> addr_{0x0000};
    std::atomic<uint16_t> val_{0x0000};
    int count_{};
    std::vector<atomwrapper<int>> wvalue_{};//存要写的值
    std::vector<atomwrapper<int>> rvalue_{};//存读到的值
    std::atomic<bool> changeflag_{false};
public:
    HoldRegister(const std::string& name=""):name_(name){};
    virtual ~HoldRegister();
};


class KAANHBOT_API DIRegister:public InputRegister{
public:
    auto setDefaultVal(const uint16_t& dval)->void{dval_.store(dval);}
    auto getDefaultVal()->uint16_t{return dval_.load();}

private:
    std::atomic<uint16_t> dval_{};
public:
    DIRegister(const std::string& name=""):InputRegister(name){};
    ~DIRegister();
};

class KAANHBOT_API DORegister:public HoldRegister{
public:
    auto setDefaultVal(const uint16_t& dval)->void{dval_.store(dval);}
    auto getDefaultVal()->uint16_t{return dval_.load();}
private:
    std::atomic<uint16_t> dval_{};
public:
    DORegister(const std::string& name=""):HoldRegister(name){};
    ~DORegister();
};

// 配置对面主站信息  控制器是客户端
class KAANHBOT_API ModbusRtuSlave{
public:
    auto reconnect()->void;
    auto connectSlave()->void;
    auto isConnect()->bool;
    auto device_name() const noexcept->const std::string&{return device_name_;}
    auto resetDevice_name(const std::string &device_name) noexcept->void{device_name_ = device_name;}
    auto slave_id() const noexcept->const int&{return slave_id_;}
    auto resetSlave_id(const int &slave_id) noexcept->void{slave_id_ = slave_id;}
    auto baud() const noexcept->const int&{return baud_;}
    auto resetBaud(const int &baud) noexcept->void{baud_ = baud;}
    auto data_bit() const noexcept->const int&{return data_bit_;}
    auto resetData_bit(const int &data_bit) noexcept->void{data_bit_ = data_bit;}
    auto stop_bit() const noexcept->const int&{return stop_bit_;}
    auto resetStop_bit(const int &stop_bit) noexcept->void{stop_bit_ = stop_bit;}
    auto parity_bit() const noexcept->const std::string&{return parity_bit_;}
    auto resetParity_bit(const std::string &parity_bit) noexcept->void{parity_bit_ = parity_bit;}
    // 打印数据交互信息 调试用
    auto Debugmode() const noexcept->const bool&{return debugmode_;}
    auto resetDebugmode(const bool &debugmode) noexcept->void{debugmode_ = debugmode;}
    auto isVirtual() const noexcept->const bool&{return isvirtual;}
    auto setVirtual(const bool &isvirtual_) noexcept->void{isvirtual = isvirtual_;}
    auto getModbusctx()->modbus_t *{return ctx_;}


    auto getInputRegisterPool()->aris::core::PointerArray<InputRegister>&{return *inputPool_;}
    auto getInputRegisterPool()const->const aris::core::PointerArray<InputRegister>&{return const_cast<std::decay_t<decltype(*this)> *>(this)->getInputRegisterPool();}
    auto resetInputRegisterPool(aris::core::PointerArray<InputRegister>* inputPool) ->void{inputPool_.reset(inputPool);}
    auto getHoldRegisterPool()->aris::core::PointerArray<HoldRegister>&{return *holdPool_;}
    auto getHoldRegisterPool()const->const aris::core::PointerArray<HoldRegister>&{return const_cast<std::decay_t<decltype(*this)> *>(this)->getHoldRegisterPool();}
    auto resetHoldRegisterPool(aris::core::PointerArray<HoldRegister>* holdPool) ->void{holdPool_.reset(holdPool);}

private:
    std::string device_name_{};
    int slave_id_{};
    int baud_{};
    int data_bit_{};
    int stop_bit_{};
    std::string parity_bit_{};
    bool debugmode_{};
    bool isvirtual{};
    modbus_t *ctx_{nullptr};
    std::atomic_bool is_reconnecting_{false};
    std::thread th_reconnect_;
    std::unique_ptr<aris::core::PointerArray<InputRegister>>  inputPool_;
    std::unique_ptr<aris::core::PointerArray<HoldRegister>>  holdPool_;
public:
    ModbusRtuSlave();
    virtual ~ModbusRtuSlave();
};

class KAANHBOT_API RtuDigitalIo : public aris::control::DigitalIo{
public:
    auto slaveId() const-> int;
    auto setSlaveId(const int slave_id)->void;

    virtual ~RtuDigitalIo() = default;
    RtuDigitalIo(std::uint16_t num_of_di = 8, std::uint16_t num_of_do = 8);
    RtuDigitalIo(const RtuDigitalIo &other) = delete;
    RtuDigitalIo(RtuDigitalIo &&other) = delete;
    RtuDigitalIo& operator=(const RtuDigitalIo &other) = delete;
    RtuDigitalIo& operator=(RtuDigitalIo &&other) = delete;

private:
    int slave_id_;
};

class KAANHBOT_API MRTUDigitalIO : public RtuDigitalIo{
public:
    auto virtual init()->void;

    virtual auto getDi(const std::uint16_t index) const->bool;
    virtual auto getDo(const std::uint16_t index) const->bool;
    virtual auto setDo(const std::uint16_t index, const bool status)->void;

    virtual ~MRTUDigitalIO();
    explicit MRTUDigitalIO(std::uint16_t num_of_di = 8, std::uint16_t num_of_do = 8);
    MRTUDigitalIO(const MRTUDigitalIO &other)= delete;
    MRTUDigitalIO(MRTUDigitalIO &&other) = delete;
    MRTUDigitalIO& operator=(const MRTUDigitalIO &other)= delete;
    MRTUDigitalIO& operator=(MRTUDigitalIO &&other) = delete;

private:
    struct Imp;
    aris::core::ImpPtr<Imp> imp_;
};


class KAANHBOT_API ModbusRtuManager : public kaanh::module::MiddleModule {
public:
    auto virtual init()->void override;

    auto virtual execute(const std::string &str, std::function<void(std::string)> send_ret) noexcept->std::pair<std::string, std::string> override;

    // 使用从站id读写
    auto getDIvalue(const int slave_id,const std::uint16_t index)const->bool;
    auto getDOvalue(const int slave_id,const std::uint16_t index) const->bool;
    auto setDOvalue(const int slave_id,const std::uint16_t index, const bool status)->void;

    auto resetModbusRtuSlavePool(aris::core::PointerArray<ModbusRtuSlave> * mPool)->void;
    auto ModbusRtuSlavePool()->aris::core::PointerArray<ModbusRtuSlave>&;
    auto ModbusRtuSlavePool()const->const aris::core::PointerArray<ModbusRtuSlave>&;
    // 和示教器交互使用 跟新变量的值
    auto UpdateRegister(const uint16_t& slave_id, const uint16_t& addr,const uint16_t& value)->void;
    // 读写任务队列  主线程负责推任务，后台执行写到硬件操作
    auto WQueueSize()->size_t;
    auto WQueuePop(std::pair<int,std::pair<uint16_t,uint16_t>> & pair_)->bool;
    // 和示教器交互使用 读变量的值
    auto ReadRegister(const uint16_t& slave_id, const uint16_t& addr,const uint16_t& value)->void;
    auto RQueueSize()->size_t;
    auto RQueuePop(std::pair<int,std::pair<uint16_t,uint16_t>> & pair_)->bool;
    static auto instanceInCs()->ModbusRtuManager&;
public:

private:
    struct Imp;
    std::unique_ptr<Imp> imp_;

public:
    ModbusRtuManager();
    ~ModbusRtuManager();
    KAANH_DELETE_BIG_FOUR(ModbusRtuManager)
};


class KAANHBOT_API MrtuLed : public kaanh::module::MiddleModule{
public:
    auto virtual init()->void override;

    auto virtual execute(const std::string &str, std::function<void(std::string)> send_ret) noexcept->std::pair<std::string, std::string> override;

    static auto instanceInCs()->ModbusRtuManager&;

public:
    auto Device_name() const noexcept->const std::string&;
    auto resetDevice_name(const std::string &Device_name_) noexcept->void;
    auto Slave_id() const noexcept->const int&;
    auto resetSlave_id(const int &Slave_id_) noexcept->void;
    auto Baud() const noexcept->const int&;
    auto resetBaud(const int &Baud_) noexcept->void;
    auto Data_bit() const noexcept->const int&;
    auto resetData_bit(const int &Data_bit_) noexcept->void;
    auto Stop_bit() const noexcept->const int&;
    auto resetStop_bit(const int &Stop_bit_) noexcept->void;
    auto Parity_bit() const noexcept->const std::string&;
    auto resetParity_bit(const std::string &Parity_bit_) noexcept->void;
    auto Debugmode() const noexcept->const bool&;
    auto resetDebugmode(const bool &Debugmode_) noexcept->void;
    // 
    auto WriteDecNum(uint16_t value)->bool;
    
    auto setLuminace(uint16_t value)->bool;
    
    auto setDecPoint(uint16_t point)->bool;
    
    auto setFlicker(uint16_t point)->bool;
    
    auto setFloat(std::string float_str)->bool;
    
    auto setString(char sixchar[6])->bool;



private:
    struct Imp;
    std::unique_ptr<Imp> imp_;
public:
    MrtuLed();
    ~MrtuLed();
    KAANH_DELETE_BIG_FOUR(MrtuLed);
};

}

#endif //KAANHBOT_PROTOCOL_MODBUS_RTU_POLL_HPP_
