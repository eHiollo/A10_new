#ifndef KAANHBOT_PROTOCOL_MODBUS_TCP_SERVER_HPP_
#define KAANHBOT_PROTOCOL_MODBUS_TCP_SERVER_HPP_

#include <memory>
#include <vector>
#include <string>

#include "aris/plan/plan.hpp"
#include "kaanh/module/middle_module.hpp"
#include "kaanh/general/macro.hpp"
#include "kaanh/general/json.hpp"
#include "kaanhbot_lib_export.h"


namespace kaanhbot::protocol {

enum class MtcpSlaveNodeType : int {
    kBool = 1,
    kInt16,
    kFloat
};

NLOHMANN_JSON_SERIALIZE_ENUM(MtcpSlaveNodeType, {
    {MtcpSlaveNodeType::kBool, "Bool"},
    {MtcpSlaveNodeType::kInt16, "Int16"},
    {MtcpSlaveNodeType::kFloat, "Float"}
})

struct MtcpSlaveNode {
    std::string description;
    bool editable{true};
    bool changable{true};
    std::string address;

    NLOHMANN_DEFINE_TYPE_INTRUSIVE(MtcpSlaveNode, description, editable, changable, address)
};

enum class MtcpSlaveGroupType : int {
    kWriteOnly = 1,
    kReadOnly,
    kWriteRead
};

NLOHMANN_JSON_SERIALIZE_ENUM(MtcpSlaveGroupType, {
    {MtcpSlaveGroupType::kWriteOnly, "WriteOnly"},
    {MtcpSlaveGroupType::kReadOnly, "ReadOnly"},
    {MtcpSlaveGroupType::kWriteRead, "WriteRead"}
})

struct MtcpSlaveGroup {
    std::vector<MtcpSlaveNode> bnodes;
    std::vector<MtcpSlaveNode> inodes;
    std::vector<MtcpSlaveNode> fnodes;

    NLOHMANN_DEFINE_TYPE_INTRUSIVE(MtcpSlaveGroup, bnodes, inodes, fnodes)
};

class KAANHBOT_API ModbusTcpServer : public kaanh::module::MiddleModule {
public:
    auto virtual init()->void override;

    auto virtual execute(const std::string &str, std::function<void(std::string)> send_ret) noexcept->std::pair<std::string, std::string> override;

public:
    auto ip() const noexcept->const std::string&;
    auto resetIp(const std::string &ip) noexcept->void;
    auto port() const noexcept->int;
    auto resetPort(int port) noexcept->void;

    // 属性配置
    auto roGroup() const->const MtcpSlaveGroup&;
    auto resetRoGroup(const MtcpSlaveGroup &group)->void;
    auto woGroup() const->const MtcpSlaveGroup&;
    auto resetWoGroup(const MtcpSlaveGroup &group)->void;
    auto wrGroup() const->const MtcpSlaveGroup&;
    auto resetWrGroup(const MtcpSlaveGroup &group)->void;

    // 属性修改
    auto setDescription(MtcpSlaveGroupType gtype, MtcpSlaveNodeType ntype, int index, const std::string &description)->void;
    auto setEditChangable(MtcpSlaveGroupType gtype, MtcpSlaveNodeType ntype, int index, bool editable,bool changable)->void;
    auto swapMtcpSlaveNode(MtcpSlaveGroupType gtype, MtcpSlaveNodeType ntype, int index, int toindex)->void;
    // 单个访问
    auto woWriteBool(int index, bool val)->void;
    auto woWriteInt16(int index, std::int16_t val)->void;
    auto woWriteFloat(int index, float val)->void;
    auto woGetBool(int index) const->bool;
    auto woGetInt16(int index) const->std::int16_t;
    auto woGetFloat(int index) const->float;

    auto roReadBool(int index) const->bool;
    auto roReadInt16(int index) const->std::int16_t;
    auto roReadFloat(int index) const->float;
    auto roSetBool(int index, bool val)->void;
    auto roSetInt16(int index, std::int16_t val)->void;
    auto roSetFloat(int index, float val)->void;

    auto wrWriteBool(int index, bool val)->void;
    auto wrWriteInt16(int index, std::int16_t val)->void;
    auto wrWriteFloat(int index, float val)->void;
    auto wrReadBool(int index) const->bool;
    auto wrReadInt16(int index) const->std::int16_t;
    auto wrReadFloat(int index) const->float;

    // 批量访问
    auto woBool() const noexcept->const std::vector<bool>&;
    auto woInt16() const noexcept->const std::vector<std::int16_t>&;
    auto woFloat() const noexcept->const std::vector<float>&;

    auto roBool() const noexcept->const std::vector<bool>&;
    auto roInt16() const noexcept->const std::vector<std::int16_t>&;
    auto roFloat() const noexcept->const std::vector<float>&;

    auto wrBool() const noexcept->const std::vector<bool>&;
    auto wrInt16() const noexcept->const std::vector<std::int16_t>&;
    auto wrFloat() const noexcept->const std::vector<float>&;

    // 批量重置
    auto resetWo()->void;
    auto resetRo()->void;
    auto resetWr()->void;

    auto isServing() const noexcept->bool;
    auto hasConnected() const noexcept->bool;

    static auto instanceInCs()->ModbusTcpServer&;

private:
    struct Imp;
    std::unique_ptr<Imp> imp_;

public:
    ModbusTcpServer();
    ~ModbusTcpServer();
    KAANH_DELETE_BIG_FOUR(ModbusTcpServer)
};

class KAANHBOT_API MtcpRoWaitBool : public aris::core::CloneObject<MtcpRoWaitBool, aris::plan::Plan> {
    public:
        auto prepareNrt()->void override;
        auto executeRT()->int override;

    private:
        int id_{-1};
        bool val_{false};
        int count_{-1};     // <0:一直等待 =0:不等待 >0:等待对应count数

    public:
        MtcpRoWaitBool();
};

class KAANHBOT_API MtcpRoWaitMultiBool : public aris::core::CloneObject<MtcpRoWaitMultiBool, aris::plan::Plan> {
    public:
        auto prepareNrt()->void override;
        auto executeRT()->int override;
    
    private:
        std::set<int> multi_id_;
        bool val_{false};
        int count_{-1};     // <0:一直等待 =0:不等待 >0:等待对应count数
        bool check_all_{true};
    public:
    MtcpRoWaitMultiBool();
};

class KAANHBOT_API MtcpWoPulse : public aris::core::CloneObject<MtcpWoPulse, aris::plan::Plan> {
    public:
        auto prepareNrt()->void override;
        auto executeRT()->int override;
        auto collectNrt()->void override;
    private:
        int id_{-1};
        bool val_{false};
        bool last_val_{false};
        int count_{1};
        bool is_normal_{false};
    public:
    MtcpWoPulse();
};

class KAANHBOT_API MtcpWrWaitBool : public aris::core::CloneObject<MtcpWrWaitBool, aris::plan::Plan> {
    public:
        auto prepareNrt()->void override;
        auto executeRT()->int override;

    private:
        int id_{-1};
        bool val_{false};
        int count_{-1};     // <0:一直等待 =0:不等待 >0:等待对应count数

    public:
    MtcpWrWaitBool();
};

class KAANHBOT_API MtcpWrWaitMultiBool : public aris::core::CloneObject<MtcpWrWaitMultiBool, aris::plan::Plan> {
    public:
        auto prepareNrt()->void override;
        auto executeRT()->int override;
    
    private:
        std::set<int> multi_id_;
        bool val_{false};
        int count_{-1};     // <0:一直等待 =0:不等待 >0:等待对应count数
        bool check_all_{true};
    public:
    MtcpWrWaitMultiBool();
};

class KAANHBOT_API MtcpWrPulse : public aris::core::CloneObject<MtcpWrPulse, aris::plan::Plan> {
    public:
        auto prepareNrt()->void override;
        auto executeRT()->int override;
        auto collectNrt()->void override;
    private:
        int id_{-1};
        bool val_{false};
        bool last_val_{false};
        int count_{1};
        bool is_normal_{false};
    public:
    MtcpWrPulse();
};





}   // namespace kaanhbot::protocol

#endif  // KAANHBOT_PROTOCOL_MODBUS_TCP_SERVER_HPP_