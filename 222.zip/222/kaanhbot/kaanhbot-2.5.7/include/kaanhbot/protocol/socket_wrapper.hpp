#ifndef KAANHBOT_PROTOCOL_SOCKET_WRAPPER_HPP_
#define KAANHBOT_PROTOCOL_SOCKET_WRAPPER_HPP_

#include <memory>

#include "kaanh/general/macro.hpp"
#include "kaanh/module/middle_module.hpp"
#include "kaanhbot_lib_export.h"

namespace kaanhbot::protocol {

class KAANHBOT_API SocketWrapper : public kaanh::module::MiddleModule {
public:
    auto virtual init()->void override;
    auto virtual execute(const std::string &str, std::function<void(std::string)> send_ret) noexcept->std::pair<std::string, std::string> override;

private:
    struct Imp;
    std::unique_ptr<Imp> imp_;

public:
    SocketWrapper();
    ~SocketWrapper();
    KAANH_DELETE_BIG_FOUR(SocketWrapper)
};

}   // namespace kaanhbot::protocol

#endif  // KAANHBOT_PROTOCOL_SOCKET_WRAPPER_HPP_