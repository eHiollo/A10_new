#ifndef KAANHBOT_SYSTEM_ABOUT_HPP_
#define KAANHBOT_SYSTEM_ABOUT_HPP_

#include <memory>
#include <functional>

#include "kaanh/module/middle_module.hpp"
#include "kaanh/general/macro.hpp"
#include "kaanhbot_lib_export.h"

namespace kaanhbot::system {

struct SysVersion{
    std::string name;
    std::string version;
    std::string description;
    NLOHMANN_DEFINE_TYPE_INTRUSIVE(SysVersion,name,version,description);
};

class KAANHBOT_API About : public kaanh::module::MiddleModule {
public:
    auto virtual init()->void override;

    auto virtual execute(const std::string &str, std::function<void(std::string)> send_ret) noexcept->std::pair<std::string, std::string> override;

    static auto registerCbk(const std::string &name,
                            const std::function<std::pair<std::string, std::string>()> &compile_version,
                            const std::function<std::pair<std::string, std::string>()> &running_version)->void;

private:
    struct Imp;
    std::unique_ptr<Imp> imp_;

public:
    std::vector<SysVersion> system_version_vec_;
    About();
    virtual ~About();
    KAANH_DELETE_BIG_FOUR(About)

};

}   // namespace kaanhbot::system

#endif  // KAANHBOT_SYSTEM_ABOUT_HPP_
