#ifndef KAANHBOT_SYSTEM_SYSTEM_HPP_
#define KAANHBOT_SYSTEM_SYSTEM_HPP_

#include <memory>
#include <ctime>

#include "kaanh/module/middle_module.hpp"
#include "kaanh/general/macro.hpp"
#include "kaanh/general/json.hpp"
#include "kaanhbot_lib_export.h"

namespace kaanhbot::system {

// cpu & memory
struct MemInfo {
    char name1[20];
    unsigned long MemTotal;
    char name2[20];
    unsigned long MemFree;
};

struct CpuInfo {
    char name[20];
    unsigned int user;
    unsigned int nice;
    unsigned int system;
    unsigned int idle;
};

struct Disk {
    char name[50];
    char dir[50];
    char type[50];
    char flag[150];
    int c1;
    int c2;
};

enum class KAANHBOT_API Language : int {
    kEnglish = 1,
    kChinese
};

NLOHMANN_JSON_SERIALIZE_ENUM(Language, {
    {Language::kEnglish, "English"},
    {Language::kChinese, "Chinese"}
})

class KAANHBOT_API System : public kaanh::module::MiddleModule {
public:
    auto virtual init()->void override;

    auto virtual execute(const std::string &str, std::function<void(std::string)> send_ret) noexcept->std::pair<std::string, std::string> override;

    auto resetSystime(const std::time_t &tt)->void;

    auto language() const noexcept->std::string;
    auto resetLanguage(const std::string &language)->void;

    auto mountDir() const->std::string;
    auto resetMountDir(const std::string &mount_dir)->void;

    static auto copyFile(const std::filesystem::path &from, const std::filesystem::path &to, bool cover=true)->bool;
    static auto copyDir(const std::filesystem::path &from, const std::filesystem::path &to, std::vector<std::string> prjs={}, bool del=true, bool fm=false, bool dir=true, bool cover=true)->std::pair<std::vector<std::string>, bool>; // del: to路径存在时，是否清空该目录
    static auto getChildDir(const std::filesystem::path &path)->std::vector<std::string>;
    auto udiskQuery()->std::vector<std::string>;

    static auto pgmProcessor(std::map<std::string_view, std::string_view> params, std::filesystem::path udisk, std::function<void(std::string)> send_ret)->void;

    static auto instanceInCs()->System&;

private:
    struct Imp;
    std::unique_ptr<Imp> imp_;

public:
    System();
    ~System();
    KAANH_DELETE_BIG_FOUR(System)
};

}   // namespace kaanhbot::system


#endif // KAANHBOT_SYSTEM_SYSTEM_HPP_

