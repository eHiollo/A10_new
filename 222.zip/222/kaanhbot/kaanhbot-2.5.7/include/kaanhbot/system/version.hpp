#ifndef KAANHBOT_SYSTEM_VERSION_HPP_
#define KAANHBOT_SYSTEM_VERSION_HPP_

#include <map>
#include <string>
#include "kaanhbot_lib_export.h"
namespace kaanhbot::system {

    // 返回值 <版本号, 版本描述>
KAANHBOT_API  auto version()->std::pair<std::string, std::string>;

}   // namespace kaanhbot::system

#endif  // KAANHBOT_SYSTEM_VERSION_HPP_
