#ifndef KAANHBOT_FUNCTIONAL_SINGLETEN_DATA_HPP_
#define KAANHBOT_FUNCTIONAL_SINGLETEN_DATA_HPP_

#include <memory>

#include "kaanh/general/macro.hpp"
#include "kaanhbot_lib_export.h"

namespace kaanhbot::functional {

class KAANHBOT_API SingletenData {
public:
    static auto instance()->SingletenData&;

    auto waitResult() const noexcept->bool;
    auto setWaitResult(bool result)->void;

private:
    struct Imp;
    std::unique_ptr<Imp> imp_;

private:
    SingletenData();
    ~SingletenData();
};

}   // namespace kaanhbot::functional

#endif  // KAANHBOT_FUNCTIONAL_SINGLETEN_DATA_HPP_
