#ifndef KAANHBOT_FUNCTIONAL_TERMINAL_HPP_
#define KAANHBOT_FUNCTIONAL_TERMINAL_HPP_

#include "kaanh/module/middle_module.hpp"
#include "kaanh/general/macro.hpp"
#include "kaanhbot_lib_export.h"

namespace kaanhbot::functional {

class KAANHBOT_API Terminal : public kaanh::module::MiddleModule {
public:
    auto virtual execute(const std::string &str, std::function<void(std::string)> send_ret) noexcept->std::pair<std::string, std::string> override;

    static auto instanceInCs()->Terminal&;
    auto setCmds(std::set<std::string> cmds) -> void;
    auto cmds() -> std::set<std::string>; 
    auto setChannel(const int channel) -> void;
    auto channel() const -> const int; 
private:
    struct Imp;
    std::unique_ptr<Imp> imp_;
    
public:
        Terminal();
        ~Terminal();
    KAANH_DELETE_BIG_FOUR(Terminal)
};

}   // namespace kaanhbot::functional

#endif // KAANHBOT_FUNCTIONAL_TERMINAL_HPP_