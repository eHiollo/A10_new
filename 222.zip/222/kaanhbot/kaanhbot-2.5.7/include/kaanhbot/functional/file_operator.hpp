#ifndef KAANHBOT_FUNCTIONAL_FILE_OPERATOR_HPP_
#define KAANHBOT_FUNCTIONAL_FILE_OPERATOR_HPP_

#include <memory>

#include "kaanh/module/middle_module.hpp"
#include "kaanh/general/macro.hpp"
#include "kaanhbot_lib_export.h"

namespace kaanhbot::functional {

class KAANHBOT_API FileOperator : public kaanh::module::MiddleModule{
public:
    auto virtual init()->void override;

    auto virtual execute(const std::string &str, std::function<void(std::string)> send_ret) noexcept->std::pair<std::string, std::string> override;

private:
    struct Imp;
    std::unique_ptr<Imp> imp_;

public:
    FileOperator();
    ~FileOperator();
    KAANH_DELETE_BIG_FOUR(FileOperator)
};

}   // namespace kaanhbot::functional

#endif // KAANHBOT_FUNCTIONAL_FILE_OPERATOR_HPP_
