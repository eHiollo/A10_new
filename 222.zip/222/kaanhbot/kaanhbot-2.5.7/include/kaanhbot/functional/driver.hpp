#ifndef KAANHBOT_FUNCTIONAL_DRIVER_HPP_
#define KAANHBOT_FUNCTIONAL_DRIVER_HPP_

#include <memory>
#include <iostream>
#include <vector>
#include <map>
#include <string>
#include <functional>
#include <fstream>
#include <utility>

#include "kaanh/module/middle_module.hpp"
#include "kaanh/general/macro.hpp"
#include "kaanhbot_lib_export.h"
#include "kaanh/general/json.hpp"
#include "aris/server/control_server.hpp"

#include "kaanh/log/log.hpp"

namespace kaanhbot::functional {

#define GENERAL_CODE_PATH "./doc/driver_err_code.txt"
#define QNRC_CODE_PATH "./doc/QNRC_code.txt"
#define QNRD_CODE_PATH "./doc/QNRD_code.txt"

//依赖motorPool  需要通过此来读写pdo
class EthercatDriver;

struct DriverSDO{
    std::string name_;
    std::string chinese_description_;
    std::uint16_t index_;
    std::uint32_t min_val_;
    std::uint32_t max_val_;
    std::uint16_t subindex_;
    bool restart_enable_;
    DriverSDO(){};
    DriverSDO(std::string name,std::string chinese_description,std::uint16_t index,std::uint32_t min_val,std::uint32_t max_val,std::uint16_t subindex=0x00,bool restart_enable=false):
        name_(name),chinese_description_(chinese_description),index_(index),min_val_(min_val),max_val_(max_val),subindex_(subindex),restart_enable_(restart_enable){}
    NLOHMANN_DEFINE_TYPE_INTRUSIVE(DriverSDO,name_,chinese_description_,index_,min_val_,max_val_,subindex_,restart_enable_)

};

class  DriverCsvParse: public kaanh::module::MiddleModule{
public:
    auto virtual init()->void override;
    auto virtual execute(const std::string &,std::function<void(std::string)> send_ret) noexcept->std::pair<std::string, std::string> override;
    KAANH_API static auto instanceInCs()->DriverCsvParse&;
    auto getsto1(const std::string& vendor_id,const std::string& product_code,const std::string& revision_num)->std::uint16_t;
    auto getsto2(const std::string& vendor_id,const std::string& product_code,const std::string& revision_num)->std::uint16_t;
    auto getbreakcode(const std::string& vendor_id,const std::string& product_code,const std::string& revision_num)->std::uint16_t;
    auto getSdoVec(const std::string& vendor_id,const std::string& product_code,const std::string& revision_num)->std::vector<std::vector<std::string>>;
    auto getErrorpair(int vendor_id,int product_code,int revision_num,uint16_t errorcode)->std::pair<std::string,std::string>;
    // auto getsto1(const std::string& driver_name)->std::uint16_t;
    // auto getsto2(const std::string& driver_name)->std::uint16_t;
    // auto getbreakcode(const std::string& driver_name)->std::uint16_t;
    // auto getSdoVec(const std::string& driver_name)->std::vector<std::vector<std::string>>;
private:
    struct  Imp;
    std::unique_ptr<Imp> imp_;

public:
    DriverCsvParse();
    virtual ~DriverCsvParse();
    KAANH_DELETE_BIG_FOUR(DriverCsvParse)
};


class  Driver: public kaanh::module::MiddleModule{
public:
    auto virtual init()->void override;
    auto virtual execute(const std::string &,std::function<void(std::string)> send_ret) noexcept->std::pair<std::string, std::string> override;

    KAANH_API static auto instanceInCs()->Driver&;
    auto driver_break_ready()-> bool;
    auto has_err()-> bool;
    auto uint16ToHexString(int num)->std::string;

    // auto setDriverPool(aris::core::PointerArray<EthercatDriver> *pool)->void{
    //     assert(pool);
    //     driver_pool_.reset(pool);
    // }
    auto getDriverPool()const ->aris::core::PointerArray<EthercatDriver>&  {return *driver_pool_; }
private:
    std::atomic_bool init_shield_ethercat_sync_error_{false};
    struct  Imp;
    std::unique_ptr<Imp> imp_;
    std::unique_ptr<aris::core::PointerArray<EthercatDriver>> driver_pool_;

public:
    Driver();
    virtual ~Driver();
    KAANH_DELETE_BIG_FOUR(Driver)
};


//-----------新增内容----------
//！配置时，电机号从1开始计算

class KAANHBOT_API EthercatDriver{
public:
    //设置vendor_id、product_code、revision_num
    auto virtual setVendorid(int vendor_id_)->void{vendor_id = vendor_id_;}
    auto virtual setProductcode(int product_code_)->void{product_code = product_code_;}
    auto virtual setRevisionnum(int revision_num_)->void{revision_num = revision_num_;}
    auto virtual getVendorid()->int{return vendor_id;}
    auto virtual getProductcode()->int{return product_code;}
    auto virtual getRevisionnum()->int{return revision_num;}
    //设置获取急停错误码 通过反射获取
    auto virtual setSto1(std::uint16_t sto1)->void{sto1_=sto1;}
    auto virtual getSto1() const->std::uint16_t  {return sto1_;}
    auto virtual setSto2(std::uint16_t sto2)->void{sto2_=sto2;}
    auto virtual getSto2() const->std::uint16_t  {return sto2_;}
    //绑定的电机号
    auto virtual setMotorId(std::uint32_t motor_id)->void {motor_id_=motor_id;}
    auto virtual getMotorId() const->uint32_t  {return motor_id_;}
    //反射pdo
    auto virtual setDriverBreakPdo(uint16_t driver_break_pdo)->void{driver_break_pdo_=driver_break_pdo;}
    auto virtual getDriverBreakPdo()->uint16_t {return driver_break_pdo_;}
    //绑定的电机号
    auto virtual setOffset(std::uint16_t offset)->void {offset_=offset;}
    auto virtual getOffset() const->uint16_t  {return offset_;}
    //设置获取错误信息
    // auto virtual setErrDescMap(std::string err_code_file)->void{
    //     std::ifstream ifs(err_code_file);
    //     if(!ifs){
    //         return;
    //     }
    //     std::uint16_t err_code{0};
    //     std::string solver{};
    //     std::string discribe{};
    //     int i=0;
    //     while(ifs && i < 600){
    //         ifs>>std::hex>>err_code;
    //         ifs>>discribe;
    //         ifs>>solver;
    //         errcode_description_map_[err_code]=discribe+":"+solver;
    //         i++;
    //     }
    //     ifs.close();
    //     return;
    // }
    // auto virtual getErrDescMap()->std::map<uint16_t,std::string>const {return errcode_description_map_;}
    auto virtual getErrDescstr(uint16_t errorcode)->std::pair<std::string,std::string>{ 
        return DriverCsvParse::instanceInCs().getErrorpair(vendor_id,product_code,revision_num,errorcode);
    }
    //松开抱闸动作 返回false表示不支持
    auto virtual releaseBreak()->bool{
        auto &motor =aris::server::ControlServer::instance().controller().motorPool().at(getMotorId()-1);
        motor.setOutputIoNrt(1,0x01);
        motor.setOutputIoNrt(2,0x01);
        return true;
    }
    auto virtual recoveryBreak()->bool{
        auto &motor =aris::server::ControlServer::instance().controller().motorPool().at(getMotorId()-1);
        motor.setOutputIoNrt(1,0x00);
        motor.setOutputIoNrt(2,0x00);
        return true;
    }
    //抱闸检查设置 实时线程中检查,所以不能为sdo
    auto virtual checkBreak()noexcept->bool{
        auto &motor =aris::server::ControlServer::instance().controller().motorPool().at(getMotorId()-1);
        auto &ethercat_motor=dynamic_cast<aris::control::EthercatMotor&>(motor);
        if(ethercat_motor.slave()->isVirtual()==false){
            //当0x01 输出为0的时候 设置不生效，此时抱闸设置正常
            if(!motor.outputIoNrt(1)) return true;
            //当0x01 输出为1的时候 设置生效，此时抱闸设置不正常
            else return false;
        }
        else return true;
    }
    auto virtual encoderClean()const ->bool{
        auto &motor =aris::server::ControlServer::instance().controller().motorPool().at(getMotorId()-1);
        motor.setControlWord(0x1000);
        std::this_thread::sleep_for(std::chrono::milliseconds(10));
        motor.setControlWord(0);
        return true;
    }
    auto virtual setDriverSDOPool(std::vector<DriverSDO> sdo_pool)->void{
        sdo_pool_=sdo_pool;
    }
    auto virtual getDriverSDOPool()const ->std::vector<DriverSDO>  {return sdo_pool_; }
    auto virtual getDriverSdoVals()const->std::vector<uint32_t>{
        std::vector<uint32_t> vec;
        vec.resize(sdo_pool_.size(),0);
        for(int i=0;i<sdo_pool_.size();i++){
            auto &ethercat_motor=dynamic_cast<aris::control::EthercatMotor&>(aris::server::ControlServer::instance().controller().motorPool().at(getMotorId()-1));
            ethercat_motor.slave()->readSdo(sdo_pool_[i].index_,sdo_pool_[i].subindex_,vec[i]);
        }
        return vec;
    }

    auto virtual getSingleDriverSdoVal(int index)const->uint32_t{
        if(index<0 ||  index > sdo_pool_.size()) return false;
        uint32_t val{0};
        auto &ethercat_motor=dynamic_cast<aris::control::EthercatMotor&>(aris::server::ControlServer::instance().controller().motorPool().at(getMotorId()-1));
        ethercat_motor.slave()->readSdo(sdo_pool_[index].index_,sdo_pool_[index].subindex_,val);
        return val;
    }

    auto virtual setSingleDriverSdoVal(int index,uint32_t val)->bool {
        if(index<0 ||  index > sdo_pool_.size()) return false;
        if(val > sdo_pool_[index].max_val_ || val< sdo_pool_[index].min_val_) return true;
        auto &ethercat_motor=dynamic_cast<aris::control::EthercatMotor&>(aris::server::ControlServer::instance().controller().motorPool().at(getMotorId()-1));
        ethercat_motor.slave()->writeSdo(sdo_pool_[index].index_,sdo_pool_[index].subindex_,val);
        if (getVendorid() == 1558 || getProductcode() == 5152 || getRevisionnum() == 256) //GW
            ethercat_motor.slave()->writeSdo(0x245b,0x00,1);
        else
            ethercat_motor.slave()->writeSdo(0x1010,0x01,0x65766173);
        return true;
    }
private:
    uint32_t motor_id_{1};
    int vendor_id;
    int product_code;
    int revision_num;
    uint16_t sto1_{0};
    uint16_t sto2_{0};
    std::map<uint16_t,std::string> errcode_description_map_;
    uint16_t driver_break_pdo_{0};
    std::uint16_t offset_{0};
    std::string name_;
    std::vector<DriverSDO> sdo_pool_;
public:
    explicit EthercatDriver(std::string name="EthercatDriver"){name_=name;}
    virtual ~EthercatDriver()=default;
    KAANH_DEFINE_BIG_FOUR(EthercatDriver)
};

}//namespace kaanhbot::functional

#endif // KAAANHBOT_FUNCTIONAL_DRIVER_HPP_

