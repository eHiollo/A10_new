#ifndef KAANHBOT_TIMER_COUNTER_HPP_
#define KAANHBOT_TIMER_COUNTER_HPP_

#include <cinttypes>
#include <chrono>
#include "kaanh/module/middle_module.hpp"

namespace kaanhbot::functional {
class TimeCounter:public kaanh::module::MiddleModule{
public:
   auto virtual init()->void override;
   auto virtual execute(const std::string &str,std::function<void(std::string)> send_ret) noexcept->std::pair<std::string,std::string> override;

   auto timeStart()->void;
   auto timeInterval()->double;
private:
   std::chrono::time_point<std::chrono::system_clock> start_time_;
   uint16_t timer_status_{0}; //1表示计时开始，2表示计时停止。如果状态==0，那么获取的计时为0；程序卸载，需要让这个数值清零
   struct Imp;
   std::unique_ptr<Imp> imp_;
public:
   TimeCounter();
   virtual ~TimeCounter();
   KAANH_DELETE_BIG_FOUR(TimeCounter)
};

class Timer{
public:
   auto start()->void;
   auto pause()->void;
   auto clear()->void;
   auto update()->void;
   auto time()->double{return time_count_;}

private:

   double time_count_{0.0}; //计时器时间
   double before_pause_count_{0.0};  //暂停前已经计时的时间
   uint16_t timer_status_{0}; //1表示计时开始，2表示计时停止。如果状态==0，那么获取的计时为0；

   struct Imp;
   std::unique_ptr<Imp> imp_;
public:
   Timer();
   ~Timer();
   KAANH_DELETE_BIG_FOUR(Timer)
};


}

#endif // KAANHBOT_TIMER_COUNTER_HPP_
