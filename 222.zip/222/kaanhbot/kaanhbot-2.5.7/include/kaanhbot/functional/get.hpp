#ifndef KAANHBOT_FUNCTIONAL_GET_HPP_
#define KAANHBOT_FUNCTIONAL_GET_HPP_

#include <memory>
#include "kaanh/module/middle_module.hpp"

namespace kaanhbot::functional {

class Get : public kaanh::module::MiddleModule {
public:
    auto virtual init()->void override;
    auto virtual execute(const std::string &str, std::function<void(std::string)> send_ret) noexcept->std::pair<std::string, std::string> override;

private:
    struct Imp;
    std::unique_ptr<Imp> imp_;

public:
    Get();
    ~Get();
    KAANH_DELETE_BIG_FOUR(Get)
};

}   // namespace kaanhbot::functional

#endif  // KAANHBOT_FUNCTIONAL_GET_HPP_
