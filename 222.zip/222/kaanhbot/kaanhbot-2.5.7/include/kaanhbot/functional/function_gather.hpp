#ifndef KAANHBOT_FUNCTIONAL_FUNCTION_GATHER_HPP_
#define KAANHBOT_FUNCTIONAL_FUNCTION_GATHER_HPP_


#include "kaanh/module/middle_module.hpp"
#include "kaanhbot_lib_export.h"
#include "aris.hpp"
#include "kaanhbot/io/io_manager.hpp"
#include "aris/ext/tinyxml2.h"
#include "kaanh/module/pgm_controller.hpp"
#include <sys/stat.h>


namespace  kaanhbot::functional {

enum class IOType : int {
    kEthercat = 0,
    kRtu,
};
NLOHMANN_JSON_SERIALIZE_ENUM(IOType, {
    {IOType::kEthercat, "Ethercat"},
    {IOType::kRtu, "Rtu"}
})

class KAANHBOT_API WaitMultiDi : public aris::core::CloneObject<WaitMultiDi, aris::plan::Plan> {
public:
    auto prepareNrt()->void override;
    auto executeRT()->int override;

private:
    std::set<int> multi_id_;
    bool val_{false};
    bool check_all_;
    int count_{-1};     // <0:一直等待 0:不等待 >0:等待对应周期数

    std::vector<kaanhbot::io::InputChannel<bool> *> channel_vec_{};

public:
    WaitMultiDi();
};

class KAANHBOT_API WriteFile{
public:
    auto openFile(std::string filename,bool restart=false)->bool{
        if(ofs.is_open()){
            ofs.close();
        }
        ofs.clear();
        path_="./program/"+kaanh::module::PgmController::instanceInCs().loadedInfo().first+"/"+filename+".txt";
        if(!restart) ofs.open(path_,std::ios::app);
        else ofs.open(path_,std::ios::trunc);
        if(!ofs.is_open()) return false;
        else return true;
    }

    auto write(std::string context)->int{
        if(!ofs.is_open()){
            LOCALE_THROW("please open file before write","请先打开文件后再写入");
            return -1;
        }
        if(!checkSize(path_)){
            LOCALE_THROW("file size out of 1MB","文件超过1MB,请打开其它文件再写入");
            return -2;
        }
        ofs<<context;
        ofs.flush();
        return 0;
    }

    auto writeLine(std::string context)->int{
        if(!ofs.is_open()) return -1;
        if(!checkSize(path_))return -2;
        ofs<<context<<std::endl;
        ofs.flush();
        return 0;
    }

    auto deleteFile(std::string filename)->bool{
        if(ofs.is_open()){
            ofs.close();
            ofs.clear();
        }
        std::string tmp_path="./program/"+kaanh::module::PgmController::instanceInCs().loadedInfo().first+"/"+filename+".txt";
        if(std::filesystem::exists(tmp_path)) std::filesystem::remove(path_);
        else return false;
        return true;
    }
private:
    auto checkSize(std::string path)->bool{
        struct stat statbuf;
        //提供文件名字符串，获得文件属性结构体
        if(std::filesystem::exists(path)){
            if(-1== stat(path.c_str(), &statbuf)){
                return false;
            }else {
            // 获取文件大小
            size_t filesize = statbuf.st_size;
            if(filesize  > pow(2,20)) return false;
            }
            return true;
        }else return false;
    }

    std::string path_;
    std::ofstream ofs;
public:
    WriteFile(){}
    ~WriteFile()=default;
    KAANH_DELETE_BIG_FOUR(WriteFile)
};

class KAANHBOT_API FunctionGather : public kaanh::module::MiddleModule{
public:

    auto getIoName()->std::map<std::string,IOType>;
    auto getXmlIo()->std::vector<std::tuple<std::string,bool,int>>;
    auto addIo(std::vector<std::pair<std::string,int>>)->bool;
    auto deleteIo(int num)->bool;

    auto getSlaveAttr()->std::vector<std::tuple<std::string,std::string,std::string,std::string,std::string>>;
    auto getXmlSlave()->std::vector<std::tuple<std::string,std::string,std::string,std::string>>;

    auto virtual init()->void override;
    auto virtual execute(const std::string &str,std::function<void(std::string)> send_ret) noexcept->std::pair<std::string,std::string> override;
    auto robotNetworkID()->std::string{return robot_network_id_;}
    auto setRobotNetworkID(const std::string robot_network_id)->void{robot_network_id_=robot_network_id;}

    //反射
    auto startPgmvel()->const std::uint8_t{return start_pgmvel_;}
    auto setStartPgmvel(std::uint8_t start_pgmvel){start_pgmvel_=start_pgmvel;}

    auto mainboardId() const->std::string;
    auto setMainboardId(const std::string &)->void;

private:
    //反射程序速度
    std::uint8_t start_pgmvel_{1};
    //如果当前id不存在，则添加
    auto modify_network(std::string networkid,std::string method,std::string ip,std::string netmask,std::string filename="/etc/network/interfaces")->int;
    auto modify_networkmyir(std::string networkid,std::string method,std::string ip,std::string netmask)->int;
    auto modify_networkJ1028(std::string networkid,std::string method,std::string ip,std::string netmask)->int;
    auto modify_network3030(std::string networkid,std::string method,std::string ip,std::string netmask)->int;
    //重新复写文件

    auto create_network(std::map<std::string,std::vector<std::string>> id_ip, std::string filename="/etc/network/interfaces")->int;
    auto create_networkmyir(std::pair<std::string,std::pair<std::string,std::string>> id_ip)->int;
    auto network_quiry(std::string filename="/etc/network/interfaces")->std::map<std::string,std::vector<std::string>>;
    auto network_quirymyir()->std::map<std::string,std::vector<std::string>>;
    auto network_queryJ1028()->std::map<std::string,std::vector<std::string>>;
    auto network_query3030()->std::map<std::string,std::vector<std::string>>;
    std::string  robot_network_id_;

    struct Imp;
    std::unique_ptr<Imp> imp_;

public:
    FunctionGather();
    virtual ~FunctionGather();
    KAANH_DELETE_BIG_FOUR(FunctionGather)
};

}//namespace kaanhbot::module


#endif //KAANHBOT_MODULE_FUNCTION_GATHER_HPP_
