#ifndef KAANHBOT_FUNCTIONAL_DISTRIBUTOR_HPP_
#define KAANHBOT_FUNCTIONAL_DISTRIBUTOR_HPP_

#include <memory>
#include <vector>

#include "kaanh/module/middle_module.hpp"
#include "kaanh/general/macro.hpp"
#include "kaanhbot_lib_export.h"

namespace kaanhbot::functional {

struct KAANHBOT_API DistributeRule {
    std::string module_;
    std::string cmds_;      // 指令之间用";"隔开
};

class KAANHBOT_API Distributor : public kaanh::module::MiddleModule {
public:
    auto virtual execute(const std::string &str, std::function<void(std::string)> send_ret) noexcept->std::pair<std::string, std::string> override;

    auto distributeRules() const noexcept->std::vector<DistributeRule>;

    auto resetDistributeRules(const std::vector<DistributeRule> &rules)->void;
    
    static auto instanceInCs()->Distributor&;

public:
    struct Imp;
    std::unique_ptr<Imp> imp_;

public:
    Distributor();
    ~Distributor();
    KAANH_DELETE_BIG_FOUR(Distributor)
};

}   // namespace kaanhbot::functional

#endif // KAANHBOT_FUNCTIONAL_DISTRIBUTOR_HPP_