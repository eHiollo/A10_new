#ifndef KAANHBOT_USER_USER_MANAGEMENT_HPP_
#define KAANHBOT_USER_USER_MANAGEMENT_HPP_

#include <memory>

#include "kaanh/module/middle_module.hpp"
#include "kaanh/general/macro.hpp"
#include "kaanh/general/json.hpp"
#include "kaanhbot_lib_export.h"

namespace kaanhbot::user {

enum class KAANHBOT_API User : int {
    kNone = 0,
    kOperator,
    kEngineer,
    kAdministrator,
    kManufacturer,
    kDeveloper
};

NLOHMANN_JSON_SERIALIZE_ENUM(User, {
    {User::kNone, "None"},
    {User::kOperator, "Operator"},
    {User::kEngineer, "Engineer"},
    {User::kAdministrator, "Administrator"},
    {User::kManufacturer, "Manufacturer"},
    {User::kDeveloper, "Developer"}
})

class KAANHBOT_API UserManagement : public kaanh::module::MiddleModule {
public:
    auto virtual init()->void override;
    auto virtual execute(const std::string &str, std::function<void(std::string)> send_ret) noexcept->std::pair<std::string, std::string> override;

    auto getOpPwd() const noexcept->const std::string&;
    auto getEnPwd() const noexcept->const std::string&;
    auto getAdPwd() const noexcept->const std::string&;
    auto resetOpPwd(const std::string &pwd) const noexcept->void;
    auto resetEnPwd(const std::string &pwd) const noexcept->void;
    auto resetAdPwd(const std::string &pwd) const noexcept->void;
    auto login(User user, const std::string &pwd)->void;
    auto logout() noexcept->void;
    auto user() const noexcept->User;
    auto resetPwd(User user, const std::string &pwd, const std::string &new_pwd)->void;
    auto pwdquery(User user, const std::string &pwd) const->bool;

    static auto instanceInCs()->UserManagement&;
    
private:
    struct Imp;
    std::unique_ptr<Imp> imp_;

public:
    UserManagement();
    virtual ~UserManagement();
    KAANH_DELETE_BIG_FOUR(UserManagement)
};

}   // namespace kaanhbot::user

#endif // KAANHBOT_USER_USER_MANAGEMENT_HPP_

