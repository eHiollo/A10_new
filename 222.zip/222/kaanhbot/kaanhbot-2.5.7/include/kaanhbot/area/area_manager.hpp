#ifndef KAANHBOT_AREA_AREA_MANAGER_HPP_
#define KAANHBOT_AREA_AREA_MANAGER_HPP_

#include <memory>

#include "aris/core/object.hpp"
#include "kaanh/general/macro.hpp"
#include "kaanh/module/middle_module.hpp"
#include "kaanhbot/area/unit.hpp"
#include "kaanhbot_lib_export.h"

namespace kaanhbot::area {

class KAANHBOT_API AreaManager : public kaanh::module::MiddleModule {
public:
    auto init()->void override;
    auto execute(const std::string &str, std::function<void(std::string)> send_ret) noexcept->std::pair<std::string, std::string> override;

    auto unitPool()->aris::core::PointerArray<AreaUnit>&;
    auto unitPool() const->const aris::core::PointerArray<AreaUnit>& { return const_cast<AreaManager*>(this)->unitPool(); }
    auto resetUnitPool(aris::core::PointerArray<AreaUnit> *pool)->void;

    static auto instanceInCs()->AreaManager&;

public:
    auto setAllActive(bool active)->void;
    auto setAllControl(bool control)->void;
    auto setActive(int index, bool active)->void;
    auto setControl(int index, bool control)->void;

private:
    struct Imp;
    aris::core::ImpPtr<Imp> imp_;

public:
    AreaManager();
    ~AreaManager();

    KAANH_DELETE_BIG_FOUR(AreaManager)
};


}   // namespace kaanhbot::area

#endif  // KAANHBOT_AREA_AREA_MANAGER_HPP_
