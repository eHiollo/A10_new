#ifndef KAANHBOT_AREA_UNIT_HPP_
#define KAANHBOT_AREA_UNIT_HPP_

#include <atomic>
#include <array>

#include "aris/core/object.hpp"
#include "kaanh/general/json.hpp"
#include "kaanh/general/macro.hpp"
#include "kaanhbot/utility/tool_api.hpp"


namespace kaanhbot::area {

enum class AreaType : int {
    kNone = 0,
    kWork,
    kForbid,
    kSignal,
    kInterfere
};

NLOHMANN_JSON_SERIALIZE_ENUM(AreaType, {
    {AreaType::kNone, "None"},
    {AreaType::kWork, "Work"},
    {AreaType::kForbid, "Forbid"},
    {AreaType::kSignal, "Signal"},
    {AreaType::kInterfere, "Interfere"}
})

enum class AreaShape : int {
    kCuboid = 1,
    kSphere
};

NLOHMANN_JSON_SERIALIZE_ENUM(AreaShape, {
    {AreaShape::kCuboid, "Cuboid"},
    {AreaShape::kSphere, "Sphere"}
})

enum class CollideType : int {
    kExclude = 0,   //!< 无干涉
    kIntersect,     //!< 有干涉
    kInclude,       //!< 包含
    kIncluded       //!< 被包含
};

struct CuboidCell {
    std::array<double, 3> center{0,0,0};
    std::array<double, 3> eul{0,0,0};
    std::array<double, 3> length{1, 1, 1};
    int wobj{0};

    auto check() const->void {
        for (const auto &v : length)
            if (v <= 0)
                LOCALE_THROW("length must be positive", "长度必须为正数");
    }

    auto toSi() const->CuboidCell { // 转国际单位制
        CuboidCell ret = *this;
        kaanhbot::utility::s_mm2m(ret.center.data(), ret.center.size());
        kaanhbot::utility::s_deg2rad(ret.eul.data(), ret.eul.size());
        kaanhbot::utility::s_mm2m(ret.length.data(), ret.length.size());
        return ret;
    }

    auto toUi() const->CuboidCell { // 转显示
        CuboidCell ret = *this;
        kaanhbot::utility::s_m2mm(ret.center.data(), ret.center.size());
        kaanhbot::utility::s_rad2deg(ret.eul.data(), ret.eul.size());
        kaanhbot::utility::s_m2mm(ret.length.data(), ret.length.size());
        return ret;
    }

    NLOHMANN_DEFINE_TYPE_INTRUSIVE(CuboidCell, center, eul, length, wobj)
};

struct SphereCell {
    std::array<double, 3> center{0,0,0};
    double radius{1};
    int wobj{0};

    auto check() const->void {
        if (radius <= 0) LOCALE_THROW("radius must be positive", "半径必须为正数");  
    }

    auto toSi() const->SphereCell { // 转国际单位制
        SphereCell ret = *this;
        kaanhbot::utility::s_mm2m(ret.center.data(), ret.center.size());
        kaanhbot::utility::s_mm2m(&ret.radius, 1);
        return ret;
    }

    auto toUi() const->SphereCell { // 转显示
        SphereCell ret = *this;
        kaanhbot::utility::s_m2mm(ret.center.data(), ret.center.size());
        kaanhbot::utility::s_m2mm(&ret.radius, 1);
        return ret;
    }

    NLOHMANN_DEFINE_TYPE_INTRUSIVE(SphereCell, center, radius, wobj)
};

struct UnitCuboidInfo {
    std::array<double, 3> point1{0,0,0};   // mm
    std::array<double, 3> point2{0.1,0.1,0.1};   // mm
    int wobj{0};
    std::array<double, 3> eul{0,0,0};      // deg

    auto check() const->void {
        for (int i=0; i<3; ++i) {
            if (std::abs(point1[i]-point2[i]) >= 1e-3)
                return;
        }

        LOCALE_THROW("point can't coincide", "点位不能重合");
    }

    auto reset()->void {
        for (auto &v : point1) v = 0;
        for (auto &v : point2) v = 0;
        wobj = 0;
        for (auto &v : eul) v = 0;
    }

    auto toSi() const->UnitCuboidInfo { // 转国际单位制
        UnitCuboidInfo ret = *this;
        kaanhbot::utility::s_mm2m(ret.point1.data(), ret.point1.size());
        kaanhbot::utility::s_mm2m(ret.point2.data(), ret.point2.size());
        kaanhbot::utility::s_deg2rad(ret.eul.data(), ret.eul.size());
        return ret;
    }

    auto toUi() const->UnitCuboidInfo { // 转显示
        UnitCuboidInfo ret = *this;
        kaanhbot::utility::s_m2mm(ret.point1.data(), ret.point1.size());
        kaanhbot::utility::s_m2mm(ret.point2.data(), ret.point2.size());
        kaanhbot::utility::s_rad2deg(ret.eul.data(), ret.eul.size());
        return ret;
    }

    NLOHMANN_DEFINE_TYPE_INTRUSIVE(UnitCuboidInfo, point1, point2, wobj, eul)
};

struct UnitSphereInfo {
    std::array<double, 3> center{0,0,0};   // mm
    double radius{0};                  // mm
    int wobj{0};

    auto check() const->void {
        if (radius <= 0) LOCALE_THROW("radius must be positive", "半径必须为正数");
    }

    auto reset()->void {
        for (auto &v : center) v = 0;
        radius = 0;
        wobj = 0;
    }

    auto toSi() const->UnitSphereInfo { // 转国际单位制
        UnitSphereInfo ret = *this;
        kaanhbot::utility::s_mm2m(ret.center.data(), ret.center.size());
        kaanhbot::utility::s_mm2m(&ret.radius, 1);
        return ret;
    }

    auto toUi() const->UnitSphereInfo { // 转显示
        UnitSphereInfo ret = *this;
        kaanhbot::utility::s_m2mm(ret.center.data(), ret.center.size());
        kaanhbot::utility::s_m2mm(&ret.radius, 1);
        return ret;
    }

    NLOHMANN_DEFINE_TYPE_INTRUSIVE(UnitSphereInfo, center, radius, wobj)
};

struct TcpCuboidInfo {
    std::array<double, 3> center{0,0,0};              // mm
    std::array<double, 3> length{1, 1, 1};     // mm
    int tool{0};

    auto check() const->void {
        for (const auto &v : length)
            if (v <= 0)
                LOCALE_THROW("length must be positive", "长度必须为正数");
    }

    auto toSi() const->TcpCuboidInfo { // 转国际单位制
        TcpCuboidInfo ret = *this;
        kaanhbot::utility::s_mm2m(ret.center.data(), ret.center.size());
        kaanhbot::utility::s_mm2m(ret.length.data(), ret.length.size());
        return ret;
    }

    auto toUi() const->TcpCuboidInfo { // 转显示
        TcpCuboidInfo ret = *this;
        kaanhbot::utility::s_m2mm(ret.center.data(), ret.center.size());
        kaanhbot::utility::s_m2mm(ret.length.data(), ret.length.size());
        return ret;
    }

    NLOHMANN_DEFINE_TYPE_INTRUSIVE(TcpCuboidInfo, center, length, tool)
};

struct TcpSphereInfo {
    std::array<double, 3> center{0,0,0};
    double radius{1};
    int tool{0};

    auto check() const->void {
        if (radius <= 0) LOCALE_THROW("radius must be positive", "半径必须为正数");
    }

    auto toSi() const->TcpSphereInfo { // 转国际单位制
        TcpSphereInfo ret = *this;
        kaanhbot::utility::s_mm2m(ret.center.data(), ret.center.size());
        kaanhbot::utility::s_mm2m(&ret.radius, 1);
        return ret;
    }

    auto toUi() const->TcpSphereInfo { // 转显示
        TcpSphereInfo ret = *this;
        kaanhbot::utility::s_m2mm(ret.center.data(), ret.center.size());
        kaanhbot::utility::s_m2mm(&ret.radius, 1);
        return ret;
    }

    NLOHMANN_DEFINE_TYPE_INTRUSIVE(TcpSphereInfo, center, radius, tool)
};

class AreaShaper {
public:
    virtual auto shape() const noexcept->AreaShape = 0;
    virtual auto checkCollide(const AreaShaper &shaper) const->CollideType = 0;

public:
    AreaShaper() = default;
    virtual ~AreaShaper() = default;
};

class Cuboid : public AreaShaper {
public:
    auto shape() const noexcept->AreaShape override { return AreaShape::kCuboid; }
    auto checkCollide(const AreaShaper &shaper) const->CollideType override;

    // 如wobj为-1，则由子类给出默认行为
    virtual auto cell(int wobj=-1) const->CuboidCell { return cell_; }
    virtual auto setCell(const CuboidCell &cell)->void { cell_ = cell; }

protected:
    CuboidCell cell_;

public:
    Cuboid() = default;
    Cuboid(const CuboidCell &cell) : cell_(cell) {}
    virtual ~Cuboid() = default;
};

class Sphere : public AreaShaper {
public:
    auto shape() const noexcept->AreaShape override { return AreaShape::kSphere; }
    auto checkCollide(const AreaShaper &shaper) const->CollideType override;

    // 如wobj为-1，则由子类给出默认行为
    virtual auto cell(int wobj=-1) const->SphereCell { return cell_; }
    virtual auto setCell(const SphereCell &cell)->void { cell_ = cell; }

protected:
    SphereCell cell_;

public:
    Sphere() = default;
    Sphere(const SphereCell &cell) : cell_(cell) {}
    virtual ~Sphere() = default;
};

class UnitCuboid : public Cuboid {
public:
    auto info()->UnitCuboidInfo& { return info_; }
    auto info() const->const UnitCuboidInfo& { return const_cast<UnitCuboid*>(this)->info(); }
    auto resetInfo(const UnitCuboidInfo &info)->void { info_ = info; }

    auto cell(int wobj=-1) const->CuboidCell override;

public:
    auto touchUp(const UnitCuboidInfo &info)->void;
    auto manualSet(const CuboidCell &cell)->void;

private:
    UnitCuboidInfo info_;
};

class UnitSphere : public Sphere {
public:
    auto info()->UnitSphereInfo& { return info_; }
    auto info() const->const UnitSphereInfo& { return const_cast<UnitSphere*>(this)->info(); }
    auto resetInfo(const UnitSphereInfo &info)->void { info_ = info; }

    auto cell(int wobj=-1) const->SphereCell override;

public:
    auto touchUp(const UnitSphereInfo &info)->void;
    auto manualSet(const SphereCell &cell)->void;

private:
    UnitSphereInfo info_;
};

class TcpCuboid : public Cuboid {
public:
    auto info()->TcpCuboidInfo& { return info_; }
    auto info() const->const TcpCuboidInfo& { return const_cast<TcpCuboid*>(this)->info(); }
    auto resetInfo(const TcpCuboidInfo &info)->void { info_ = info; }

    auto cell(int wobj=-1) const->CuboidCell override;

    auto manualSet(const TcpCuboidInfo &info)->void;

private:
    using Cuboid::setCell;

private:
    TcpCuboidInfo info_;
};

class TcpSphere : public Sphere {
public:
    auto info()->TcpSphereInfo& { return info_; }
    auto info() const->const TcpSphereInfo& { return const_cast<TcpSphere*>(this)->info(); }
    auto resetInfo(const TcpSphereInfo &info)->void { info_ = info; }

    auto cell(int wobj=-1) const->SphereCell override;

    auto manualSet(const TcpSphereInfo &info)->void;

private:
    using Sphere::setCell;

private:
    TcpSphereInfo info_;
};

class AreaUnit {
public:
    auto unitShaper()->AreaShaper&;
    auto unitShaper() const->const AreaShaper& { return const_cast<AreaUnit*>(this)->unitShaper(); }
    auto resetUnitShaper(AreaShaper *shaper)->void;
    
    auto tcpShaper()->AreaShaper&;
    auto tcpShaper() const->const AreaShaper& { return const_cast<AreaUnit*>(this)->tcpShaper(); }
    auto resetTcpShaper(AreaShaper *shaper)->void;

    auto rtUpdate()->void;

    auto captured() const noexcept->bool;

public:
    auto active() const->bool;
    auto resetActive(bool active)->void;
    auto control() const->bool;
    auto resetControl(bool control)->void;
    auto type() const->AreaType;
    auto resetType(AreaType type)->void;

private:
    struct Imp;
    aris::core::ImpPtr<Imp> imp_;

public:
    AreaUnit();
    ~AreaUnit();

    KAANH_DELETE_BIG_FOUR(AreaUnit)
};

void to_json(nlohmann::json& j, const AreaUnit& unit);

}   // namespace kaanhbot::area

#endif  // KAANHBOT_AREA_UNIT_HPP_
