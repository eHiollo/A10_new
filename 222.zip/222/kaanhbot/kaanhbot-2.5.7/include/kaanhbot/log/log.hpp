#ifndef KAANHBOT_LOG_LOG_HPP_
#define KAANHBOT_LOG_LOG_HPP_

#include <memory>

#include "kaanh/module/middle_module.hpp"
#include "kaanh/general/macro.hpp"
#include "kaanhbot_lib_export.h"

namespace kaanhbot::log {

class KAANHBOT_API Log : public kaanh::module::MiddleModule {
public:
    auto virtual init()->void override;

    auto virtual execute(const std::string &str, std::function<void(std::string)> send_ret) noexcept->std::pair<std::string, std::string> override;

    auto path() const noexcept->const std::string&;

    auto resetPath(const std::string &path) noexcept->void;
    
private:
    struct Imp;
    std::unique_ptr<Imp> imp_;

public:
    Log();
    ~Log();
    KAANH_DELETE_BIG_FOUR(Log)
};

}   // namespace kaanhbot::log


#endif  // KAANHBOT_LOG_LOG_HPP_