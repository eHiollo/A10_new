#ifndef KAANHBOT_SEMAPHORE_SEMA_HPP_
#define KAANHBOT_SEMAPHORE_SEMA_HPP_

#include <string>
#include <functional>
#include <memory>

#include "aris/core/object.hpp"
#include "kaanh/general/macro.hpp"
#include "kaanhbot_lib_export.h"

namespace kaanhbot::semaphore {

template<class Val>
class KAANHBOT_API Sema {
public:
    virtual auto isInput() const->bool = 0;
    virtual auto isOutput() const->bool { return !isInput(); }
    virtual auto val() const->Val { return ATOMIC_LOAD(val_); }

    auto name() const->const std::string& { return name_; }
    auto setName(const std::string &name)->void { name_ = name; }

private:
    std::string name_;

protected:
    std::atomic<Val> val_{};

public:
    Sema(const std::string &name="") : name_(name) {}
    virtual ~Sema() = default;
};

template<class Val>
class KAANHBOT_API InputSema : public Sema<Val> {
public:
    auto isInput() const->bool override { return true; }

    virtual auto rtCollect()->void = 0;
    virtual auto rtExecuteAfterCollect()->void {}

public:
    InputSema(const std::string &name="") : Sema<Val>(name) {}
    virtual ~InputSema() = default;
};

template<class Val>
class KAANHBOT_API OutputSema : public Sema<Val> {
public:
    auto isInput() const->bool override { return false; }

    virtual auto setVal(const Val &val)->void { ATOMIC_STORE(Sema<Val>::val_, val); }
    virtual auto rtExport()->void = 0;
    virtual auto rtExecutebeforeExport()->void {}

public:
    OutputSema(const std::string &name="") : Sema<Val>(name) {}
    virtual ~OutputSema() = default;
};

// class KAANHBOT_API ActualBoolInputSema : public InputSema<bool> {
// public:
//     virtual auto rtCollect()->void override;

//     auto canChangeBinded() const->bool { return can_change_binded_; }
//     auto setCanChangeBinded(bool can_change_binded)->void { can_change_binded_ = can_change_binded; }

//     auto binded() const->bool { return ATOMIC_LOAD(binded_); }
//     auto setBinded(bool binded)->void { ATOMIC_STORE(binded_, binded); }

//     auto groupId() const->int { return ATOMIC_LOAD(group_id_); }
//     auto setGroupId(int group_id)->void { ATOMIC_STORE(group_id_, group_id); }

//     auto channelId() const->int { return ATOMIC_LOAD(channel_id_); }
//     auto setChannelId(int channel_id)->void { ATOMIC_STORE(channel_id_, channel_id); }

// private:
//     bool can_change_binded_{true};
//     std::atomic_bool binded_{false};
//     std::atomic_int32_t group_id_{-1};
//     std::atomic_int32_t channel_id_{-1};

// public:
//     ActualBoolInputSema(const std::string &name="") : InputSema<bool>(name) {}
//     virtual ~ActualBoolInputSema() = default;
// };

// class KAANHBOT_API ActualBoolOutputSema : public OutputSema<bool> {
// public:
//     virtual auto rtExport()->void override;

//     auto canChangeBinded() const->bool { return can_change_binded_; }
//     auto setCanChangeBinded(bool can_change_binded)->void { can_change_binded_ = can_change_binded; }

//     auto binded() const->bool { return ATOMIC_LOAD(binded_); }
//     auto setBinded(bool binded)->void { ATOMIC_STORE(binded_, binded); }

//     auto groupId() const->int { return ATOMIC_LOAD(group_id_); }
//     auto setGroupId(int group_id)->void { ATOMIC_STORE(group_id_, group_id); }

//     auto channelId() const->int { return ATOMIC_LOAD(channel_id_); }
//     auto setChannelId(int channel_id)->void { ATOMIC_STORE(channel_id_, channel_id); }

// private:
//     bool can_change_binded_{true};
//     std::atomic_bool binded_{false};
//     std::atomic_int32_t group_id_{-1};
//     std::atomic_int32_t channel_id_{-1};

// public:
//     ActualBoolOutputSema(const std::string &name="") : OutputSema<bool>(name) {}
//     virtual ~ActualBoolOutputSema() = default;
// };

}   // namespace kaanhbot::semaphore

#endif  // KAANHBOT_SEMAPHORE_SEMA_HPP_
