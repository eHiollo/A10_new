#ifndef KAANHBOT_SEMAPHORE_SEMA_MANAGER_
#define KAANHBOT_SEMAPHORE_SEMA_MANAGER_

#include "kaanh/module/middle_module.hpp"
#include "kaanhbot/semaphore/sema.hpp"
#include "kaanhbot_lib_export.h"

namespace kaanhbot::semaphore {

class KAANHBOT_API SemaManager : public kaanh::module::MiddleModule {
public:
    auto init()->void override;
    auto execute(const std::string &str, std::function<void(std::string)> send_ret) noexcept->std::pair<std::string, std::string> override;
    
    auto boolInputSemaPool()->aris::core::PointerArray<InputSema<bool>>&;
    auto boolInputSemaPool() const->const aris::core::PointerArray<InputSema<bool>>&;
    auto resetBoolInputSemaPool(aris::core::PointerArray<InputSema<bool>> *pool);

    auto boolOutputSemaPool()->aris::core::PointerArray<OutputSema<bool>>&;
    auto boolOutputSemaPool() const->const aris::core::PointerArray<OutputSema<bool>>&;
    auto resetBoolOutputSemaPool(aris::core::PointerArray<OutputSema<bool>> *pool);

    auto intInputSemaPool()->aris::core::PointerArray<InputSema<int>>&;
    auto intInputSemaPool() const->const aris::core::PointerArray<InputSema<int>>&;
    auto resetIntInputSemaPool(aris::core::PointerArray<InputSema<int>> *pool);

    auto intOutputSemaPool()->aris::core::PointerArray<OutputSema<int>>&;
    auto intOutputSemaPool() const->const aris::core::PointerArray<OutputSema<int>>&;
    auto resetIntOutputSemaPool(aris::core::PointerArray<OutputSema<int>> *pool);


    auto floatOutputSemaPool()->aris::core::PointerArray<OutputSema<float>>&;
    auto floatOutputSemaPool() const->const aris::core::PointerArray<OutputSema<float>>&;
    auto resetFloatOutputSemaPool(aris::core::PointerArray<OutputSema<float>> *pool);

    auto rtCollect()->void;
    auto rtExport()->void;

    static auto instanceInCs()->SemaManager&;

private:
    struct Imp;
    aris::core::ImpPtr<Imp> imp_;

public:
    SemaManager();
    ~SemaManager();
};
    
}   // namespace kaanhbot::semaphore

#endif  // KAANHBOT_SEMAPHORE_SEMA_MANAGER_

