#ifndef CONVEYOR_MANAGER_HPP_
#define CONVEYOR_MANAGER_HPP_

#include "kaanh/module/middle_module.hpp"
#include "kaanh/general/macro.hpp"
#include "kaanhbot_lib_export.h"
#include "conveyor.hpp"
#include "aris.hpp"
#include "camera.hpp"
#include <vector>
#include <queue>
namespace kaanhbot::package
{

class GrabData
{
public:
    double x{0},y{0},z{0},c{0},pos{0};

};




class KAANHBOT_API ConveyorManager : public kaanh::module::MiddleModule 
{
public:
    auto virtual init()->void;
    auto virtual execute(const std::string &str, std::function<void(std::string)> send_ret) noexcept->std::pair<std::string, std::string> override;
    static auto instanceInCs()->ConveyorManager&;

public:
    ConveyorManager();
    ~ConveyorManager();

    auto start(int con_id)->void;
    auto stop(int con_id)->void;
    auto isRunnig()-> bool;
    auto conveyorPool()->aris::core::PointerArray<Conveyor>&;
    auto conveyorPool() const->const aris::core::PointerArray<Conveyor>& { return const_cast<ConveyorManager*>(this)->conveyorPool(); }
    auto resetConveyorPool(aris::core::PointerArray<Conveyor> *pool)->void;

    auto cameraClientPool()->aris::core::PointerArray<Camera>&;
    auto cameraClientPool() const->const aris::core::PointerArray<Camera>& { return const_cast<ConveyorManager*>(this)->cameraClientPool(); }
    auto resetCameraClientPool(aris::core::PointerArray<Camera> *pool)->void;

    auto addDataToGrabQueue(const GrabData& data,const std::string name = "con0",const int queue_id = -1) ->void;
    auto addDataToMissQueue(const GrabData& data,const std::string name = "con0",const int queue_id = -1)->void;
    auto delDataFromGrabQueue(const std::string name = "con0",const int queue_id = -1) ->void;
    auto getDataFromGrabQueue(const std::string name = "con0",const int queue_id = -1)->GrabData;
    auto grabQueue()-> std::vector<std::list<GrabData>>&;
    auto missQueue()-> std::vector<std::list<GrabData>>&;

    // 去重
    auto setTolerance(double val)->void;
    auto getTolerance()->const double;
    
    // -1：超出抓取区域   0:可以抓取   1:还未进入抓取区域
    auto isCatch(const int con_id,const int queue_id)->int;
    auto queueSize()->const aris::Size;
    auto setQueueSize(const aris::Size size)->void;

    auto add_miss_num()->void;
    auto clear_miss_num()->void;
    auto miss_num()->aris::Size;

    auto add_photo_num()->void;
    auto clear_photo_num()->void;
    auto photo_num()->aris::Size;

    auto add_catch_num()->void;
    auto clear_catch_num()->void;
    auto catch_num()->aris::Size;

    auto clear_count()->void;

    KAANH_DELETE_BIG_FOUR(ConveyorManager)

private:
    struct Imp;
    std::unique_ptr<Imp> imp_;
};



}   

#endif 
