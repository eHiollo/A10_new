#ifndef CONVEYOR_HPP_
#define CONVEYOR_HPP_

#include "kaanh/module/middle_module.hpp"
#include "kaanh/general/macro.hpp"
#include "kaanhbot_lib_export.h"
#include "aris.hpp"
namespace kaanhbot::package
{

enum class ConveyorType : int
{
    kNone = 0,
    kPrismatic,
    kRevolute
};

NLOHMANN_JSON_SERIALIZE_ENUM(ConveyorType, {{ConveyorType::kNone, "None"},
                                            {ConveyorType::kPrismatic, "Prismatic"},
                                            {ConveyorType::kRevolute, "Revolute"}})

class KAANHBOT_API ConveyorInfo
{
public:
    std::string name = "con0";
    ConveyorType type{ConveyorType::kNone};
    int motor_id = -1;
    bool active = false;
    int wobj = -1;
    int tool = -1;
    double min_x=0,max_x=0,min_y=0,max_y=0;
    double start_x=0,start_y=0,end_x=0,end_y=0;
    // 编码器
    double pulse = 0;
public:


    auto check() const ->void 
    {
        auto& model = dynamic_cast<aris::dynamic::MultiModel&>(aris::server::ControlServer::instance().model());
        if (!active){ LOCALE_THROW("Conveyor is not enable","传动带未启用");}
        if (type == ConveyorType::kNone){LOCALE_THROW("Conveyor type is none","未知的传动带类型");            }
        if (motor_id < model.inputPosSize()) LOCALE_THROW("Can not control motor of robot", "不能选择控制机器人的电机");
    }
    
    NLOHMANN_DEFINE_TYPE_INTRUSIVE(ConveyorInfo, name, motor_id, type, active,wobj,tool,min_x, max_x,min_y,max_y,start_x,start_y,end_x,end_y,pulse)
};

class KAANHBOT_API Conveyor
{

public:
    Conveyor(/* args */);
    ~Conveyor();
    auto wobj() -> int;
    auto setWobj(int wobj) -> void;


    auto vel() -> double;
    auto setVel(const double vel) -> void;

    auto tool() -> int;
    auto setTool(int tool) -> void;

    auto name() -> const std::string;
    auto setName(const std::string name) -> void;

    auto motor()->aris::control::EthercatMotor*;
    auto setMotor(aris::control::EthercatMotor* motor)->void;

    auto conveyorInfo() -> ConveyorInfo &;
    auto setConveyorInfo(ConveyorInfo info) -> void;

    auto start() -> void;
    auto stop() -> void;
    auto isRuning() -> bool;

    auto isSync() ->bool;
    auto setSync(bool active) ->void;

    auto resetFollower(aris::plan::MoveFollower* follower)->void;
    auto follower()->aris::plan::MoveFollower&;

    ARIS_DECLARE_BIG_FOUR_NOEXCEPT(Conveyor);

private:
    struct Imp;
    std::unique_ptr<Imp> imp_;
};

}

#endif
