#ifndef CAMERA_HPP_
#define CAMERA_HPP_

#include "kaanh/module/middle_module.hpp"
#include "kaanh/general/macro.hpp"
#include "kaanhbot_lib_export.h"
#include "aris.hpp"
#include "kaanh/protocol/modbus_tcp_client.hpp"
#include "kaanhbot/io/io_channel.hpp"
using namespace kaanh::protocol;

namespace kaanhbot::package
{

enum class CameraTrigType : int
{
    kNone = 0,
    kDistance,
    kTime,
    kInput
};

NLOHMANN_JSON_SERIALIZE_ENUM(CameraTrigType, {{CameraTrigType::kNone, "None"},
                                                {CameraTrigType::kDistance, "Distance"},
                                                {CameraTrigType::kTime, "Time"},
                                                {CameraTrigType::kInput, "Input"}})


enum class CameraConnectType : int
{
    kNone = 0,
    kModbusTcpServer,
    kModbusTcpClient,
    kTcpServer,
    kTcpClient
};

NLOHMANN_JSON_SERIALIZE_ENUM(CameraConnectType, {{CameraConnectType::kNone, "None"},
                                                {CameraConnectType::kModbusTcpServer, "ModbusTcpServer"},
                                                {CameraConnectType::kModbusTcpClient, "ModbusTcpClient"},
                                                {CameraConnectType::kTcpServer, "TcpServer"},
                                                {CameraConnectType::kTcpClient, "TcpClient"}})

class KAANHBOT_API CameraInfo
{
public:
    std::string ip = "127.0.0.1";
    int port{502};

    // 触发方式
    CameraTrigType trig_type{CameraTrigType::kTime};
    CameraConnectType connect_type{CameraConnectType::kModbusTcpServer};
    int trig_io_id = -1;
    double trig_distance = -1;
    double trig_time = 0;

public:

    auto check() const ->void 
    {

        if (trig_time < 0) { LOCALE_THROW("Trig time is can not small 0","触发时间不能小于0");};
        if (trig_type == CameraTrigType::kNone) { LOCALE_THROW("Trig type is none","未知的触发类型");};
        if (connect_type == CameraConnectType::kModbusTcpServer) { LOCALE_THROW("Connect type is none","未知的连接类型");};
        if (trig_distance < 0) LOCALE_THROW("Trig distance is can not small 0", "触发距离不能小于0");
    }
    
    NLOHMANN_DEFINE_TYPE_INTRUSIVE(CameraInfo, ip, port, trig_type, connect_type,trig_io_id, trig_distance,trig_time)
};

class KAANHBOT_API Camera
{

public:

    auto init()->void;
    auto parser()->aris::core::CommandParser&;
    auto cameraInfo()->const CameraInfo&;
    auto setCameraInfo(const CameraInfo info)->void;

    auto ip()->const std::string&;
    auto setIp(const std::string ip)->void;

    auto photoFlag()->const bool;
    auto setPhotoFlag(const bool flag)->void;

    auto calibFlag()->const bool;
    auto setCalibFlag(const bool flag)->void;

    auto isNeedTrig()->const bool;
    auto setNeedTrig(const bool flag)->void;

    auto iOChennel()-> kaanhbot::io::InputChannel<bool>*;
    auto setIoChennel(kaanhbot::io::InputChannel<bool>* channel)->void;

    auto port()->const int&;
    auto setPort(const int port)->void;

    auto modbusTcpClient()-> ModbusTcpClient&;
    auto setModbusTcpClient(ModbusTcpClient* c)->void;
    auto socketTcpClient()-> aris::core::Socket&;
    auto setSocketTcpClient(aris::core::Socket* client)->void;
    auto socketTcpServer()-> aris::core::Socket&;
    auto setSocketTcpServer(aris::core::Socket* server)->void;

    auto modbusTcpClientConnect()-> void;
    auto modbusTcpClientStop()->void;

    auto netIsWork()->bool;
    auto isTrig()->bool;
    auto startNet()->void;
    auto stopNet()->void;


    auto threadIsStart()-> bool;
    auto startThread()->void;

    Camera();
    ~Camera();
private:
    
    struct Imp;
    std::unique_ptr<Imp> imp_;
    
};


}   

#endif 
