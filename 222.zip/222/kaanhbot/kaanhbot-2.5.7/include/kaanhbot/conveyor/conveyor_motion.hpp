#ifndef CONVEYOR_MOTION_HPP_
#define CONVEYOR_MOTION_HPP_

#include "aris.hpp"
#include "kaanh/multi_motion/motion_plan.hpp"
#include "kaanhbot_lib_export.h"

namespace kaanhbot::package
{

enum PickingState {
    FOLLOW_WOBJ,
    PICKING,
    LEAVE_WOBJ,
    Waiting
};

class KAANHBOT_API MoveConveyor :public aris::core::CloneObject<MoveConveyor,aris::plan::Plan>
{

public:

    auto virtual prepareNrt()->void override;
    auto virtual executeRT()->int override;
    auto virtual collectNrt()->void override;

    explicit MoveConveyor (const std::string &name = "MoveConveyor");
    MoveConveyor(const MoveConveyor &other);
    virtual ~MoveConveyor ();
private:
    struct Imp;
    aris::core::ImpPtr<Imp> imp_; 
};

// 支持多线程但不支持多模型
class KAANHBOT_API ConveyorFastCatch :public aris::core::CloneObject<ConveyorFastCatch,kaanh::multi_motion::MoveCartBase>
{

public:

    auto virtual prepareNrt()->void override;
    auto virtual executeRT()->int override;

    explicit ConveyorFastCatch (const std::string &name = "ConveyorFastCatch");
    ConveyorFastCatch(const ConveyorFastCatch &other);
    virtual ~ConveyorFastCatch ();
private:
    struct Imp;
    aris::core::ImpPtr<Imp> imp_; 
};

class KAANHBOT_API SyncStop : public aris::core::CloneObject<SyncStop, aris::plan::Plan>
{
public:
    auto virtual prepareNrt()->void override;
    explicit SyncStop(const std::string &name = "sync_stop");
};

}   

#endif 
