#ifndef KAANHBOT_PACKAGE_PKG_MANAGER_HPP_
#define KAANHBOT_PACKAGE_PKG_MANAGER_HPP_

#include <memory>

#include "kaanh/module/middle_module.hpp"
#include "kaanhbot_lib_export.h"

namespace kaanhbot::package {

class KAANHBOT_API PkgManager : public kaanh::module::MiddleModule {
public:
    using PkgInitCbk = std::function<void(void)>;
public:
    auto virtual init()->void override;

    auto virtual execute(const std::string &str, std::function<void(std::string)> send_ret) noexcept->std::pair<std::string, std::string> override;

    auto pkgs() const->std::string;
    auto resetPkgs(const std::string &pkgs)->void;

    auto allPkgs() const noexcept->const std::vector<std::string>&;
    
    static auto registerPgkInitCbk(const std::string &pkg, PkgInitCbk cbk)->void;
    static auto hasPkgInitCbk(const std::string &pkg) noexcept->bool;
    static auto pkgInitCbk(const std::string &pkg) noexcept->PkgInitCbk;
    static auto allPkgInitCbks() noexcept->std::map<std::string, PkgInitCbk>;

    static auto instanceInCs()->PkgManager&;

private:
    struct Imp;
    std::unique_ptr<Imp> imp_;

    static std::map<std::string, PkgInitCbk> init_cbks_;

public:
    PkgManager();
    ~PkgManager();
    KAANH_DELETE_BIG_FOUR(PkgManager)
};

}   // namespace kaanhbot::package

#endif  // KAANHBOT_PACKAGE_PKG_MANAGER_HPP_
