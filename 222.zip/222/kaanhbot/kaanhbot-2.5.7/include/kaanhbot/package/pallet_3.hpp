#ifndef KAANHBOT_PACKAGE_PALLET_3_HPP_
#define KAANHBOT_PACKAGE_PALLET_3_HPP_
#include <aris.hpp>
#include "kaanh/module/middle_module.hpp"
#include "kaanh/general/macro.hpp"
#include "kaanh/general/general.hpp"
#include "kaanhbot_lib_export.h"
namespace kaanhbot::package {

//三点法  层高输入
//四点法  层高输入
//五点法
//矩形 平行四边形 弧形   S型  N型
enum class  PalletType{
    kRectangleS=1, //矩形 首尾相接S
    kRectangleN=2, //矩形 N形从行首开始
    kCircleS=3,     //圆形S
    kCircleN=4,     //圆形N
    kCamberS=5,     //弧形S
    kCamberN=6      //弧形N
};
enum class HightType{
    kSingle=1, //单层高
    kMultiple=2    //总层高
};

NLOHMANN_JSON_SERIALIZE_ENUM(PalletType, {
    {PalletType::kRectangleS, "RectangleS"},
    {PalletType::kRectangleN, "RectangleN"},
    {PalletType::kCircleS, "CircleS"},
    {PalletType::kCircleN, "CircleN"},
    {PalletType::kCamberS, "CamberS"},
    {PalletType::kCamberN, "CamberN"}
})


NLOHMANN_JSON_SERIALIZE_ENUM(HightType, {
    {HightType::kSingle, "Single"},
    {HightType::kMultiple, "Multiple"}
})

//码垛数据
// struct PalletInfo {
//     // basic
//     std::string name;
//     int ee_id;
//     bool auto_save;

//     // stack
//     PalletType type;
//     int row, column, layer;
//     std::array<std::vector<std::vector<double>>, 5> robot_targets{};
//     HightType pallet_height;

//     // shield
//     std::vector<std::vector<std::array<int, 2>>> shield_points{};

//     NLOHMANN_DEFINE_TYPE_INTRUSIVE(PalletInfo, name, ee_id, auto_save, type, row, column, layer, robot_targets, pallet_height, shield_points)
// };

class KAANHBOT_API PalletData{
public:
    PalletData();
    PalletData(const std::string & pltname);
    ~PalletData();

    //公共
    auto check()->void;


    auto getpalletTotalCounts()->int;
    auto setCurIndex(int serial_num)->void;
    auto getCurIndex()->int;
    
    auto setName(const std::string&name)->void;
    auto getName()const->std::string;
    auto setEeId(const int& ee_id)->void;
    auto getEeId()const->int;
    auto setIsPowerOffHold(bool is_save)->void;
    auto getIsPowerOffHold()->bool;

    //矩形
    auto initPallet()->void;
    auto getNextPos()->std::vector<std::pair<std::vector<double>,std::array<int,4>>>;
    auto setShieldPoints(const std::vector<std::array<int,3>> shield_points)->void;
    auto getShieldPoints()->std::vector<std::array<int,3>>;
    auto getPalletPos(const std::array<int,3> & coordinate)->std::vector<std::pair<std::vector<double>,std::array<int,4>>>;
    auto getXOffset()->std::vector<std::vector<double>>;
    auto getYOffset()->std::vector<std::vector<double>>;
    auto getZOffset()->std::vector<std::vector<double>>;
    auto coorToId(std::array<int,3> coor) ->int;
    //圆形
    auto initC()->void;//初始化圆心和半径
    auto getCenter()->std::array<double,3>;//获取圆心
    auto getNormalVec()->std::array<double,3>;//获取法向量
    auto getRadius()->double;//获取半径
    auto getAngle()->double;//获取总旋转角度
    //圆弧形偏移量
    auto getCOffset(bool isclockwise)->std::vector<std::vector<double>>;
    auto getRotAngle()->double;

    auto getOffsetHeight()->std::vector<std::pair<std::vector<double>,std::array<int,4>>>;
    auto setCoordinateNum(std::array<int,3>coordinate_num)->void;
    auto getCurCoordinate()->std::array<int,3>;
    // 码垛名称
    std::string name_{"pallet_default"};
    // 码垛轨迹类型
    PalletType shape_{PalletType::kRectangleS};
    // 未使用
    HightType hight_type_{HightType::kMultiple};

    //矩形：array[0]是p0(原点), array[1]是px,        array[2]是py,        array[3]是pxy,      array[4]是pz;
    //圆形：array[0]是p0(圆心), array[1]是ps(起始点), array[2]是无,        array[3]是pe(结束点), array[4]是pz;
    //圆弧：array[0]是p0(圆心), array[1]是ps(起始点), array[2]是pt(过渡点), array[3]是pe(结束点), array[4]是pz;
    //点位信息  <末端维数    <         <位置信息，           选解和相位信息>>>      
    std::array<std::vector<std::pair<std::vector<double>,std::array<int,4>>>,5> multipos_;

        
    //屏蔽点   
    std::vector<std::array<int,3>> shield_nums_;
   //有序
    std::set<int> shield_nums_set_{};

    //末端号 目前仅支持单模型单末端情形，默认为0,不能修改
    int ee_id_{0};
    // 跺堆的数量
    int x_num_{1};
    int y_num_{1};
    int z_num_{1};

 
    //运行数据 是否需要断电保持
    bool is_save_{true};

    //当前料号 初始化为0,运行时为1～x*y*z,去除屏蔽点
    int serial_num_{1};

    // 当前正在执行的坐标 初始化为{0,0,0} ，第一次运行时为{1,1,1}
    std::array<int,3> coordinate_num_{0,0,0};
    // 总码垛数量 总数 - 屏蔽数
    int pallet_counts_{0};

    //法向量 非矩形码垛，暂不支持，先不考虑
    std::array<double,3> normalvec_;
    double radius_;
    double angle_;

public:
    NLOHMANN_DEFINE_TYPE_INTRUSIVE(PalletData,name_,shape_,hight_type_,multipos_,ee_id_,
        x_num_,y_num_,z_num_,shield_nums_set_,shield_nums_,is_save_,serial_num_,pallet_counts_);
};

//全局码垛模块
class KAANHBOT_API PalletVar {
public:
    auto getPallet(const std::string& pallet_name)->PalletData&;
private:
    struct Imp;
    std::unique_ptr<Imp> imp_;

public:
    PalletVar();
    virtual ~PalletVar();
    KAANH_DELETE_BIG_FOUR(PalletVar)
};


class KAANHBOT_API Pallet3 : public kaanh::module::MiddleModule {
public:

    auto virtual init()->void override;
    auto virtual execute(const std::string &str, std::function<void(std::string)> send_ret) noexcept->std::pair<std::string, std::string> override;
    static auto instanceInCs()->Pallet3&;

    //返回引用，可以修改
    auto getPallets()->std::map<std::string,PalletData>&;
    auto getPallet(std::string plt_name)->PalletData&;
    auto hasPallet(std::string plt_name) ->bool;
    auto savePallet()->void;
private:

    struct Imp;
    std::unique_ptr<Imp> imp_;

public:
    Pallet3();
    virtual ~Pallet3();
    KAANH_DELETE_BIG_FOUR(Pallet3)
};

}

#endif//#ifndef KAANHBOT_PACKAGE_PALLET_3_HPP_
