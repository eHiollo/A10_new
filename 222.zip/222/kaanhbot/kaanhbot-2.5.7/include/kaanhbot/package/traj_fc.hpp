#ifndef KAANHBOT_PACKAGE_PKG_TRAJ_EXTRA_
#define KAANHBOT_PACKAGE_PKG_TRAJ_EXTRA_
#include <memory>
#include<regex>
#include<iostream>
#include<string.h>
#include<vector>
#include<sstream>
#include<fstream>
#include<utility>
#include<math.h>
#include<atomic>
#include<filesystem>
#include "kaanh/module/middle_module.hpp"
#include "kaanhbot_lib_export.h"

namespace kaanhbot::package {

class KAANHBOT_API Trajfc : public kaanh::module::MiddleModule {
public:
    auto virtual init()->void override;

    auto virtual execute(const std::string &str, std::function<void(std::string)> send_ret) noexcept->std::pair<std::string, std::string> override;

    static auto instanceInCs()->Trajfc&;

private:
    struct Imp;
    std::unique_ptr<Imp> imp_;

public:
    Trajfc();
    ~Trajfc();
    KAANH_DELETE_BIG_FOUR(Trajfc)
};

class trag_extra{
    public:
    trag_extra();
    ~trag_extra();
    auto logtrajextratxt()->void;
    auto splicing(std::string filename1,std::string filename2)->void;
    auto filtrate_fc(std::string,std::string)->void;//根据设置进行筛选
    auto regex_fc(std::string)->bool;
    auto regex_ct(std::string)->bool;
    auto regex_md(std::string)->bool;
    auto setfcrange(std::vector<std::pair<double,double>> fc_range)->void;//设置六维力范围
    auto setx(std::pair<double,double>)->void;//设置六维力范围
    auto sety(std::pair<double,double>)->void;//设置六维力范围
    auto setz(std::pair<double,double>)->void;//设置六维力范围
    auto seta(std::pair<double,double>)->void;//设置六维力范围
    auto setb(std::pair<double,double>)->void;//设置六维力范围
    auto setc(std::pair<double,double>)->void;//设置六维力范围
    auto setcount(int)->void;//设置时间间隔
    auto setmovedist(double)->void;//设置移动距离间隔
    auto setflag(int)->void;

    auto fctrig()->void;//是否打开时间间隔筛选
    auto cttrig()->void;//是否打开力控范围筛选
    auto mdtrig()->void;//是否打开移动距离筛选

    auto checkfc()->bool;//检查六维力是否在范围内

    auto updatebest()->void;//更新最佳点
    auto ptpdist(std::vector<double> &p1,std::vector<double> &p2)->double;//计算最佳点

    auto createproject(std::string,std::string)->void;//生成工程
    private:
    std::atomic<int> flag;
    std::string line;//逐行读取保存数值
    int xcount;//时间间隔
    std::atomic<double> movecount;//已经移动时间间隔
    std::atomic<double> movedist;//移动距离间隔
    std::atomic<double> movetotal;//已经移动的距离
    //   pair<保存的点位，<距离点位的最短距离，最短距离对应的所有数据>>
    std::pair<std::vector<double>,std::pair<double,std::string>> tg_last;//上一目标点
    std::pair<std::vector<double>,std::pair<double,std::string>> tg_now;//现在的目标点
    std::pair<std::vector<double>,std::pair<double,std::string>> tg_next;//下一个目标点
    std::vector<int> vec_t;//保存<当前运动的count,总运动的count>
    std::vector<double> vec_pe;//保存<位姿，工具，工件>
    std::vector<double> vec_pe_last;//上一个点位
    std::vector<double> vec_fc;//保存<六维力>
    std::vector<std::pair<double,double>> fcrange;//六维力的筛选范围
};
trag_extra::trag_extra(){
    fcrange.insert(fcrange.begin(),6,std::make_pair(0.00,999.00));
    //初始最短距离非常大
    tg_last.second.first = 9999.9999;
    tg_last.first.clear();
    tg_now.second.first = 9999.9999;
    tg_now.first.clear();
    tg_next.second.first = 9999.9999;
    tg_next.first.clear();
    flag.store(0);
    movecount.store(0);
    xcount = 1;//默认时间间隔一个count
    movedist.store(0.01);//初始移动距离间隔为0.01
    movetotal.store(0);//初始已移动距离为0
}
trag_extra::~trag_extra(){

}

auto trag_extra::logtrajextratxt()->void{
    if(std::filesystem::exists("./log/trajextract0.txt")){
        for(int i = 1;i<180;++i){
            if(std::filesystem::exists("./log/trajextract" + std::to_string(i) + ".txt"))
                splicing("./log/trajextract0.txt","./log/trajextract" + std::to_string(i) + ".txt");
            else break;
        }
    }
}
auto trag_extra::regex_fc(std::string oneline)->bool{
    std::smatch mat;
    if(std::regex_search(oneline,mat,std::regex{"force\\{(.*)\\}"})){
        vec_fc.clear();
        for(int i = 1; i<mat.size(); ++i){
            std::stringstream ss(mat[i].str());
            double num_fc;
            while(ss >> num_fc){
                vec_fc.push_back(num_fc);
            }
        }
        return true;
    }
    return false;
}
auto trag_extra::regex_ct(std::string oneline)->bool{
    std::smatch mat;
    if(std::regex_search(oneline,mat,std::regex{"t\\{(.*)\\};p"})){
        for(int i = 1; i < mat.size(); ++i){
        std::stringstream ss(mat[i].str());
        int num_t;
        ss >> num_t;
        vec_t[0] = num_t;
        }
        return true;
    }
    return false;
}
auto trag_extra::regex_md(std::string oneline)->bool{
    std::smatch mat;
    if(std::regex_search(oneline,mat,std::regex{"pe\\{(.*)\\};"})){
        vec_pe.clear();
        for(int i = 1; i < mat.size(); ++i){
            std::stringstream ss(mat[i].str());
            std::string num_pe;
            while(ss >> num_pe){
                    vec_pe.push_back(std::stod(num_pe));
            }
        }
        return true;
    }
    return false;
}

auto trag_extra::filtrate_fc(std::string readfile = "./log/trajextract0.txt",std::string writefile = "./pedata.txt")->void{
    std::smatch mat;
    if(flag.load() == 0){
        std::cout << "not set mode" << std::endl;
        return;
    }
    std::ifstream Read(readfile);
    std::ofstream Write(writefile);
    vec_t.resize(2);
    while(std::getline(Read,line)){
    bool ret;//正则提取返回值判断
    if(flag.load() == 1){//力控范围筛选
    ret = std::regex_search(line,mat,std::regex{"mvl:pe\\{(.*)\\}"});
    if(ret){
        if(tg_next.first.size() != 0){//上个指令是否为mvc
            if(tg_last.second.second.size()!=0)
                Write << tg_last.second.second<< std::endl;//tg_last被释放前应该保存的是最佳点位
            if(tg_now.second.second.size()!=0)
                Write << tg_now.second.second<< std::endl;//tg_now被释放前应该保存的是最佳点位
            std::swap(tg_last,tg_next);
            tg_next.first.clear();
        }else if(tg_now.first.size() != 0){//上个指令是否为mvl
            if(tg_last.second.second.size()!=0){
                if(regex_fc(tg_last.second.second)){
                    if(checkfc()){
                        Write << tg_last.second.second<< std::endl; //tg_last被释放前应该保存的是最佳点位
                        tg_last.second.first=999.999;
                        tg_last.first.clear();
                        tg_last.second.second.clear();
                    }
                }

            }
            std::swap(tg_last,tg_now);
        }else if(tg_last.first.size() == 0){//代表为第一个指令
        }else {//不该出现只有tg_last有值
            std::cout << "err!!!!" << std::endl;
        }
        tg_now.first.clear();
        for(int i = 1; i<mat.size(); ++i){
            std::stringstream ss(mat[i].str());
            double num_fc;
            while(ss >> num_fc){
                tg_now.first.push_back(num_fc);
            }
        }
        continue;
    }
    ret = std::regex_search(line,mat,std::regex{"mvc:mid_pe\\{(.*)\\};end_pe\\{(.*)\\}"});
    if(ret){
        if(tg_next.first.size() != 0){//上个指令是否为mvc
            if(tg_last.second.second.size()!=0)
                Write << tg_last.second.second<< std::endl;//tg_last被释放前应该保存的是最佳点位
            if(tg_now.second.second.size()!=0)
                Write << tg_now.second.second<< std::endl;//tg_now被释放前应该保存的是最佳点位
            std::swap(tg_last,tg_next);
           tg_next.first.clear();
           tg_now.first.clear();
        }else if(tg_now.first.size() != 0){//上个指令是否为mvl
            if(tg_last.second.second.size()!=0){
                Write << tg_last.second.second<< std::endl; //tg_last被释放前应该保存的是最佳点位
                tg_last.second.first=999.999;
                tg_last.second.second.clear();
            }
            std::swap(tg_last,tg_now);
            tg_now.first.clear();
        }else if(tg_last.first.size() == 0){//代表为第一个指令
        }else {//不该出现只有tg_last有值
            std::cout << "err!!!!" << std::endl;
        }
        int tgsize = 0;
        for(int i = 1; ret&&i<mat.size(); ++i){
            std::stringstream ss(mat[i].str());
            double num_fc;
            while(ss >> num_fc){
                if(tgsize==0)
                tg_now.first.push_back(num_fc);
                else
                tg_next.first.push_back(num_fc);
            }
            tgsize=tg_now.first.size();
        }
        continue;
    }
    if(regex_fc(line)){
        if(!checkfc()){
            continue;
        }
    }else{}
    if(regex_md(line)){}else{}

    updatebest();
    }
    if(flag.load() == 2){//时间间隔筛选
        if(regex_ct(line)){
            if(vec_t.size() < 2){

            }
            if(vec_t[0] > movecount.load()){
                movecount.store(movecount.load() + xcount);
                Write << line << std::endl;//记录当前点位数据
            }
        }else{

        }
    }
    if(flag.load() == 3){//时间间隔+力控范围筛选
        if(regex_ct(line)){

        }
        if(regex_fc(line)){

        }
        if(vec_t.size()>=2){
            if(vec_t[0] < vec_t[1]){
                movecount.store(xcount);
            }
            if(vec_t[0] > movecount.load() - 0.2*xcount  && vec_t[0] < movecount.load() + 0.2*xcount && checkfc()){
                movecount.store(movecount.load() + xcount);
                vec_t[1] = vec_t[0];
                Write << line << std::endl;//记录当前点位数据
            }else if(vec_t[0] > movecount.load() + 0.2*xcount){
                movecount.store(movecount.load() + 0.4*xcount);
            }

        }

    }
    if(flag.load() == 4){//移动距离筛选
        if(regex_md(line)){
            if(vec_pe_last.size() == vec_pe.size()){
                movetotal.store(ptpdist(vec_pe_last,vec_pe)+movetotal.load());//更新已经移动过的距离
                if(movetotal.load() >= movedist.load()){
                    movetotal.store(0);
                    Write << line << std::endl;//记录当前点位数据
                }

            }
            swap(vec_pe,vec_pe_last);//更新上次点位
        }
    }
    if(flag.load() == 5){//移动距离+力控范围筛选
        if(regex_md(line)){
            if(vec_pe_last.size() == vec_pe.size()){
                movetotal.store(ptpdist(vec_pe_last,vec_pe)+movetotal.load());//更新已经移动过的距离
            }
            swap(vec_pe,vec_pe_last);//更新上次点位
        }
        if(regex_fc(line)){

        }
        if( movedist.load() * 1.15 >= movetotal.load() && movetotal.load() >= movedist.load() * 0.85){
            if(checkfc()){
                movetotal.store(0);
                Write << line << std::endl;//记录当前点位数据
            }else{
            }
        }else if(movetotal.load() >= movedist.load() * 1.15){
            movetotal.store(movedist.load() * 0.85);
        }else{
        }

    }
    }
    //遍历结束，写入最后的最佳点位
    if(flag.load() == 1){
        if(tg_next.first.size() != 0){//上个指令是否为mvc
        if(tg_last.second.second.size()!=0)
             Write << tg_last.second.second << std::endl;//tg_last被释放前应该保存的是最佳点位
        if(tg_now.second.second.size()!=0)
             Write << tg_now.second.second << std::endl;//tg_now被释放前应该保存的是最佳点位
        if(tg_next.second.second.size()!=0)
             Write << tg_next.second.second << std::endl;
        }else if(tg_now.first.size() != 0){//上个指令是否为mvl
        if(tg_last.second.second.size()!=0)
              Write << tg_last.second.second<< std::endl;//tg_last被释放前应该保存的是最佳点位
        if(tg_now.second.second.size()!=0)
              Write << tg_now.second.second<< std::endl;//tg_now被释放前应该保存的是最佳点位
        }else if(tg_last.first.size() == 0){//代表为第一个指令
        }else {//不该出现只有tg_last有值
            std::cout << "err!!!!" << std::endl;
        }
    }
    tg_last.second.first = 9999.9999;
    tg_last.first.clear();
    tg_last.second.second.clear();
    tg_now.second.first = 9999.9999;
    tg_now.first.clear();
    tg_now.second.second.clear();
    tg_next.second.first = 9999.9999;
    tg_next.first.clear();
    tg_next.second.second.clear();
    if(Read){
        Read.close();
    }
    if(Write){
        Write.close();
    }
    std::cout <<"end fc " << std::endl;
}
auto trag_extra::ptpdist(std::vector<double> &p1,std::vector<double> &p2)->double{
     if(p1.size() < 3 || p2.size() < 3)
        return 0;
     double xdist = p1[0] - p2[0];
     double ydist = p1[1] - p2[1];
     double zdist = p1[2] - p2[2];
     return sqrt(xdist*xdist + ydist*ydist + zdist*zdist);
}
auto trag_extra::updatebest()->void{
    if(tg_last.first.size() != 0){
        if(tg_last.second.first > ptpdist(tg_last.first,vec_pe)){
            tg_last.second.first = ptpdist(tg_last.first,vec_pe);
            tg_last.second.second = line;
        }
    }
    if(tg_now.first.size() != 0){
        if(tg_now.second.first > ptpdist(tg_now.first,vec_pe)){
            tg_now.second.first = ptpdist(tg_now.first,vec_pe);
            tg_now.second.second = line;
        }
    }
    if(tg_next.first.size() != 0){
        if(tg_next.second.first > ptpdist(tg_next.first,vec_pe)){
            tg_next.second.first = ptpdist(tg_next.first,vec_pe);
            tg_next.second.second = line;
        }
    }

}


auto trag_extra::checkfc()->bool{
    if(fcrange.size() != 6 || vec_fc.size() != 6){
        std::cout << "fc numbers error!" << std::endl;
        return false;
    }
    for(int i = 0;i < 6;++i){
        double fcmin = fcrange[i].first - fcrange[i].second;
        double fcmax = fcrange[i].first + fcrange[i].second;
        if(vec_fc[i] > fcmax || vec_fc[i] < fcmin){
            return false;
        }
    }
    return true;
}
auto trag_extra::setfcrange(std::vector<std::pair<double,double>> fc_range)->void{
    std::swap(fcrange,fc_range);
}
auto trag_extra::setx(std::pair<double,double> xfc)->void{
    fcrange[0].first = xfc.first;
    fcrange[0].second = xfc.second;
}
auto trag_extra::sety(std::pair<double,double> yfc)->void{
    fcrange[1].first = yfc.first;
    fcrange[1].second = yfc.second;
}
auto trag_extra::setz(std::pair<double,double> zfc)->void{
    fcrange[2].first = zfc.first;
    fcrange[2].second = zfc.second;
}
auto trag_extra::seta(std::pair<double,double> afc)->void{
    fcrange[3].first = afc.first;
    fcrange[3].second = afc.second;
}
auto trag_extra::setb(std::pair<double,double> bfc)->void{
    fcrange[4].first = bfc.first;
    fcrange[4].second = bfc.second;
}
auto trag_extra::setc(std::pair<double,double> cfc)->void{
    fcrange[5].first = cfc.first;
    fcrange[5].second = cfc.second;
}
auto trag_extra::setmovedist(double move_distance)->void{
    movedist = move_distance;
}
auto trag_extra::setcount(int x_count)->void{
    xcount = x_count;
    movecount.store(xcount);
}

auto trag_extra::setflag(int flag_)->void{
    flag.store(flag_);
}

auto trag_extra::createproject(std::string readfile = "./program/",std::string projectname = "project1")->void{
    std::ofstream project_dat;
    std::ofstream project_src;
    std::string pointdata;
    std::smatch mat;
    std::vector<double> RobotTarget;
    std::ifstream myread(readfile);
    project_dat.open(projectname+".dat");
    if(!project_dat){
        std::cout << projectname+".dat" << " doesn't exit" << std::endl;
    }
    project_src.open(projectname+".src");
    if(!project_src){
        std::cout << projectname+".src" << " doesn't exit" << std::endl;
    }
    //dat基本数据先写入
    project_dat << "BOOL fc = false\n";
    project_dat << "Speed v10 = {3,10.000000,180.000000}\n";
    project_dat << "Speed v100 = {10,100.000000,180.000000}\n";
    project_dat << "Speed v1000 = {100,1000.000000,180.000000}\n";
    project_dat << "Speed v2000 = {100,2000.000000,180.000000}\n";
    project_dat << "Speed v50 = {7.5,50.000000,180.000000}\n";
    project_dat << "Speed v500 = {50,500.000000,180.000000}\n";
    project_dat << "Zone z0 = {0.000000,0.000000}\n";
    project_dat << "Zone z10 = {10.000000,10.000000}\n";
    project_dat << "Zone z100 = {100.000000,50.000000}\n";
    project_dat << "Zone z20 = {20.000000,20.000000}\n";
    project_dat << "Zone z50 = {50.000000,30.000000}\n";
    project_dat << "Zone z80 = {80.000000,40.000000}\n";
    //src基本数据先写入
    project_src << "FUNCTION track" + std::to_string(flag.load()) + "\n";

    int j = 0;//点位编号，p0，p1...pj...
    while(std::getline(myread,pointdata)){//写入所有点位
        RobotTarget.clear();
        bool ret = std::regex_search(pointdata,mat,std::regex{"pe\\{(.*)\\};f"});
        if(ret){
            for(int i = 1; i < mat.size(); ++i){
                std::stringstream ss{mat[i].str()};
                double num_pe;
                while(ss >> num_pe){
                RobotTarget.push_back(num_pe);
                }
            }
            std::string onepoint{"RobotTarget p" + std::to_string(j) + " = {"};
            std::string onemvl{"    L <p" + std::to_string(j++) +",v100,z20,o0,fc>"};
            for(auto & pos_num:RobotTarget){
                onepoint = onepoint + std::to_string(pos_num) + ",";
            }
            onepoint[onepoint.size()-1] = '}';
            project_dat << onepoint << "\n";
            project_src << onemvl << "\n";
        }
    }
    std::string offset{"Offset o0 = {"};
    int rb_target_size = RobotTarget.size() - 1;
    if(rb_target_size > 1){
            while( 0 < rb_target_size-- ){
            offset = offset + std::to_string(0) + ',';
        }
        offset[offset.size()-1]='}';
        project_dat << offset << "\n";//根据位姿写入offset
    }
    
    project_src << "END_FUNCTION\n";
    if(project_src){
        project_src.close();
    }
    if(project_dat){
        project_dat.close();
    }

    //std::system(std::string("sudo rm ./log/trajextract*").c_str());
}
auto trag_extra::splicing(std::string filename1,std::string filename2)->void{
    if(std::filesystem::exists(filename1) && std::filesystem::exists(filename2)){
        std::ofstream Write(filename1,std::ios::app);
        std::ifstream Read(filename2);
        std::string line;
        while(getline(Read,line)){
            Write << line << std::endl;
        }
        Write.close();
        Read.close();
        std::system(std::string("sudo rm " + filename2).c_str());
    }else{
        //std::cout << filename1 <<" doesn`t exit" << std::endl;
    }
}


}   // namespace kaanhbot::package

#endif  // KAANHBOT_PACKAGE_PKG_MANAGER_HPP_

