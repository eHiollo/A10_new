/**
 * @file zig_zag_search.hpp
 * @author your name (you@domain.com)
 * @brief 
 * @version 0.1
 * @date 2025-04-01
 * 
 * @copyright Copyright (c) 2025
 * 
 */

#ifndef KAANH_PACKAGE_SCREW_IO_HPP
#define KAANH_PACKAGE_SCREW_IO_HPP

#include "aris.hpp"
#include <kaanh/general/macro.hpp>
#include <kaanh/multi_motion/motion_plan.hpp>
#include <kaanh/package/force_param.hpp>

namespace kaanhbot::motion
{
/**
 * @brief 普通导纳的螺旋运动入孔，用于镶牙套
 * 
 */
class KAANH_API ScrewI :public aris::core::CloneObject<ScrewI,kaanh::multi_motion::MoveCartBase>
{
public:
    auto virtual prepareNrt()->void override;
    auto virtual executeRT()->int override;
    auto virtual collectNrt()->void override;
    explicit ScrewI(const std::string &name = "ScrewI");
    KAANH_DECLARE_BIG_FOUR(ScrewI)
    virtual ~ScrewI();
private:
    struct Imp;
    aris::core::ImpPtr<Imp> imp_;
};
/**
 * @brief 普通导纳的螺旋运动出孔，用于镶牙套
 * 
 */
class KAANH_API ScrewO: public aris::core::CloneObject<ScrewO,kaanh::multi_motion::MoveCartBase>
{
public:
    auto virtual prepareNrt()->void override;
    auto virtual executeRT()->int override;
    auto virtual collectNrt()->void override;
    explicit ScrewO(const std::string &name = "ScrewO");
    KAANH_DECLARE_BIG_FOUR(ScrewO)
    virtual ~ScrewO();
private:
    struct Imp;
    aris::core::ImpPtr<Imp> imp_;
};
/**
 * @brief 带滤波器的螺旋运动，用于镶牙套
 * 
 */
class KAANH_API ScrewIF :public aris::core::CloneObject<ScrewIF,kaanh::multi_motion::MoveCartBase>
{
public:
    auto virtual prepareNrt()->void override;
    auto virtual executeRT()->int override;
    auto virtual collectNrt()->void override;
    explicit ScrewIF(const std::string &name = "ScrewIF");
    KAANH_DECLARE_BIG_FOUR(ScrewIF)
    virtual ~ScrewIF();
private:
    struct Imp;
    aris::core::ImpPtr<Imp> imp_;
};
/**
 * @brief 带速度前馈项的螺旋运动，用于镶牙套
 * 
 */
class KAANH_API ScrewV :public aris::core::CloneObject<ScrewV,kaanh::multi_motion::MoveCartBase>
{
public:
    auto virtual prepareNrt()->void override;
    auto virtual executeRT()->int override;
    auto virtual collectNrt()->void override;
    explicit ScrewV(const std::string &name = "ScrewV");
    KAANH_DECLARE_BIG_FOUR(ScrewV)
    virtual ~ScrewV();
private:
    struct Imp;
    aris::core::ImpPtr<Imp> imp_;
};

/**
 * @brief 带速度前馈项的螺旋运动，用于螺旋退刀
 * 
 */
class KAANH_API ScrewVO :public aris::core::CloneObject<ScrewVO,kaanh::multi_motion::MoveCartBase>
{
public:
    auto virtual prepareNrt()->void override;
    auto virtual executeRT()->int override;
    auto virtual collectNrt()->void override;
    explicit ScrewVO(const std::string &name = "ScrewVO");
    KAANH_DECLARE_BIG_FOUR(ScrewVO)
    virtual ~ScrewVO();
private:
    struct Imp;
    aris::core::ImpPtr<Imp> imp_;
};


}
#endif