#ifndef KAANHBOT_MOTION_MOVE_FIND_HPP_
#define KAANHBOT_MOTION_MOVE_FIND_HPP_


#include <aris/plan/plan.hpp>
#include "kaanh/multi_motion/motion_plan.hpp"
#include <stdlib.h>
#include "kaanh/general/macro.hpp"
#include "kaanhbot_lib_export.h"

using namespace aris::plan;


namespace kaanhbot::motion{

    class KAANHBOT_API MoveLFind :public aris::core::CloneObject<MoveLFind,kaanh::multi_motion::MoveCartBase>
    {
    public:
        auto virtual prepareNrt()->void override;
        auto virtual executeRT()->int override;
        explicit MoveLFind(const std::string &name = "MoveLFind");
        //MoveLFind(const MoveLFind& other);
        virtual ~MoveLFind();
        KAANH_DECLARE_BIG_FOUR(MoveLFind)
    private:
        struct Imp;
        aris::core::ImpPtr<Imp> imp_;
    };

}

#endif // KAANHBOT_MOTION_MOVE_FIND_HPP_
