#ifndef KAANHBOT_AUTHORITY_AUTHORITY_HPP_
#define KAANHBOT_AUTHORITY_AUTHORITY_HPP_

#include <memory>
#include <string_view>

#include "kaanh/module/middle_module.hpp"
#include "kaanh/general/macro.hpp"
#include "kaanhbot_lib_export.h"

namespace kaanhbot::authority {

enum class NodeType : int {
    kAnd = 0,
    kOr,
    kNot,
    kSymble
};

class NodeBase {
public:
    virtual auto content() const->std::string = 0;
    virtual auto value() const->bool = 0;

    auto nodeType() const->int { return node_type_; }
    auto setNodeType(int node_type)->void { node_type_ = node_type; }
    auto leftChild() const->const std::shared_ptr<NodeBase>& { return left_child_; }
    auto setLeftChild(const std::shared_ptr<NodeBase> &left_child)->void { left_child_ = left_child; }
    auto rightChild() const->const std::shared_ptr<NodeBase>&  { return right_child_; }
    auto setRightChild(const std::shared_ptr<NodeBase> &right_child)->void { right_child_ = right_child; }

private:
    int node_type_{-1};
    std::shared_ptr<NodeBase> left_child_{nullptr};
    std::shared_ptr<NodeBase> right_child_{nullptr};

public:
    NodeBase(int node_type, const std::shared_ptr<NodeBase> &left_child=nullptr, const std::shared_ptr<NodeBase> &right_child=nullptr) {
        node_type_ = node_type;
        left_child_ = left_child;
        right_child_ = right_child;
    }
    virtual ~NodeBase() = default;
};

struct KAANHBOT_API AuthorityRule {
    std::string cmd_;
    bool pass_{true};
    std::string rule_;
    std::string name_;  // 仅供前端使用
    std::string desc_;  // 仅供前端使用
    std::shared_ptr<NodeBase> node_;
};

class KAANHBOT_API Authority : public kaanh::module::MiddleModule {
public:
    using ParseCbk = std::function<std::shared_ptr<NodeBase>(const std::string&)>;

private:
    enum class TokenType : int {
        kAnd = 0,
        kOr,
        kNot,
        kLParenthesis,
        kRParenthesis,
        kSymble
    };

    struct Token {
        TokenType type;
        std::string_view symble; 
    };

    using CIter = std::vector<Token>::const_iterator;

public:
    auto virtual init()->void override;
    auto virtual execute(const std::string &str, std::function<void(std::string)> send_ret) noexcept->std::pair<std::string, std::string> override;

    auto defaultPass() const->bool;
    auto resetDefaultPass(bool default_pass)->void;

    auto whiteList() const->std::string;
    auto resetWhiteList(const std::string &list)->void;

    auto rules() const->std::vector<AuthorityRule>;
    auto resetRules(std::vector<AuthorityRule> rules)->void;

private:
    auto parseRule(const std::string &rule)->std::shared_ptr<NodeBase>;
    auto tokens(std::string_view str)->std::vector<Token>;
    auto parse(CIter b, CIter e)->std::shared_ptr<NodeBase>;

private:
    struct Imp;
    std::unique_ptr<Imp> imp_;

public:
    Authority();
    ~Authority();
    KAANH_DELETE_BIG_FOUR(Authority)
};

}   // namespace kaanhbot::authority

#endif // KAANHBOT_AUTHORITY_AUTHORITY_HPP_
