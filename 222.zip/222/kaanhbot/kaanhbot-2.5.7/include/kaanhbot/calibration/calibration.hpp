#ifndef KAANHBOT_CALIBRATION_CALIBRATION_HPP_
#define KAANHBOT_CALIBRATION_CALIBRATION_HPP_

#include <aris.hpp>
#include "kaanh/module/pgm_controller.hpp"
#include "kaanh/robot/robot.hpp"
#include "kaanh/general/macro.hpp"
#include "kaanh/multi_motion/motion_config.hpp"
#include "kaanh/multi_motion/motion_manager.hpp"
#include "kaanh/robot/robot.hpp"
#include "kaanh/robot/error.hpp"
#include "kaanh/log/log.hpp"

namespace kaanhbot::calibration {

	const double PI = 3.141592653589793;
	auto crossVector(double* a, double* s, double* n)->int;
	auto get_teachpt_data(std::string datastr, double *data, size_t data_size)->int;



class CalibBase :public aris::core::CloneObject<CalibBase,aris::plan::Plan>
{
public:
	explicit CalibBase (const std::string &name = "CalibBase");
	ARIS_DECLARE_BIG_FOUR(CalibBase)
	virtual ~CalibBase ();


	auto virtual getInstance()->void;


	// 全局单利快速索引
	auto multiModel()-> aris::dynamic::MultiModel*; 
	auto pgmCalculator()-> kaanh::program::PgmCalculator*;
	auto robot()-> kaanh::robot::Robot*;
	auto pgmController()-> kaanh::module::PgmController*;   
	auto moveParam()-> kaanh::multi_motion::MoveParam*; 
	auto twManager()-> kaanh::multi_motion::ToolWobjManager*; 
	auto log()-> kaanh::log::Sqlite3Log*; 
	//标定工具时校验 模式 当前选择的是否超限
	auto virtual checkChoosenToolWobj(int ee_id)->int; 
	auto virtual checkTool(int ee_id,int tool_id)->int;
    auto virtual checkHdWobj(int ee_id,int hd_wobj_id)->int;
    auto virtual checkWobj(int ee_id,int wobj_id)->int;
    auto virtual checkExTool(int ee_id,int ex_tool_id)->int;
private:
	struct Imp;
	aris::core::ImpPtr<Imp> imp_; 
};


	//2点-tool标定，基于2点计算工具坐标系相对于法兰的位姿
	class CalibT2P : public aris::core::CloneObject<CalibT2P, CalibBase>
	{
	public:
		auto virtual prepareNrt()->void;
		explicit CalibT2P(const std::string &name = "CalibT2P");
		auto calTcp()->void;
		ARIS_DECLARE_BIG_FOUR(CalibT2P);



	private:
		struct Imp;
		aris::core::ImpPtr<Imp> imp_;
	};

	//3点-Wobj标定，基于3点计算工件坐标系相对于base的位姿
	class CalibW3P : public aris::core::CloneObject<CalibW3P, CalibBase>
	{
	public:
		auto virtual prepareNrt()->void;
		explicit CalibW3P(const std::string &name = "CalibW3P");
		ARIS_DECLARE_BIG_FOUR(CalibW3P)
	private:
		struct Imp;
		aris::core::ImpPtr<Imp> imp_;
	};

	//4点-TCP标定，基于4点计算工具坐标系原点位置
	class CalibT4P : public aris::core::CloneObject<CalibT4P, CalibBase>
	{
	public:
		auto virtual prepareNrt()->void;
		explicit CalibT4P(const std::string &name = "CalibT4P");
		ARIS_DECLARE_BIG_FOUR(CalibT4P)
		auto cal_TCP(double transmatric[64], double tcp[3], double &tcp_error)->int;
		auto tm2RP_4Pt(double tm[64], double *R, double *P)->int;
		auto deltaRP_4Pt(double R[36], double P[12], double * deltaR, double * deltaP)->int;
	private:
		struct Imp;
		aris::core::ImpPtr<Imp> imp_;
	};

	//5点-TCP和Z标定，基于5点计算工具坐标系原点位置及Z轴正方向姿态
	class CalibT5P : public aris::core::CloneObject<CalibT5P, CalibBase>
	{
	public:
		auto virtual prepareNrt()->void;
		explicit CalibT5P(const std::string &name = "CalibT5P");
		ARIS_DECLARE_BIG_FOUR(CalibT5P)
		auto cal_TCP_Z(double transmatric[80], double tcp[3], double &tcp_error, double tcf[9])->int;
		auto tm2RP_5Pt(double tm[80], double *R, double *P)->int;
		auto deltaRP_5Pt(double R[45], double P[15], double * deltaR, double * deltaP)->int;
	private:
		struct Imp;
		aris::core::ImpPtr<Imp> imp_;
	};

	//6点-TCP和TCF的Z轴、Y轴标定，基于6点计算工具坐标系原点位置及Z、Y、X轴正方向姿态
	class CalibT6P : public aris::core::CloneObject<CalibT6P, CalibBase>
	{
	public:
		auto virtual prepareNrt()->void;
		explicit CalibT6P(const std::string &name = "CalibT6P");
		ARIS_DECLARE_BIG_FOUR(CalibT6P)
        auto cal_TCP_TCF(double transmatric[96], double tcp[3], double &tcp_error, double tcf[6])->int;
		auto tm2RP_6Pt(double tm[96], double *R, double *P)->int;
		auto deltaRP_6Pt(double R[54], double P[18], double * deltaR, double * deltaP)->int;
	private:
		struct Imp;
		aris::core::ImpPtr<Imp> imp_;
	};

	//手动设置工具坐标系
	class ManualSetTool : public aris::core::CloneObject<ManualSetTool, CalibBase>
	{
	public:
		auto virtual prepareNrt()->void;
		explicit ManualSetTool(const std::string &name = "ManualSetTool");
	};

	//获取工具坐标系
	class GetTool : public aris::core::CloneObject<GetTool, CalibBase>
	{
	public:
		auto virtual prepareNrt()->void;
		explicit GetTool(const std::string &name = "GetTool");

	};

	//手动设置工件坐标系
	class ManualSetWobj : public aris::core::CloneObject<ManualSetWobj, CalibBase>
	{
	public:
		auto virtual prepareNrt()->void;
		explicit ManualSetWobj(const std::string &name = "ManualSetWobj");
	};

	//获取工件坐标系
	class GetWobj : public aris::core::CloneObject<GetWobj, CalibBase>
	{
	public:
		auto virtual prepareNrt()->void;
		explicit GetWobj(const std::string &name = "GetWobj");
	};
}

#endif //KAANHBOT_CALIBRATION_CALIBRATION_HPP_

