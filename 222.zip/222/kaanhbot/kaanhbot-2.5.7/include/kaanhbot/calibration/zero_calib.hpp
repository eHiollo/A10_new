#ifndef KAANHBOT_CALIBRATION_ZEROCALIB_HPP_
#define KAANHBOT_CALIBRATION_ZEROCALIB_HPP_

#include "aris.hpp"
#include "kaanh/module/middle_module.hpp"
#include "kaanh/algorithm/zero_calibration.hpp"
#include "kaanhbot_lib_export.h"

namespace kaanhbot::calibration {

    class KAANHBOT_API ZeroCalib: public kaanh::module::MiddleModule{
        public:
            auto virtual init()->void override;
            auto virtual execute(const std::string &,std::function<void(std::string)> send_ret) noexcept->std::pair<std::string, std::string> override;
            ZeroCalib();
            ~ZeroCalib();
        private:
            struct  Imp;
            std::unique_ptr<Imp> imp_;
    };
}

#endif //KAANHBOT_CALIBRATION_CALIBRATION_HPP_
