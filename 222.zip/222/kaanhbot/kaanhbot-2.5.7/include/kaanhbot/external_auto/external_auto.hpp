#ifndef KAANHBOT_EXTERNAL_AUTO_EXTERNAL_AUTO_HPP_
#define KAANHBOT_EXTERNAL_AUTO_EXTERNAL_AUTO_HPP_


#include <string>
#include <vector>
#include <atomic>
#include <memory>

#include "aris/core/reflection.hpp"
#include "kaanhbot/semaphore/semaphore.hpp"
#include "kaanhbot/robot/system_sema.hpp"
#include <chrono>

namespace kaanhbot::external_auto {



// class KAANHBOT_API kaanhbot::robot::SystemBoolInputSema : public kaanhbot::robot::SystemBoolInputSema {
// public:
//     auto rtCollect()->void override;
// private:
//     std::atomic_int32_t modbus_readbool_channel_id_{-1};
// public:
//     kaanhbot::robot::SystemBoolInputSema(const std::string &name="") : kaanhbot::robot::SystemBoolInputSema(name) {}
//     virtual ~kaanhbot::robot::SystemBoolInputSema() = default;
// };


// class KAANHBOT_API kaanhbot::robot::SystemBoolOutputSema : public  kaanhbot::robot::SystemBoolOutputSema {
// public:
//     auto rtExport()->void override;
    
//     // auto modbusWriteBoolChannelId() const->int { return ATOMIC_LOAD(modbus_writebool_channel_id_); }
//     // auto setModbusWriteBoolChannelId(int modbus_writebool_channel_id)->void { ATOMIC_STORE(modbus_writebool_channel_id_, modbus_writebool_channel_id); }
// private:
//     std::atomic_int32_t modbus_writebool_channel_id_{-1};//
// public:
//     kaanhbot::robot::SystemBoolOutputSema(const std::string &name="") : kaanhbot::robot::SystemBoolOutputSema(name) {}
//     virtual ~kaanhbot::robot::SystemBoolOutputSema() = default;
// };


//！全局速度
class InputGlobalSpeedSema  : public kaanhbot::robot::SystemIntInputSema {
public:
    auto rtExecuteAfterCollect()->void override;
public:
    InputGlobalSpeedSema(const std::string &name="") :kaanhbot::robot::SystemIntInputSema(name) {}
    ~InputGlobalSpeedSema() = default;
};
    

//!准备就绪状态输出
class OutputReadySema  : public kaanhbot::robot::SystemBoolOutputSema {
public:
    auto rtExecutebeforeExport()->void override;
private:
    std::atomic_bool last_load{false};
public:
    OutputReadySema(const std::string &name="") : kaanhbot::robot::SystemBoolOutputSema(name) {}
    ~OutputReadySema() = default;
};
//!外部使能
class InputExternalEnSema  : public kaanhbot::robot::SystemBoolInputSema {
public:
    auto rtExecuteAfterCollect()->void override;
public:
    InputExternalEnSema(const std::string &name="") :kaanhbot::robot::SystemBoolInputSema(name) {}
    ~InputExternalEnSema() = default;
};

class InputClearSema  : public kaanhbot::robot::SystemBoolInputSema{
public:
    auto rtExecuteAfterCollect()->void override;
public:
    InputClearSema(const std::string &name="") : kaanhbot::robot::SystemBoolInputSema(name) {}
    ~InputClearSema() = default;
};

class InputLoadSema  : public kaanhbot::robot::SystemBoolInputSema{
public:
    auto rtExecuteAfterCollect()->void override;
public:
    InputLoadSema(const std::string &name="") : kaanhbot::robot::SystemBoolInputSema(name) {}
    ~InputLoadSema() = default;
};

class InputStartSema  : public kaanhbot::robot::SystemBoolInputSema{
public:
    auto rtExecuteAfterCollect()->void override;
public:
    InputStartSema(const std::string &name="") :kaanhbot::robot::SystemBoolInputSema(name) {}
    ~InputStartSema() = default;
};

class InputPauseSema  : public kaanhbot::robot::SystemBoolInputSema{
public:
    auto rtExecuteAfterCollect()->void override;
public:
    InputPauseSema(const std::string &name="") :kaanhbot::robot::SystemBoolInputSema(name) {}
    ~InputPauseSema() = default;
};

class InputUnloadSema  : public kaanhbot::robot::SystemBoolInputSema{
public:
    auto rtExecuteAfterCollect()->void override;
public:
    InputUnloadSema(const std::string &name="") :kaanhbot::robot::SystemBoolInputSema(name) {}
    ~InputUnloadSema() = default;
};

class InputProgramResetSema  : public kaanhbot::robot::SystemBoolInputSema{
public:
    auto rtExecuteAfterCollect()->void override;
public:
    InputProgramResetSema(const std::string &name="") :kaanhbot::robot::SystemBoolInputSema(name) {}
    ~InputProgramResetSema() = default;
};

class InputServoConfirmSema  : public kaanhbot::robot::SystemBoolInputSema{
public:
    auto rtExecuteAfterCollect()->void override;
public:
    InputServoConfirmSema(const std::string &name="") : kaanhbot::robot::SystemBoolInputSema(name) {}
    ~InputServoConfirmSema() = default;
};

class IputProgramBitSema_0  : public kaanhbot::robot::SystemBoolInputSema{
public:
    auto rtExecuteAfterCollect()->void override;
public:
    IputProgramBitSema_0(const std::string &name="") : kaanhbot::robot::SystemBoolInputSema(name) {}
    ~IputProgramBitSema_0() = default;
};

class IputProgramBitSema_1  : public kaanhbot::robot::SystemBoolInputSema{
public:
    auto rtExecuteAfterCollect()->void override;
public:
    IputProgramBitSema_1(const std::string &name="") : kaanhbot::robot::SystemBoolInputSema(name) {}
    ~IputProgramBitSema_1() = default;
};

class IputProgramBitSema_2  : public kaanhbot::robot::SystemBoolInputSema{
public:
    auto rtExecuteAfterCollect()->void override;
public:
    IputProgramBitSema_2(const std::string &name="") : kaanhbot::robot::SystemBoolInputSema(name) {}
    ~IputProgramBitSema_2() = default;
};


// 继承自actualbooloutputsema ,只能来源于io
class OutputServoConfirmSema  : public kaanhbot::robot::SystemBoolOutputSema{
public:
    auto rtExecutebeforeExport()->void  override;
private:
    std::atomic_bool last_load{false};
public:
    OutputServoConfirmSema(const std::string &name="") : kaanhbot::robot::SystemBoolOutputSema(name) {}
    ~OutputServoConfirmSema() = default;
};

class OutputProgramBitSema_0  : public kaanhbot::robot::SystemBoolOutputSema{
public:
    auto rtExecutebeforeExport()->void  override;
private:
    std::atomic_bool last_load{false};
public:
    OutputProgramBitSema_0(const std::string &name="") : kaanhbot::robot::SystemBoolOutputSema(name) {}
    ~OutputProgramBitSema_0() = default;
};

class OutputProgramBitSema_1  : public kaanhbot::robot::SystemBoolOutputSema{
public:
    auto rtExecutebeforeExport()->void  override;
private:
    std::atomic_bool last_load{false};
public:
    OutputProgramBitSema_1(const std::string &name="") :kaanhbot::robot::SystemBoolOutputSema(name) {}
    ~OutputProgramBitSema_1() = default;
};

class OutputProgramBitSema_2  : public kaanhbot::robot::SystemBoolOutputSema{
public:
    auto rtExecutebeforeExport()->void  override;
private:
    std::atomic_bool last_load{false};
public:
    OutputProgramBitSema_2(const std::string &name="") : kaanhbot::robot::SystemBoolOutputSema(name) {}
    ~OutputProgramBitSema_2() = default;
};




// 信号的类型
enum class SignalType : int {
	kClear = 1,
	kLoad,
	kStart,
	kPause,
	kUnload,
	kProgramReset,
    kServoConfirm,
	kProgramBit0,
	kProgramBit1,
    kProgramBit2,
	kProgramBit3
};
// 信号的属性
struct Attribute {
    //bits_num {1};我认为需要知道这个io的位数，可以用这个数据
	SignalType signal_type{ SignalType::kClear };
	Attribute() {};
	Attribute(SignalType _signal_type) {signal_type = _signal_type; }
};

// ！检测信号保持时间，如果保持true_standard_hold_time_长度，则返回true.
// ！如果信号保持长时间一致，则一直返回的是true！true_counter_ 会一直增加，运行1亿年左右会超出数据大小
// ！对于这种信号，在使用时，要注意method返回值，会在信号等于标准信号的时候一直为0，区别于单沿检测器
// ！ 未使用
//template<typename Val>
//class MsEqualSignalDetector{
//public:
//    auto virtual method(const Val &ival)->bool{
//        //如果值等于标准，则计数开始，当计时大于hold_time时，返回true.一旦不等于，则计时复位为0
//        if(ival == true_standard_val_ ){
//            true_counter_++;
//        }else{
//            true_counter_=0;
//        }
//        if(true_counter_ >= true_standard_hold_time_) return true;
//        else return false;
//    }
//public:
//    explicit MsEqualSignalDetector(const Val &true_standard_val,std::uint64_t true_standard_hold_time = 1);
//    ARIS_DEFINE_BIG_FOUR(MsEqualSignalDetector);
//protected:
//    const Val true_standard_val_;
//    const std::uint64_t true_standard_hold_time_;
//    std::uint64_t true_counter_{0};
//};

using BoolNumericalSignal = aris::core::NumericalSignal<bool, Attribute>;
using SigQueue = aris::core::LockFreeArrayQueue<BoolNumericalSignal>;

class KAANHBOT_API ExternalAuto : public kaanh::module::MiddleModule {
public:

    auto virtual init()->void override;

    auto virtual execute(const std::string &str, std::function<void(std::string)> send_ret) noexcept->std::pair<std::string, std::string> override;
//信号来源获取一下
    auto signalFromModbus() const->int { return ATOMIC_LOAD(signal_from_modbus_); }
    auto setSignalFromModbus(int signal_from)->void { ATOMIC_STORE(signal_from_modbus_, signal_from); }

    auto externalPgmvelFromModbus() const->bool { return ATOMIC_LOAD(external_pgmvel_from_modbus_); }
    auto setExternalPgmvelFromModbus(bool external_pgmvel_from_modbus)->void { ATOMIC_STORE(external_pgmvel_from_modbus_, external_pgmvel_from_modbus); }

//非指令，只是简单的成员函数
    std::atomic_bool isServoConfirm(){return ATOMIC_LOAD(is_servo_confirm_);}
    auto setServoConfirm(bool is_servo_confirm)->void{is_servo_confirm_=is_servo_confirm;}

    std::atomic_bool inputPauseStatus(){return ATOMIC_LOAD(input_pause_status_);}
    auto setInputPauseStatus(bool input_pause_status)->void{input_pause_status_=input_pause_status;}

//program和set_program是一对映射，set_program会从xml获取参数
    auto program()const->std::vector<std::string> {return bind_program_id_name_;}
    auto set_program(const std::vector<std::string>& bind_program_id_name) -> void{bind_program_id_name_=bind_program_id_name;}

    auto servoConfirmShield()const ->bool{return ATOMIC_LOAD(servo_confirm_is_shield_);}

    auto setServoConfirmShield(const bool servo_confirm_is_shield)->void{ ATOMIC_STORE(servo_confirm_is_shield_,servo_confirm_is_shield);}

    auto setExternalModeStartLoadProgram(const std::string program)->void{external_mode_start_load_program_=program;}
    auto getExternalModeStartLoadProgram()const->std::string{return external_mode_start_load_program_;}


    auto setIsStartLoadProgram(bool is_strat_load_program)->void{is_start_load_program_=is_strat_load_program;}
    auto getIsStartLoadProgram()const->bool{return is_start_load_program_;}

    static auto instanceInCs()->ExternalAuto&;

//开放给sema访问使用
    struct ImpPub;
    std::unique_ptr<ImpPub> imp_pub_;


private:

    std::chrono::time_point<std::chrono::system_clock> last_load_time_;

    //splc记录当前加载的程序号
    std::atomic_int32_t splcprogram_id_{-1};
    //程序一可以有7个，因为第一个不能绑定
    std::vector<std::string> bind_program_id_name_;
    std::atomic_int32_t program_id_{-1};
    std::atomic_int signal_from_modbus_{0};

    SigQueue sig_queue_;

    std::atomic_bool input_pause_status_{false};

    std::atomic_bool is_servo_confirm_{false};
    std::atomic_bool servo_confirm_is_shield_{false};

    std::atomic_bool external_pgmvel_from_modbus_{false};

    //外部自动自动启动程序设置
    bool is_start_load_program_{false};
    std::string external_mode_start_load_program_{""};


    struct Imp;
    std::unique_ptr<Imp> imp_;
    
public:
    ExternalAuto();
    virtual ~ExternalAuto();
    KAANH_DELETE_BIG_FOUR(ExternalAuto)//不要拷贝构造，右值构造，拷贝赋值，左值引用，右值引用，长应用，万能引用
};
}// namespace kaanhbot::module

#endif  // KAANHBOT_MODULE_EXTERNAL_AUTO_HPP_
