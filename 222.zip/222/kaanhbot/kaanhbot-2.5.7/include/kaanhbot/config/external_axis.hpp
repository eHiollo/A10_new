#ifndef KAANHBOT_CONFIG_EXTERNAL_ARIS_HPP_
#define KAANHBOT_CONFIG_EXTERNAL_ARIS_HPP_

#include <memory>
#include <aris/plan/plan.hpp>
#include <aris/core/core.hpp>
#include "kaanhbot_lib_export.h"
namespace kaanhbot::config
{
    using Size = std::size_t;
    class KAANHBOT_API MoveEa :public aris::core::CloneObject<MoveEa, aris::plan::Plan>
        {
            public:
                auto virtual prepareNrt()->void;
                auto virtual executeRT()->int;
                explicit MoveEa(const std::string &name = "moveea");
            private:
                int32_t motor_num_;
                double begin_pos_;
                Size total_count_;
                double tar_pos_;
                double vel_;
                double acc_;
                double dec_;
                double jerk_;
                double act_pos_;
        };
}

#endif
