#ifndef KAANHBOT_CONFIG_ROBOTCONFIG_HPP_
#define KAANHBOT_CONFIG_ROBOTCONFIG_HPP_

#include <memory>
#include <ctime>
#include "aris.hpp"
#include "kaanh/module/middle_module.hpp"
#include "kaanh/general/macro.hpp"
#include "kaanh/general/json.hpp"
#include "kaanhbot_lib_export.h"


namespace kaanhbot::config {

struct MotorConfigPar{
    double max_pos;
    double min_pos;
    double max_vel;
    double min_vel;
    double max_acc;
    double min_acc;
    double max_pos_following_error;
    double max_vel_following_error;
    double unit_factor = 180.0/aris::PI;    //单位系数--直线轴:1000.0;旋转轴:57.295779513------
    double feed_constant = 360.0;           //当量比(机械结构行程/减速机输出端转1圈)--直线轴:导程mm/1圈;旋转轴:360度/1圈
    double gear_ratio = 1.0;                //减速比
    int resolution = 131072;                //电机分辨率
    int direction = 1;                      //1：电机顺时针方向；-1：电机逆时针方向------
    std::string motion_type = "rotatory";   //驱动类型--直线轴:linear;旋转轴:rotatory------
    double pos_factor;
    double home_pos = 0.0;
    double vel_factor = 1.0;
    double pos_offset = 0;

    auto check() const->void {
        if (max_pos <= min_pos) LOCALE_THROW("max_pos must be bigger than min pos", "电机位置上限必须大于电机位置下限");
        if (max_vel <= min_vel) LOCALE_THROW("max_vel must be bigger than min vel", "电机速度上限必须大于电机速度下限");
        if (max_acc <= min_acc) LOCALE_THROW("max_acc must be bigger than min acc", "电机加速度上限必须大于电机加速度下限");
        if (max_pos_following_error <= 0) LOCALE_THROW("max_pos_following_error must be positive", "电机位置跟随误差上限必须为正数");
        if (max_vel_following_error <= 0) LOCALE_THROW("max_vel_following_error must be positive", "电机速度跟随误差上限必须为正数");
        if (unit_factor <= 0) LOCALE_THROW("unit_factor must be positive", "电机单位系数必须为正数");
        if (feed_constant <= 0) LOCALE_THROW("feed_constant must be positive", "电机当量比必须为正数");
        if (gear_ratio < 1.0) LOCALE_THROW("gear_ratio must be positive", "电机减速比不能小于1");
        if (resolution <= 0) LOCALE_THROW("resolution must be positive", "电机分辨率必须为正数");
        if ((direction != 1)&&(direction != -1)) LOCALE_THROW("direction must be 1 or -1", "电机旋转方向必须为1或-1");
        if ((motion_type!="rotatory")&&(motion_type!="linear"))LOCALE_THROW("motion_type must be rotatory or linear", "电机驱动类型错误，必须为旋转轴或直线轴");
        if ((motion_type=="rotatory")&&(std::abs(unit_factor-57.295779513)>1e-3))LOCALE_THROW("rotatory axis's unit_factor must close to 57.295779513", "旋转轴单位系数必须为57.295779513");
        if ((motion_type=="linear")&&(std::abs(unit_factor-1000.0)>1e-6))LOCALE_THROW("linear axis's unit_factor must close to 1000.0", "直线轴单位系数必须为1000");
    }

    auto checkFromMotor(const aris::control::Motor &m)->void{
        pos_factor = direction*resolution*gear_ratio/feed_constant*unit_factor;
        if(std::abs(pos_factor - m.posFactor())>10.0)LOCALE_THROW("pos_factor differs between user and system", "用户、系统的电机位置系数不一致，请重新配置电机单位系数、当量比、减速比、分辨率、旋转方向");
        if(std::abs(max_pos/unit_factor - m.maxPos())>0.1)LOCALE_THROW("max_pos differs between user and system", "用户、系统的电机位置上限不一致，请重新配置");
        if(std::abs(min_pos/unit_factor - m.minPos())>0.1)LOCALE_THROW("min_pos differs between user and system", "用户、系统的电机位置下限不一致，请重新配置");
        if(std::abs(max_vel/unit_factor - m.maxVel())>0.1)LOCALE_THROW("max_vel differs between user and system", "用户、系统的电机速度上限不一致，请重新配置");
        if(std::abs(min_vel/unit_factor - m.minVel())>0.1)LOCALE_THROW("min_vel differs between user and system", "用户、系统的电机速度下限不一致，请重新配置");
        if(std::abs(max_acc/unit_factor - m.maxAcc())>0.5)LOCALE_THROW("max_acc differs between user and system", "用户、系统的电机加速度上限不一致，请重新配置");
        if(std::abs(min_acc/unit_factor - m.minAcc())>0.5)LOCALE_THROW("min_acc differs between user and system", "用户、系统的电机加速度下限不一致，请重新配置");
        if(std::abs(max_pos_following_error/unit_factor - m.maxPosFollowingError())>0.1)LOCALE_THROW("max_pos_following_error differs between user and system", "用户、系统的电机位置跟随误差不一致，请重新配置");
        if(std::abs(max_vel_following_error/unit_factor - m.maxVelFollowingError())>0.1)LOCALE_THROW("max_vel_following_error differs between user and system", "用户、系统的电机速度跟随误差不一致，请重新配置");
    }

    auto toMotor(aris::control::Motor &m)->void{
        pos_factor = direction*resolution*gear_ratio/feed_constant*unit_factor;
        m.setPosFactor(pos_factor);
        m.setMaxPos(max_pos/unit_factor);
        m.setMinPos(min_pos/unit_factor);
        m.setMaxVel(max_vel/unit_factor);
        m.setMinVel(min_vel/unit_factor);
        m.setMaxAcc(max_acc/unit_factor);
        m.setMinAcc(min_acc/unit_factor);
        m.setMaxPosFollowingError(max_pos_following_error/unit_factor);
        m.setMaxVelFollowingError(max_vel_following_error/unit_factor);
    }

    NLOHMANN_DEFINE_TYPE_INTRUSIVE(MotorConfigPar, max_pos, min_pos, max_vel, min_vel, max_acc, min_acc, max_pos_following_error, max_vel_following_error, unit_factor, feed_constant, gear_ratio, resolution, direction, motion_type)
};

class KAANHBOT_API RobotConfig : public kaanh::module::MiddleModule {
public:
    auto virtual init()->void override;

    auto virtual execute(const std::string &str, std::function<void(std::string)> send_ret) noexcept->std::pair<std::string, std::string> override;
    auto creatGeometry(aris::dynamic::Model* m,const double* base_pe)->void;
    static auto instanceInCs()->RobotConfig&;

private:
    struct Imp;
    std::unique_ptr<Imp> imp_;

public:
    std::vector<MotorConfigPar> motor_config_par_vec_;
    RobotConfig();
    ~RobotConfig();
    KAANH_DELETE_BIG_FOUR(RobotConfig)
};

}   //namespace kaanhbot::config


#endif //KAANHBOT_CONFIG_ROBOTCONFIG_HPP_
