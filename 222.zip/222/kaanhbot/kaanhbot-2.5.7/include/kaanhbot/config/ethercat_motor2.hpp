#ifndef KAANHBOT_CONFIG_ETHERCAT_MOTOR2_HPP_
#define KAANHBOT_CONFIG_ETHERCAT_MOTOR2_HPP_

#include <aris/control/control.hpp>
using namespace aris::control;

namespace kaanhbot::config
{
    class EthercatMotor2 : public Motor
    {
	public:
		auto virtual controlWord()const->std::uint16_t override;
		auto virtual modeOfOperation()const->std::uint8_t override;
		auto virtual targetPos()const->double override;
		auto virtual targetVel()const->double override;
		auto virtual targetToq()const->double override;
		auto virtual offsetVel()const->double override;
		auto virtual offsetCur()const->double override;
		// require pdo 0x6840 //
		auto virtual setControlWord(std::uint16_t control_word)->void override;
		// require pdo 0x6860 //
		auto virtual setModeOfOperation(std::uint8_t mode)->void override;
		// require pdo 0x687A //
		auto virtual setTargetPos(double pos)->void override;
		// require pdo 0x68FF //
		auto virtual setTargetVel(double vel)->void override;
		// require pdo 0x6871 //
		auto virtual setTargetToq(double toq)->void override;
		// require pdo 0x68B1 //
		auto virtual setOffsetVel(double vel)->void override;
		// require pdo 0x68B2 //
		auto virtual setOffsetToq(double toq)->void override;
		// require pdo 0x6841 //
		auto virtual statusWord()const->std::uint16_t override;
		// require pdo 0x6861 //
		auto virtual modeOfDisplay()const->std::uint8_t override;
		// require pdo 0x6864 //
		auto virtual actualPos()const->double override;
		// require pdo 0x686C //
		auto virtual actualVel()const->double override;
		// require pdo 0x6877 //
		auto virtual actualToq()const->double override;
		// require pdo 0x6878 //
		auto virtual actualCur()const->double override;

		// require pdo 0x6840 0x6841 // 
		auto virtual disable()->int override;
		// require pdo 0x6840 0x6841 //
		auto virtual enable()->int override;
		// require pdo 0x6840 0x6841 0x6860 0x6861 //
		auto virtual home()->int override;
		// require pdo 0x6860 0x6861 //
		auto virtual mode(std::uint8_t md)->int override;

		auto slave()->EthercatSlave*;
		auto setSlave(EthercatSlave*)->void;

		virtual ~EthercatMotor2();
		EthercatMotor2(EthercatSlave* slave = nullptr, const std::string &name = "ethercat_motor"
			, double max_pos = 1.0, double min_pos = -1.0, double max_vel = 1.0, double min_vel = -1.0, double max_acc = 1.0, double min_acc = -1.0
			, double max_pos_following_error = 1.0, double max_vel_following_error = 1.0, double pos_factor = 1.0, double pos_offset = 0.0, double home_pos = 0.0);
		EthercatMotor2(const EthercatMotor2 &other) = delete;
		EthercatMotor2(EthercatMotor2 &&other) = delete;
		EthercatMotor2& operator=(const EthercatMotor2 &other) = delete;
		EthercatMotor2& operator=(EthercatMotor2 &&other) = delete;

	private:
		struct Imp;
		aris::core::ImpPtr<Imp> imp_;
        
    };

}

#endif // KAANHBOT_CONFIG_ETHERCAT_MOTOR2_HPP_
