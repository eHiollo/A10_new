#ifndef KAANHBOT_CONFIG_ETHERCAT_IO_HPP_
#define KAANHBOT_CONFIG_ETHERCAT_IO_HPP_

#include <aris/control/control.hpp>
#include "kaanhbot_lib_export.h"

using namespace aris::control;

namespace kaanhbot::config
{
    class KAANHBOT_API EthercatIoBeckhoff : public EthercatDigitalIo
    {
    public:
        EthercatIoBeckhoff(const std::string &name = "ethercat_io_beckhoff", std::uint16_t phy_id = 0
                , std::uint32_t vendor_id = 0x00000000, std::uint32_t product_code = 0x00000000, std::uint32_t revision_num = 0x00000000, std::uint32_t dc_assign_activate = 0x00000000
                , std::uint16_t num_of_di = 0, std::uint16_t num_of_do = 0);
        virtual ~EthercatIoBeckhoff() = default;
        EthercatIoBeckhoff(const EthercatIoBeckhoff &other) = delete;
        EthercatIoBeckhoff(EthercatIoBeckhoff &&other) = delete;
        EthercatIoBeckhoff& operator=(const EthercatIoBeckhoff &other) = delete;
        EthercatIoBeckhoff& operator=(EthercatIoBeckhoff &&other) = delete;
        virtual auto getDi(const std::uint16_t index) const->bool override;
        virtual auto getDo(const std::uint16_t index) const->bool override;
        virtual auto setDo(const std::uint16_t index, const bool status)->void override;
    };

    class KAANHBOT_API EthercatIoTrio : public EthercatDigitalIo
    {
    public:
        EthercatIoTrio(const std::string &name = "ethercat_io_trio", std::uint16_t phy_id = 0
                , std::uint32_t vendor_id = 0x00000000, std::uint32_t product_code = 0x00000000, std::uint32_t revision_num = 0x00000000, std::uint32_t dc_assign_activate = 0x00000000
                , std::uint16_t num_of_di = 0, std::uint16_t num_of_do = 0);
        virtual ~EthercatIoTrio() = default;
        EthercatIoTrio(const EthercatIoTrio &other) = delete;
        EthercatIoTrio(EthercatIoTrio &&other) = delete;
        EthercatIoTrio& operator=(const EthercatIoTrio &other) = delete;
        EthercatIoTrio& operator=(EthercatIoTrio &&other) = delete;
        virtual auto getDi(const std::uint16_t index) const->bool override;
        virtual auto getDo(const std::uint16_t index) const->bool override;
        virtual auto setDo(const std::uint16_t index, const bool status)->void override;
    };

	class KAANHBOT_API EthercatIoItegva : public EthercatDigitalIo
	{
	public:
		EthercatIoItegva(const std::string &name = "ethercat_io_trio", std::uint16_t phy_id = 0
			, std::uint32_t vendor_id = 0x00000000, std::uint32_t product_code = 0x00000000, std::uint32_t revision_num = 0x00000000, std::uint32_t dc_assign_activate = 0x00000000
			, std::uint16_t num_of_di = 0, std::uint16_t num_of_do = 0);
		virtual ~EthercatIoItegva() = default;
		EthercatIoItegva(const EthercatIoItegva &other) = delete;
		EthercatIoItegva(EthercatIoItegva &&other) = delete;
		EthercatIoItegva& operator=(const EthercatIoItegva &other) = delete;
		EthercatIoItegva& operator=(EthercatIoItegva &&other) = delete;
		virtual auto getDi(const std::uint16_t index) const->bool override;
		virtual auto getDo(const std::uint16_t index) const->bool override;
		virtual auto setDo(const std::uint16_t index, const bool status)->void override;
	};

    class KAANHBOT_API EthercatIoLingChen : public EthercatDigitalIo
    {
    public:
       EthercatIoLingChen(const std::string &name = "ethercat_io_lingchen", std::uint16_t phy_id = 0
           , std::uint32_t vendor_id = 0x00000000, std::uint32_t product_code = 0x00000000, std::uint32_t revision_num = 0x00000000, std::uint32_t dc_assign_activate = 0x00000000
           , std::uint16_t num_of_di = 0, std::uint16_t num_of_do = 0);
       virtual ~EthercatIoLingChen() = default;
       EthercatIoLingChen(const EthercatIoLingChen &other) = delete;
       EthercatIoLingChen(EthercatIoLingChen &&other) = delete;
       EthercatIoLingChen& operator=(const EthercatIoLingChen &other) = delete;
       EthercatIoLingChen& operator=(EthercatIoLingChen &&other) = delete;
       virtual auto getDi(const std::uint16_t index)const->bool override;
       virtual auto getDo(const std::uint16_t index)const->bool override;
       virtual auto setDo(const std::uint16_t index, const bool status)->void override;
    };

    class KAANHBOT_API Ka_IO_0201N : public EthercatDigitalIo
    {
    public:
       Ka_IO_0201N(const std::string &name = "ethercat_io_leisai", std::uint16_t phy_id = 0
           , std::uint32_t vendor_id = 0x00000000, std::uint32_t product_code = 0x00000000, std::uint32_t revision_num = 0x00000000, std::uint32_t dc_assign_activate = 0x00000000
           , std::uint16_t num_of_di = 0, std::uint16_t num_of_do = 0);
       virtual ~Ka_IO_0201N() = default;
       Ka_IO_0201N(const EthercatIoLingChen &other) = delete;
       Ka_IO_0201N(EthercatIoLingChen &&other) = delete;
       Ka_IO_0201N& operator=(const EthercatIoLingChen &other) = delete;
       Ka_IO_0201N& operator=(EthercatIoLingChen &&other) = delete;
       virtual auto getDi(const std::uint16_t index)const->bool override;
       virtual auto getDo(const std::uint16_t index)const->bool override;
       virtual auto setDo(const std::uint16_t index, const bool status)->void override;
    };


    class KAANHBOT_API Ka_IO_0102N : public EthercatDigitalIo
    {
        public:
        Ka_IO_0102N(const std::string &name = "ethercat_io_lingchen2", std::uint16_t phy_id = 0
            , std::uint32_t vendor_id = 0x00000000, std::uint32_t product_code = 0x00000000, std::uint32_t revision_num = 0x00000000, std::uint32_t dc_assign_activate = 0x00000000
            , std::uint16_t num_of_di = 0, std::uint16_t num_of_do = 0);
        virtual ~Ka_IO_0102N() = default;
        Ka_IO_0102N(const Ka_IO_0102N &other) = delete;
        Ka_IO_0102N(Ka_IO_0102N &&other) = delete;
        Ka_IO_0102N& operator=(const Ka_IO_0102N &other) = delete;
        Ka_IO_0102N& operator=(Ka_IO_0102N &&other) = delete;
        virtual auto getDi(const std::uint16_t index)const->bool override;
        virtual auto getDo(const std::uint16_t index)const->bool override;
        virtual auto setDo(const std::uint16_t index, const bool status)->void override;
    };

    class KAANHBOT_API Ka_IO_0301N : public EthercatDigitalIo
    {
        public:
        Ka_IO_0301N(const std::string &name = "ethercat_io_decowell", std::uint16_t phy_id = 0
            , std::uint32_t vendor_id = 0x00000000, std::uint32_t product_code = 0x00000000, std::uint32_t revision_num = 0x00000000, std::uint32_t dc_assign_activate = 0x00000000
            , std::uint16_t num_of_di = 0, std::uint16_t num_of_do = 0);
        virtual ~Ka_IO_0301N() = default;
        Ka_IO_0301N(const Ka_IO_0301N &other) = delete;
        Ka_IO_0301N(Ka_IO_0301N &&other) = delete;
        Ka_IO_0301N& operator=(const Ka_IO_0301N &other) = delete;
        Ka_IO_0301N& operator=(Ka_IO_0301N &&other) = delete;
        virtual auto getDi(const std::uint16_t index)const->bool override;
        virtual auto getDo(const std::uint16_t index)const->bool override;
        virtual auto setDo(const std::uint16_t index, const bool status)->void override;
    };


	class IoParam{
	public:
		auto virtual init()->void;
        auto virtual getDi(const uint32_t &index) const->bool;
        auto virtual getDo(const uint32_t &index) const->bool;
        auto virtual setDi(const uint32_t &index, const bool &din)->void;
        auto virtual setDo(const uint32_t &index, const bool &dout)->void;
        auto virtual sizeofdi() const->uint32_t;
        auto virtual sizeofdo() const->uint32_t;
		static IoParam& instance() {
			static IoParam inst;
			return inst;
		}

	private:
        std::vector<std::atomic_bool> din_;
        std::vector<std::atomic_bool> dout_;
		explicit IoParam() {};
		IoParam(const IoParam &) = delete;
		IoParam& operator=(const IoParam &) = delete;
	};



    class  KAANHBOT_API EthercatAIKEYENCEDL : public EthercatAnalogIo
    {
    public:
       EthercatAIKEYENCEDL(const std::string &name = "ethercat_io_lingchen", std::uint16_t phy_id = 0
           , std::uint32_t vendor_id = 0x00000000, std::uint32_t product_code = 0x00000000, std::uint32_t revision_num = 0x00000000, std::uint32_t dc_assign_activate = 0x00000000
           , std::uint16_t num_of_ai = 0, std::uint16_t num_of_ao = 0);
       virtual ~EthercatAIKEYENCEDL() = default;
       EthercatAIKEYENCEDL(const EthercatAIKEYENCEDL &other) = delete;
       EthercatAIKEYENCEDL(EthercatAIKEYENCEDL &&other) = delete;
       EthercatAIKEYENCEDL& operator=(const EthercatAIKEYENCEDL &other) = delete;
       EthercatAIKEYENCEDL& operator=(EthercatAIKEYENCEDL &&other) = delete;
       virtual auto getAi(const std::uint16_t index)const->float override;
       virtual auto getAo(const std::uint16_t index)const->float override;
       virtual auto setAo(const std::uint16_t index, const float val)->void override;
    };


} 

#endif // KAANHBOT_CONFIG_ETHERCAT_IO_HPP_
