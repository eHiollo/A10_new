#ifndef KAANHBOT_CONFIG_MODEL3D_HPP_
#define KAANHBOT_CONFIG_MODEL3D_HPP_

#include "kaanh/module/middle_module.hpp"
#include "kaanh/general/macro.hpp"
#include "kaanh/general/json.hpp"
#include "kaanhbot_lib_export.h"

namespace kaanhbot::config{


class KAANHBOT_API Web3DModel : public kaanh::module::MiddleModule {
public:
    auto virtual init()->void override;

    auto virtual execute(const std::string &str, std::function<void(std::string)> send_ret) noexcept->std::pair<std::string, std::string> override;
    auto traversingXMLofModel3d()->void;
    auto updateXMLofModel3d()->void;
    Web3DModel();
    ~Web3DModel();
    KAANH_DELETE_BIG_FOUR(Web3DModel)
private:
    struct Imp;
    std::unique_ptr<Imp> imp_;
};

template <typename T>
struct atomwrapper
{
std::atomic<T> _a;

atomwrapper()
:_a()
{}

atomwrapper(const std::atomic<T> &a)
    :_a(a.load())
{}
T load(){
    return _a.load();
}
void store(const T& a){
    _a.store(a);
}
atomwrapper(const atomwrapper &other)
    :_a(other._a.load())
{}

atomwrapper &operator=(const atomwrapper &other)
{
    _a.store(other._a.load());
}
};


}








#endif