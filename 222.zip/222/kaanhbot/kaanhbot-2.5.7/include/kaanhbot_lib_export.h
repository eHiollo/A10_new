
#ifndef KAANHBOT_API_H
#define KAANHBOT_API_H

#ifdef KAANHBOT_LIB_STATIC_DEFINE
#  define KAANHBOT_API
#  define KAANHBOT_LIB_NO_EXPORT
#else
#  ifndef KAANHBOT_API
#    ifdef kaanhbot_lib_EXPORTS
        /* We are building this library */
#      define KAANHBOT_API __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define KAANHBOT_API __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef KAANHBOT_LIB_NO_EXPORT
#    define KAANHBOT_LIB_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef KAANHBOT_LIB_DEPRECATED
#  define KAANHBOT_LIB_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef KAANHBOT_LIB_DEPRECATED_EXPORT
#  define KAANHBOT_LIB_DEPRECATED_EXPORT KAANHBOT_API KAANHBOT_LIB_DEPRECATED
#endif

#ifndef KAANHBOT_LIB_DEPRECATED_NO_EXPORT
#  define KAANHBOT_LIB_DEPRECATED_NO_EXPORT KAANHBOT_LIB_NO_EXPORT KAANHBOT_LIB_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef KAANHBOT_LIB_NO_DEPRECATED
#    define KAANHBOT_LIB_NO_DEPRECATED
#  endif
#endif

#endif /* KAANHBOT_API_H */
