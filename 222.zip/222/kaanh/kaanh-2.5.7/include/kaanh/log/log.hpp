#ifndef KAANH_LOG_LOG_HPP_
#define KAANH_LOG_LOG_HPP_

#include <memory>
#include <chrono>
#include <set>
#include <map>
#include <thread>
#include <atomic>
#include <mutex>
#include <string>
#include <filesystem>

#include "kaanh/general/macro.hpp"
#include "kaanh/general/json.hpp"
#include "kaanh/general/sqlite3.h"
#include "aris/core/core.hpp"
#include "aris/plan/plan.hpp"
#include "kaanh_lib_export.h"

namespace kaanh::log {

enum class KAANH_API LogType : int {
    kSystem = 0,
    kConfig,
    kOperation
};

enum class KAANH_API LogLvl : int {
    kDebug = 0,
    kInfo,
    kWarning,
    kError
};

class KAANH_API DbLogCell {
#define MAX_LOG_LENGTH 512
public:
    auto text() const->std::string { return std::string(ctext_); }
    auto ctext() const->const char* { return ctext_; }
    auto setText(const std::string &text)->void { std::strncpy(ctext_, text.c_str(), MAX_LOG_LENGTH-1); ctext_[MAX_LOG_LENGTH-1]='\0'; }
    auto setText(const char *ctext)->void { if (!ctext) return; std::strncpy(ctext_, ctext, MAX_LOG_LENGTH-1); ctext_[MAX_LOG_LENGTH-1]='\0'; }
    auto logLvl() const->LogLvl { return l_; }
    auto setLogLvl(LogLvl l)->void { l_ = l; }
    auto logType() const->LogType { return t_; }
    auto setLogType(LogType t)->void { t_ = t; }
    auto code() const->int { return code_; }
    auto setCode(int code)->void { code_ = code; }
    auto strategy() const->aris::core::AccessStrategy { return stg_; }
    auto setStrategy(aris::core::AccessStrategy stg)->void { stg_ = stg; }
    auto needCheck() const->bool { return nc_; }
    auto setNeedCheck(bool need_check)->void { nc_ = need_check; }
    auto setTimeStamp(const std::chrono::system_clock::time_point &tp) { tp_ = tp; }
    auto timeStamp() const->const std::chrono::system_clock::time_point& { return tp_; }
    
private:
    char ctext_[MAX_LOG_LENGTH];
    LogLvl l_{LogLvl::kInfo};
    LogType t_{LogType::kSystem};
    int code_{0};
    aris::core::AccessStrategy stg_{aris::core::AccessStrategy::kYield};
    bool nc_{true};
    std::chrono::system_clock::time_point tp_{std::chrono::system_clock::now()};

public:
    DbLogCell() = default;
    explicit DbLogCell(const char *ctext,
                        LogLvl l = LogLvl::kInfo, 
                        LogType t = LogType::kSystem, 
                        int code = 0,
                        aris::core::AccessStrategy stg = aris::core::AccessStrategy::kYield,
                        bool need_check = true,
                        const std::chrono::system_clock::time_point tp = std::chrono::system_clock::now()
                        ) 
        :l_(l), t_(t), code_(code), stg_(stg), nc_(need_check), tp_(tp) { setText(ctext); }
    explicit DbLogCell(const std::string &text,
                        LogLvl l = LogLvl::kInfo, 
                        LogType t = LogType::kSystem, 
                        int code = 0,
                        aris::core::AccessStrategy stg = aris::core::AccessStrategy::kYield,
                        bool need_check = true,
                        const std::chrono::system_clock::time_point tp = std::chrono::system_clock::now()
                        ) 
        :l_(l), t_(t), code_(code), stg_(stg), nc_(need_check), tp_(tp) { setText(text); }
    virtual ~DbLogCell() = default;
};

auto KAANH_API operator<<(std::ostream &s, const DbLogCell &cell)->std::ostream&;

class KAANH_API LogFilter {
public:
    struct KAANH_API TimeRule {
        bool enable{true};
        std::chrono::system_clock::time_point begin;
        std::chrono::system_clock::time_point end;
    };

    struct KAANH_API LvlRule {
        bool enable{true};
        std::set<LogLvl> lvls;
    };

    struct KAANH_API TypeRule {
        bool enable{true};
        std::set<LogType> types;
    };

    struct KAANH_API CodeRule {
        bool enable{true};
        int min_code{0};
        int max_code{0};
    };

    struct KAANH_API CountRule {
        bool enable{true};
        unsigned start{0};
        unsigned offset{10};
    };

public:
    auto setTimeRule(const TimeRule &rule)->void { time_rule_ = rule; }
    auto timeRule() const->const TimeRule& { return time_rule_; }
    auto setLvlRule(const LvlRule &rule)->void { lvl_rule_ = rule; }
    auto lvlRule() const->const LvlRule& { return lvl_rule_; }
    auto setTypeRule(const TypeRule &rule)->void { type_rule_ = rule; }
    auto typeRule() const->const TypeRule& { return type_rule_; }
    auto setCodeRule(const CodeRule &rule)->void { code_rule_ = rule; }
    auto codeRule() const->const CodeRule& { return code_rule_; }
    auto setOrder(bool order)->void { order_ = order; }
    auto order() const->bool { return order_; }
    auto setCountRule(const CountRule &rule)->void { count_rule_ = rule; }
    auto countRule() const->const CountRule& { return count_rule_; }
    
private:
    TimeRule time_rule_{false};
    LvlRule lvl_rule_{false};
    TypeRule type_rule_{false};
    CodeRule code_rule_{false};
    bool order_{false};
    CountRule count_rule_{false};
};

class KAANH_API Sqlite3Log {
public:
    static auto instance()->Sqlite3Log&;
    auto open(const std::filesystem::path &db_path)->void;
    auto toDb(const DbLogCell &cell)->void;
    auto rtToDb(const DbLogCell &cell)->void;
    auto close()->void;
    auto isOpen() const->bool;
    auto select(const LogFilter &filter) const->std::vector<DbLogCell>;

    auto currentId() const->uint64_t { return id_.load(std::memory_order_acquire); }
    auto unchecked() const->std::map<uint64_t, DbLogCell>;
    auto check(uint64_t id)->void;
    auto checkAll()->void;
    auto registerError(int errorcode,const std::string& errormsg,const std::string & errormeassure = "")->void;
    auto addMeassure(int errorcode,const std::string& errormeassure)->void;
    auto setError(int errorcode,const std::string& premsg = "",const std::string& msgsuf = "",LogType lt = LogType::kSystem)->void;
    auto setPlanPreError(int errorcode,aris::plan::Plan& plan,const std::string& premsg = "",const std::string& msgsuf="",LogType lt = LogType::kSystem)->void;
    auto setPlanExeError(int errorcode,aris::plan::Plan& plan,const std::string& premsg = "",const std::string& msgsuf="",LogType lt = LogType::kSystem)->void;
    auto initErrorConfig()->void;
    auto createErrorConfig()->void;
    auto getErrorMeassure(int errorcode)->std::string;
    auto hasError() const->bool { return log_error_.load(std::memory_order_acquire) || state_error_.load(std::memory_order_acquire); }

    auto registerState(int code, const std::string &name)->void;
    auto triggerState(int code)->void;
    auto disappearState(int code)->void;
    auto checkState(const std::string &name)->void;
    auto trrigeredStates()->std::vector<std::pair<int,std::string>>;
    auto currentStateId() const->uint64_t;

    auto rtUpdateStateError()->void;

private:
    auto clearError()->void;

private:
    sqlite3 *db_{nullptr};
    bool to_work_{false};
    std::thread worker_;
    std::unique_ptr<aris::core::LockFreeArrayQueue<DbLogCell>> queue_{nullptr};
    aris::core::Msg rt_msg_;
    std::unique_ptr<aris::core::Pipe> pipe_{nullptr};
    mutable std::recursive_mutex mu_;

    std::atomic<uint64_t> id_{0};
    std::set<uint64_t> error_ids_;
    std::map<uint64_t, DbLogCell> unchecked_cells_;
    mutable std::recursive_mutex unchecked_mu_;
    std::atomic_bool log_error_{false};

    std::atomic<uint64_t> state_id_{0};
    std::map<int, std::pair<std::string, std::atomic_bool>> states_;
    std::atomic_bool state_error_{false};

    std::map<int, std::pair<std::string,std::string>> errorconfig_;
private:
    Sqlite3Log() : queue_(new aris::core::LockFreeArrayQueue<DbLogCell>(1024)), pipe_(new aris::core::Pipe("rt_log", 1024*sizeof(DbLogCell))) {
        rt_msg_.resize(sizeof(DbLogCell));
    }
    ~Sqlite3Log();
};

#define DEBUG_SYS(text, code) std::cout<<kaanh::log::DbLogCell(text, kaanh::log::LogLvl::kDebug, kaanh::log::LogType::kSystem, code, aris::core::AccessStrategy::kYield, false);
#define DEBUG_CFG(text, code) std::cout<<kaanh::log::DbLogCell(text, kaanh::log::LogLvl::kDebug, kaanh::log::LogType::kConfig, code, aris::core::AccessStrategy::kYield, false);
#define DEBUG_OPR(text, code) std::cout<<kaanh::log::DbLogCell(text, kaanh::log::LogLvl::kDebug, kaanh::log::LogType::kOperation, code, aris::core::AccessStrategy::kYield, false);
#define INFO_SYS(text, code) std::cout<<kaanh::log::DbLogCell(text, kaanh::log::LogLvl::kInfo, kaanh::log::LogType::kSystem, code, aris::core::AccessStrategy::kYield, false);
#define INFO_CFG(text, code) std::cout<<kaanh::log::DbLogCell(text, kaanh::log::LogLvl::kInfo, kaanh::log::LogType::kConfig, code, aris::core::AccessStrategy::kYield, false);
#define INFO_OPR(text, code) std::cout<<kaanh::log::DbLogCell(text, kaanh::log::LogLvl::kInfo, kaanh::log::LogType::kOperation, code, aris::core::AccessStrategy::kYield, false);
#define DEBUG_SYS_NC(text, code) std::cout<<kaanh::log::DbLogCell(text, kaanh::log::LogLvl::kDebug, kaanh::log::LogType::kSystem, code, aris::core::AccessStrategy::kYield, true);
#define DEBUG_CFG_NC(text, code) std::cout<<kaanh::log::DbLogCell(text, kaanh::log::LogLvl::kDebug, kaanh::log::LogType::kConfig, code, aris::core::AccessStrategy::kYield, true);
#define DEBUG_OPR_NC(text, code) std::cout<<kaanh::log::DbLogCell(text, kaanh::log::LogLvl::kDebug, kaanh::log::LogType::kOperation, code, aris::core::AccessStrategy::kYield, true);
#define INFO_SYS_NC(text, code) std::cout<<kaanh::log::DbLogCell(text, kaanh::log::LogLvl::kInfo, kaanh::log::LogType::kSystem, code, aris::core::AccessStrategy::kYield, true);
#define INFO_CFG_NC(text, code) std::cout<<kaanh::log::DbLogCell(text, kaanh::log::LogLvl::kInfo, kaanh::log::LogType::kConfig, code, aris::core::AccessStrategy::kYield, true);
#define INFO_OPR_NC(text, code) std::cout<<kaanh::log::DbLogCell(text, kaanh::log::LogLvl::kInfo, kaanh::log::LogType::kOperation, code, aris::core::AccessStrategy::kYield, true);
#define WARNING_SYS_NC(text, code) std::cout<<kaanh::log::DbLogCell(text, kaanh::log::LogLvl::kWarning, kaanh::log::LogType::kSystem, code, aris::core::AccessStrategy::kYield, true);
#define WARNING_CFG_NC(text, code) std::cout<<kaanh::log::DbLogCell(text, kaanh::log::LogLvl::kWarning, kaanh::log::LogType::kConfig, code, aris::core::AccessStrategy::kYield, true);
#define WARNING_OPR_NC(text, code) std::cout<<kaanh::log::DbLogCell(text, kaanh::log::LogLvl::kWarning, kaanh::log::LogType::kOperation, code, aris::core::AccessStrategy::kYield, true);
#define ERROR_SYS_NC(text, code) std::cout<<kaanh::log::DbLogCell(text, kaanh::log::LogLvl::kError, kaanh::log::LogType::kSystem, code, aris::core::AccessStrategy::kYield, true);
#define ERROR_CFG_NC(text, code) std::cout<<kaanh::log::DbLogCell(text, kaanh::log::LogLvl::kError, kaanh::log::LogType::kConfig, code, aris::core::AccessStrategy::kYield, true);
#define ERROR_OPR_NC(text, code) std::cout<<kaanh::log::DbLogCell(text, kaanh::log::LogLvl::kError, kaanh::log::LogType::kOperation, code, aris::core::AccessStrategy::kYield, true);

#define RT_DEBUG_SYS(text, code) kaanh::log::Sqlite3Log::instance().rtToDb(kaanh::log::DbLogCell(text, kaanh::log::LogLvl::kDebug, kaanh::log::LogType::kSystem, code, aris::core::AccessStrategy::kAbandon, false));
#define RT_DEBUG_CFG(text, code) kaanh::log::Sqlite3Log::instance().rtToDb(kaanh::log::DbLogCell(text, kaanh::log::LogLvl::kDebug, kaanh::log::LogType::kConfig, code, aris::core::AccessStrategy::kAbandon, false));
#define RT_DEBUG_OPR(text, code) kaanh::log::Sqlite3Log::instance().rtToDb(kaanh::log::DbLogCell(text, kaanh::log::LogLvl::kDebug, kaanh::log::LogType::kOperation, code, aris::core::AccessStrategy::kAbandon, false));
#define RT_INFO_SYS(text, code) kaanh::log::Sqlite3Log::instance().rtToDb(kaanh::log::DbLogCell(text, kaanh::log::LogLvl::kInfo, kaanh::log::LogType::kSystem, code, aris::core::AccessStrategy::kAbandon, false));
#define RT_INFO_CFG(text, code) kaanh::log::Sqlite3Log::instance().rtToDb(kaanh::log::DbLogCell(text, kaanh::log::LogLvl::kInfo, kaanh::log::LogType::kConfig, code, aris::core::AccessStrategy::kAbandon, false));
#define RT_INFO_OPR(text, code) kaanh::log::Sqlite3Log::instance().rtToDb(kaanh::log::DbLogCell(text, kaanh::log::LogLvl::kInfo, kaanh::log::LogType::kOperation, code, aris::core::AccessStrategy::kAbandon, false));
#define RT_DEBUG_SYS_NC(text, code) kaanh::log::Sqlite3Log::instance().rtToDb(kaanh::log::DbLogCell(text, kaanh::log::LogLvl::kDebug, kaanh::log::LogType::kSystem, code, aris::core::AccessStrategy::kAbandon, true));
#define RT_DEBUG_CFG_NC(text, code) kaanh::log::Sqlite3Log::instance().rtToDb(kaanh::log::DbLogCell(text, kaanh::log::LogLvl::kDebug, kaanh::log::LogType::kConfig, code, aris::core::AccessStrategy::kAbandon, true));
#define RT_DEBUG_OPR_NC(text, code) kaanh::log::Sqlite3Log::instance().rtToDb(kaanh::log::DbLogCell(text, kaanh::log::LogLvl::kDebug, kaanh::log::LogType::kOperation, code, aris::core::AccessStrategy::kAbandon, true));
#define RT_INFO_SYS_NC(text, code) kaanh::log::Sqlite3Log::instance().rtToDb(kaanh::log::DbLogCell(text, kaanh::log::LogLvl::kInfo, kaanh::log::LogType::kSystem, code, aris::core::AccessStrategy::kAbandon, true));
#define RT_INFO_CFG_NC(text, code) kaanh::log::Sqlite3Log::instance().rtToDb(kaanh::log::DbLogCell(text, kaanh::log::LogLvl::kInfo, kaanh::log::LogType::kConfig, code, aris::core::AccessStrategy::kAbandon, true));
#define RT_INFO_OPR_NC(text, code) kaanh::log::Sqlite3Log::instance().rtToDb(kaanh::log::DbLogCell(text, kaanh::log::LogLvl::kInfo, kaanh::log::LogType::kOperation, code, aris::core::AccessStrategy::kAbandon, true));
#define RT_WARNING_SYS_NC(text, code) kaanh::log::Sqlite3Log::instance().rtToDb(kaanh::log::DbLogCell(text, kaanh::log::LogLvl::kWarning, kaanh::log::LogType::kSystem, code, aris::core::AccessStrategy::kAbandon, true));
#define RT_WARNING_CFG_NC(text, code) kaanh::log::Sqlite3Log::instance().rtToDb(kaanh::log::DbLogCell(text, kaanh::log::LogLvl::kWarning, kaanh::log::LogType::kConfig, code, aris::core::AccessStrategy::kAbandon, true));
#define RT_WARNING_OPR_NC(text, code) kaanh::log::Sqlite3Log::instance().rtToDb(kaanh::log::DbLogCell(text, kaanh::log::LogLvl::kWarning, kaanh::log::LogType::kOperation, code, aris::core::AccessStrategy::kAbandon, true));
#define RT_ERROR_SYS_NC(text, code) kaanh::log::Sqlite3Log::instance().rtToDb(kaanh::log::DbLogCell(text, kaanh::log::LogLvl::kError, kaanh::log::LogType::kSystem, code, aris::core::AccessStrategy::kAbandon, true));
#define RT_ERROR_CFG_NC(text, code) kaanh::log::Sqlite3Log::instance().rtToDb(kaanh::log::DbLogCell(text, kaanh::log::LogLvl::kError, kaanh::log::LogType::kConfig, code, aris::core::AccessStrategy::kAbandon, true));
#define RT_ERROR_OPR_NC(text, code) kaanh::log::Sqlite3Log::instance().rtToDb(kaanh::log::DbLogCell(text, kaanh::log::LogLvl::kError, kaanh::log::LogType::kOperation, code, aris::core::AccessStrategy::kAbandon, true));

// #define EN 0
// #define CHS 1
// class ARIS_API CodeTextTable {
// public:
// 	static auto instance()->CodeTextTable& { static CodeTextTable obj; return obj; }
// 	auto language() const->int { return language_; }
// 	auto setLanguage(int language)->void { language_ = language; }
// 	auto add(int code, int language, const std::string &text)->CodeTextTable& {
// 		if (tbl_.find(code) == tbl_.end()) tbl_[code] = {};
// 		auto &mlang = tbl_.at(code);
// 		if (mlang.find(language) != mlang.end())
// 			THROW_FILE_LINE("Text has existed -- code:"+std::to_string(code)+" language: "+std::to_string(language));
// 		mlang[language] = text;
// 		return *this;
// 	}
// 	auto get(int code, int language) const->const std::string& {
// 		auto it_code = tbl_.find(code);
// 		if (it_code == tbl_.end()) THROW_FILE_LINE("Code '"+std::to_string(code)+"' doesn't exist.");
// 		auto it_lang = it_code->second.find(language);
// 		if (it_lang == it_code->second.end()) 
// 			THROW_FILE_LINE("Code '"+std::to_string(code)+"' has no language '"+std::to_string(language)+"'.");
// 		return it_lang->second;
// 	}
// 	auto get(int code) const->const std::string& { return get(code, language_); }
// 	auto getAndFormat(int code, int language, ...) const->std::string;
// 	auto table() const->const std::map<int, std::map<int, std::string>>& { return tbl_; }

// private:
// 	int language_{CHS};
// 	std::map<int, std::map<int, std::string>> tbl_;

// private:
// 	CodeTextTable() = default;
// 	virtual ~CodeTextTable() = default;
// };

// #define EN_TEXT_REGISTER(code, text) aris::core::CodeTextTable::instance().add(code, EN, text)
// #define CHS_TEXT_REGISTER(code, text) aris::core::CodeTextTable::instance().add(code, CHS, text)
// #define EN_CHS_TEXT_REGISTER(code, en_text, chs_text) \
// EN_TEXT_REGISTER(code, en_text);					  \
// CHS_TEXT_REGISTER(code, chs_text)
// #define TEXT_GET_AND_FORMAT(code, ...) \
// aris::core::CodeTextTable::instance().getAndFormat(code, aris::core::CodeTextTable::instance().language(), ##__VA_ARGS__)

#define EN 0
#define CHN 1
class KAANH_API LocaleString {
public:
    static auto locale()->unsigned { return locale_; }
    static auto setLocale(unsigned locale)->void { locale_ = locale; }
    static auto select(std::initializer_list<std::string> strs)->std::string {
#define LOCALE_STRING_HELPER(id) \
case id : \
if (strs.size() >= id+1) return *(strs.begin()+id); \
else if (strs.size() == 1) return *(strs.begin()); \
else return "";

        switch (locale_) {
        LOCALE_STRING_HELPER(EN)
        LOCALE_STRING_HELPER(CHN)
        default :
            if (strs.size() >= 1) return *(strs.begin());
            else return "";
        }

#undef LOCALE_STRING_HELPER

        return "";
    }

private:
    static unsigned locale_;
};

NLOHMANN_JSON_SERIALIZE_ENUM(LogLvl, {
    {LogLvl::kDebug, "Debug"},
    {LogLvl::kInfo, "Info"},
    {LogLvl::kWarning, "Warning"},
    {LogLvl::kError, "Error"}
})

NLOHMANN_JSON_SERIALIZE_ENUM(LogType, {
    {LogType::kSystem, "System"},
    {LogType::kConfig, "Config"},
    {LogType::kOperation, "Operation"}
})

KAANH_API void to_json(nlohmann::json& j, const DbLogCell& cell);

}   // namespace kaanh::log

#endif  // KAANH_LOG_LOG_HPP_
