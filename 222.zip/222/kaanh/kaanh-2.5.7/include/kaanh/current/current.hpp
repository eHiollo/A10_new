#ifndef KAANH_PACKAGE_CURRENT_HPP_
#define KAANH_PACKAGE_CURRENT_HPP_

#include <aris.hpp>
#include <stdlib.h>
#include "kaanh/module/middle_module.hpp"
#include "kaanh/general/macro.hpp"

namespace kaanh::package
{

    class KAANH_API CalibDynPar : public aris::core::CloneObject<CalibDynPar, aris::plan::Plan>{
    public:
        auto virtual prepareNrt()->void override;
        auto virtual executeRT()->int override;
        auto virtual collectNrt()->void override;
        explicit CalibDynPar(const std::string &name = "CalibDynPar");
        auto PauseContinueB()->double;
        ~CalibDynPar();
        KAANH_DECLARE_BIG_FOUR(CalibDynPar)
    private:
        struct Imp;
        aris::core::ImpPtr<Imp> imp_;
        
    };
    class KAANH_API CurrentGuidance : public aris::core::CloneObject<CurrentGuidance, aris::plan::Plan>{
    public:
        auto virtual prepareNrt()->void override;
        auto virtual executeRT()->int override;
        auto virtual collectNrt()->void override;
        explicit CurrentGuidance(const std::string &name = "CurrentGuidance");
    private:
        struct Imp;
        aris::core::ImpPtr<Imp> imp_;
    };

    class KAANH_API Current : public kaanh::module::MiddleModule {
    public:
        auto virtual init()->void override;
        auto virtual execute(const std::string &str, std::function<void(std::string)> send_ret) noexcept->std::pair<std::string, std::string> override;
        static auto instanceInCs()->Current&;

        auto setCalibing(bool st)->void;
        auto calibing()const->bool;

        auto setCurStatus(bool st)->void;
        auto curStatus()const->bool;

        auto setCurCalibrated(aris::Size model_id,double cc)->void;
        auto curCalibrated(aris::Size model_id)->double;
        auto setCurCalibrateds(std::vector<double> cc)->void;
        auto curCalibrateds()->const std::vector<double>;

        auto setMaxStaticVel(std::vector<double> vel)->void;
        auto maxStaticVel()const->std::vector<double>;

        auto setFrStaticIndex(std::vector<double> fsi)->void;
        auto frStaticIndex()const->std::vector<double>;

        auto setFrDynamicIndex(std::vector<double> fdi)->void;
        auto frDynamicIndex()const->std::vector<double>;

        auto setCollisionDetectionState(std::vector<double> st)->void;
        auto collisionDetectionState()const->std::vector<double>;

        auto setCollisionDetectionSensitivity(const std::vector<double> st)->void;
        auto collisionDetectionSensitivity()const->std::vector<double>;

        auto setCollisionFlag(bool flag)->void;
        auto collisionFlag()->const bool;
    private:
        struct Imp;
        std::unique_ptr<Imp> imp_;

    public:
        Current();
        ~Current();
        KAANH_DELETE_BIG_FOUR(Current)
    };


    class KAANH_API CCStop : public aris::core::CloneObject<CCStop, aris::plan::Plan>
    {
    public:
        auto virtual prepareNrt()->void override;
        explicit CCStop(const std::string &name = "CCStop");
    };

}

#endif // KAANH_PACKAGE_CURRENT_HPP_
