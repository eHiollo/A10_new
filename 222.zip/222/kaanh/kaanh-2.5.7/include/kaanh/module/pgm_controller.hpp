#ifndef KAANH_MODULE_PGM_CONTROLLER_HPP_
#define KAANH_MODULE_PGM_CONTROLLER_HPP_

#include <memory>
#include <functional>

#include "kaanh/module/middle_module.hpp"
#include "kaanh/program/program.hpp"
#include "kaanh/general/macro.hpp"
#include "kaanh_lib_export.h"

#define DATA_SUFFIX std::string(".dat")
#define SRC_SUFFIX  std::string(".src")
#define TXT_SUFFIX  std::string(".txt")
#define GLOBAL_DATA_FILE std::string("global.dat")

namespace kaanh::module {

enum class PgmMode : std::int32_t {
    kStep = 0x01,    //!< 单步模式
    kContinuous      //!< 连续模式
};


NLOHMANN_JSON_SERIALIZE_ENUM(PgmMode, {
    {PgmMode::kStep, "Step"},
    {PgmMode::kContinuous, "Continuous"}
})

enum class PgmRunDirection : std::int32_t {
    kForward = 0x01,    //!< 正向
    kBackward           //!< 逆向
};

NLOHMANN_JSON_SERIALIZE_ENUM(PgmRunDirection, {
    {PgmRunDirection::kForward, "Forward"},
    {PgmRunDirection::kBackward, "Backward"}
})

enum class PgmState : std::int32_t {
    kUnloaded = -2,     //!< 未加载工程状态
    kError,             //!< 已加载工程且异常状态 
    kInit,              //!< 已加载工程且初始状态
    kStopped,           //!< 已加载工程且停止状态
    kRunning            //!< 已加载工程且运行状态
};

NLOHMANN_JSON_SERIALIZE_ENUM(PgmState, {
    {PgmState::kUnloaded, "Unloaded"},
    {PgmState::kError, "Error"},
    {PgmState::kInit, "Init"},
    {PgmState::kStopped, "Stopped"},
    {PgmState::kRunning, "Running"}
})

enum class StmtState : std::int32_t {
    kNone = -1,
    kToExecute,
    kPaused,
    kExecuting,
    kExecuted
};

NLOHMANN_JSON_SERIALIZE_ENUM(StmtState, {
    {StmtState::kNone, "None"},
    {StmtState::kToExecute, "ToExecute"},
    {StmtState::kPaused, "Paused"},
    {StmtState::kExecuting, "Executing"},
    {StmtState::kExecuted, "Executed"}
})

class KAANH_API PgmController : public MiddleModule {
public:
    auto virtual init()->void override;

    auto virtual execute(const std::string &str, std::function<void(std::string)> send_ret) noexcept->std::pair<std::string, std::string> override;

public:
    auto config() noexcept->program::PgmConfig&;
    auto config() const noexcept->const program::PgmConfig& { return const_cast<PgmController*>(this)->config(); }
    auto resetConfig(program::PgmConfig *config)->void;
    auto calculator() noexcept->program::PgmCalculator&;
    auto calculator() const noexcept->const program::PgmCalculator& { return const_cast<PgmController*>(this)->calculator(); }
    auto resetCalculator(program::PgmCalculator *calculator)->void;
    auto translator() noexcept->program::PgmTranslator&;
    auto translator() const noexcept->const program::PgmTranslator& { return const_cast<PgmController*>(this)->translator(); }
    auto resetTranslator(program::PgmTranslator *translator)->void;
    auto executer() noexcept->program::PgmExecuter&;
    auto executer() const noexcept->const program::PgmExecuter& { return const_cast<PgmController*>(this)->executer(); }
    auto resetExecuter(program::PgmExecuter *executer)->void;

    auto path() const noexcept->std::string;
    auto resetPath(const std::string &path)->void;
    auto autoSave() const noexcept->bool;
    auto resetAutoSave(bool auto_save)->void;

    static auto instanceInCs()->PgmController&;

public:
    // 和软PLC模块共用全局变量
    auto globalDataPkg()->const std::shared_ptr<kaanh::program::DataPkg>&;
    auto resetGlobalDataPkg(const std::shared_ptr<kaanh::program::DataPkg> &gdatas)->void;

private:
    class State {
    public:
        State(PgmController *controller) { controller_ = controller; };
        virtual ~State() = default;

    protected:
        PgmController *controller_;

    public:
        auto virtual setRunMode(PgmMode run_mode)->void = 0;
        auto virtual setRunDirection(PgmRunDirection run_direction)->void = 0;
        auto virtual setPc(const std::string &pgm_name, int line)->void = 0;
        auto virtual reset()->void = 0;
        auto virtual load(const std::string &prj_name, const std::string &pgm_name="")->void = 0;
        auto virtual unload()->void = 0;
        auto virtual start()->void = 0;
        auto virtual stop()->void = 0;
        auto virtual clearError()->void = 0;
        auto virtual addVar(const std::string &space, const std::string &name, const std::string &val)->void = 0;
        auto virtual updateVarInMem(const std::string &space, const std::string &name, const std::string &val)->void = 0;
        auto virtual updateVar(const std::string &space, const std::string &name, const std::string &val)->void = 0;
        auto virtual deleteVar(const std::string &space, const std::string &name)->void = 0;
        auto virtual renameVar(const std::string &space, const std::string &old_name, const std::string &new_name)->void = 0;
        auto virtual insertStmts(const std::string &pgm_name, int before_line, const std::string &content)->void = 0; 
        auto virtual removeStmts(const std::string &pgm_name, int start_line, int end_line)->void = 0;
        auto virtual updateStmt(const std::string &pgm_name, int line, const std::string &content)->void = 0; 
        auto virtual commentStmts(const std::string &pgm_name, int start_line, int end_line)->void = 0;   
        auto virtual uncommentStmts(const std::string &pgm_name, int start_line, int end_line)->void = 0;
        auto virtual syncArpToMrp()->void = 0;
    };

#define STATE_DECL_HELPER(STATE)\
class STATE : public State {\
public:\
    STATE(PgmController *controller) : State(controller) {}\
    ~STATE() = default;\
    auto setRunMode(PgmMode run_mode)->void override;\
    auto setRunDirection(PgmRunDirection run_direction)->void override;\
    auto setPc(const std::string &pgm_name, int line)->void override;\
    auto reset()->void override;\
    auto load(const std::string &prj_name, const std::string &pgm_name="")->void override;\
    auto unload()->void override;\
    auto start()->void override;\
    auto stop()->void override;\
    auto clearError()->void override;\
    auto addVar(const std::string &space, const std::string &name, const std::string &val)->void override;\
    auto updateVarInMem(const std::string &space, const std::string &name, const std::string &val)->void override;\
    auto updateVar(const std::string &space, const std::string &name, const std::string &val)->void override;\
    auto deleteVar(const std::string &space, const std::string &name)->void override;\
    auto renameVar(const std::string &space, const std::string &old_name, const std::string &new_name)->void override;\
    auto insertStmts(const std::string &pgm_name, int before_line, const std::string &content)->void override;\
    auto removeStmts(const std::string &pgm_name, int start_line, int end_line)->void override;\
    auto updateStmt(const std::string &pgm_name, int line, const std::string &content)->void override;\
    auto commentStmts(const std::string &pgm_name, int start_line, int end_line)->void override;\
    auto uncommentStmts(const std::string &pgm_name, int start_line, int end_line)->void override;\
    auto syncArpToMrp()->void override;\
};

    STATE_DECL_HELPER(Unloaded)
    STATE_DECL_HELPER(Error)
    STATE_DECL_HELPER(Init)
    STATE_DECL_HELPER(Stopped)
    STATE_DECL_HELPER(Running)

#undef STATE_DECL_HELPER

    using ShpState = std::shared_ptr<State>;

    auto setState(PgmState state) noexcept->void;
    auto setStmtState(StmtState state) noexcept->void;
    auto setThreadId(const std::thread::id &id)->void;

public:
    // 状态机操作
    auto setRunMode(PgmMode run_mode)->void;
    auto setRunDirection(PgmRunDirection run_direction)->void;
    auto setPc(const std::string &pgm_name, int line)->void;
    auto reset()->void;
    auto load(const std::string &prj_name, const std::string &pgm_name="")->void;
    auto unload()->void;
    auto start()->void;
    auto stop()->void;
    auto clearError()->void;  
    auto addVar(const std::string &space, const std::string &name, const std::string &val)->void;
    auto updateVarInMem(const std::string &space, const std::string &name, const std::string &val)->void;
    auto updateVar(const std::string &space, const std::string &name, const std::string &val)->void;
    auto deleteVar(const std::string &space, const std::string &name)->void;
    auto renameVar(const std::string &space, const std::string &old_name, const std::string &new_name)->void;
    auto insertStmts(const std::string &pgm_name, int before_line, const std::string &content)->void;
    auto removeStmts(const std::string &pgm_name, int start_line, int end_line)->void;
    auto updateStmt(const std::string &pgm_name, int line, const std::string &content)->void;
    auto commentStmts(const std::string &pgm_name, int start_line, int end_line)->void;
    auto uncommentStmts(const std::string &pgm_name, int start_line, int end_line)->void;
    auto syncArpToMrp()->void;

    // 访问操作
    auto state() const noexcept->PgmState;
    auto runMode() const noexcept->PgmMode;
    auto runDirection() const noexcept->PgmRunDirection;
    auto isEdited() const noexcept->bool;
    auto loadedInfo() const noexcept->const std::pair<std::string, std::string>&;
    auto pc() const noexcept->std::pair<std::string, int>;
    auto isToStop() const noexcept->bool;
    auto lastStoppedMotorPos() const->std::vector<std::vector<double>>;
    auto setLastStoppedMotorPos(const std::vector<std::vector<double>> &pos)->void;
    auto stmtState() const noexcept->StmtState;
    auto threadId() const->const std::thread::id&;

    // 反射操作
    auto resetRunMode(PgmMode run_mode)->void;

    // 变量操作
    auto saveVar(const std::string &space, const std::string &name)->void;

    // 工程操作
    auto createProject(const std::string &prj_name)->void;
    auto deleteProject(const std::string &prj_name)->void;
    auto renameProject(const std::string &old_name, const std::string &new_name)->void;

    // 程序操作
    auto createProgram(const std::string &prj_name, const std::string &pgm_name)->void;
    auto deleteProgram(const std::string &prj_name, const std::string &pgm_name)->void;
    auto renameProgram(const std::string &prj_name, const std::string &old_name, const std::string &new_name)->void;

    // 注册操作
    auto registerCbkOnStateChanged(const std::function<void(PgmState last, PgmState current)> &cbk)->void;
    auto registerCbkOnCreateProject(const std::function<std::string()> &cbk)->void;
    auto registerCbkOnDeleteProject(const std::function<void(const std::string &prj_name)> &cbk)->void;
    auto registerCbkOnRenameProject(const std::function<void(const std::string &old_name, const std::string &new_name)> &cbk)->void;
    auto registerArCbk(const std::function<bool(const std::vector<std::weak_ptr<program::StatementNode>>&, const program::StatementNode&)> &cbk)->void;

    // 非原子类指令
    auto nonAtomicPlans() const->std::string;
    auto resetNonAtomicPlans(const std::string &plans)->void;
    auto isNonAtomicPlan(const std::string &plan) const->bool;

private:
    struct Imp;
    std::unique_ptr<Imp> imp_;

public:
    PgmController();
    virtual ~PgmController();
    KAANH_DELETE_BIG_FOUR(PgmController)
};

} // namespace kaanh::module

#endif  // KAANH_MODULE_PGM_CONTROLLER_HPP_