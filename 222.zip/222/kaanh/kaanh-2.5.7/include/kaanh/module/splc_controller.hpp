#ifndef KAANH_MODULE_SPLC_CONTROLLER_
#define KAANH_MODULE_SPLC_CONTROLLER_
#include "kaanh/module/pgm_controller.hpp"
#include "kaanh/general/macro.hpp"
namespace kaanh::module {

class KAANH_API SplcController : public MiddleModule {
public:
    auto virtual init()->void override;

    auto virtual execute(const std::string &str, std::function<void(std::string)> send_ret) noexcept->std::pair<std::string, std::string> override;

public:
    // 和程序模块共用全局变量
    auto globalDataPkg()->const std::shared_ptr<kaanh::program::DataPkg>&;
    auto resetGlobalDataPkg(const std::shared_ptr<kaanh::program::DataPkg> &gdatas)->void;

private:
    class State {
    public:
        State(SplcController *controller) { controller_ = controller; };
        virtual ~State() = default;

    protected:
        SplcController *controller_;

    public:
        auto virtual select(const std::string &prj_name)->void = 0;
        auto virtual unselect()->void = 0;
        auto virtual start()->void = 0;
        auto virtual stop()->void = 0;
        auto virtual restart()->void = 0;
        auto virtual clearError()->void = 0;
    };

#define STATE_DECL_HELPER(STATE)\
class STATE : public State {\
public:\
    STATE(SplcController *controller) : State(controller) {}\
    ~STATE() = default;\
    auto select(const std::string &prj_name)->void override;\
    auto unselect()->void override;\
    auto start()->void override;\
    auto stop()->void override;\
    auto restart()->void override;\
    auto clearError()->void override;\
};

    STATE_DECL_HELPER(Unloaded)
    STATE_DECL_HELPER(Init)
    STATE_DECL_HELPER(Error)
    STATE_DECL_HELPER(Stopped)
    STATE_DECL_HELPER(Running)

#undef STATE_DECL_HELPER

    using ShpState = std::shared_ptr<State>;

    auto setState(PgmState state) noexcept->void;
    auto setThreadId(const std::thread::id &id)->void;

public:
    // 访问操作
    auto selectedPrj() const noexcept->const std::string&;
    auto path() const noexcept->const std::filesystem::path&;
    auto autoStart() const noexcept->bool;
    auto state() const noexcept->PgmState;
    auto error() const noexcept->const std::string&;
    auto threadId() const->const std::thread::id&;
    auto isToStop() const noexcept->bool;

    // 修改操作
    auto resetSelectedPrj(const std::string &prj)->void;
    auto resetPath(const std::filesystem::path &path)->void;
    auto resetAutoStart(bool auto_start)->void;

    // 状态机操作
    auto select(const std::string &prj)->void;
    auto unselect()->void;
    auto start()->void;
    auto stop()->void;
    auto clearError()->void;

    static auto instanceInCs()->SplcController&;

private:
    struct Imp;
    std::unique_ptr<Imp> imp_;

public:
    SplcController();
    ~SplcController();
    KAANH_DELETE_BIG_FOUR(SplcController)
};

// 暂停程序
class KAANH_API pauseProgram : public aris::core::CloneObject<pauseProgram, aris::plan::Plan>
{
public:
    auto virtual prepareNrt() -> void;
    explicit pauseProgram(const std::string &name = "pauseProgram");
};

}   // namespace kaanh::module

#endif  // KAANH_MODULE_SPLC_CONTROLLER_
