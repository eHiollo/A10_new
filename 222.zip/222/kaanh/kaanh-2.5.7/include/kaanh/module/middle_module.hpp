#ifndef KAANH_MODULE_MIDDLE_MODULE_HPP_
#define KAANH_MODULE_MIDDLE_MODULE_HPP_

#include <string>
#include <functional>

#include "kaanh/log/log.hpp"
#include "kaanh/general/macro.hpp"
#include "kaanh_lib_export.h"

#define RET_CODE "ret_code"
#define RET_MSG "ret_msg"
#define RET_CONTEXT "ret_context"
#define END_CMD_FLOW return {"", ""}

namespace kaanh::module {

class KAANH_API MiddleModule {
public:
    auto virtual name() const->const std::string { return name_; }
    auto virtual setName(const std::string &name)->void { name_ = name; }
    auto virtual init()->void {}
    auto virtual execute(const std::string &str, std::function<void(std::string)> send_ret) noexcept->std::pair<std::string, std::string> = 0;

    static auto sendRet(const std::function<void(std::string)> &send_ret, int ret_code = 0, const std::string &ret_msg = "", const std::string &ret_context = "")->void;
    static auto getCmdName(const std::string &cmd)->std::string;

private:
    std::string name_;

public:
    MiddleModule() = default;
    virtual ~MiddleModule() = default;
    KAANH_DELETE_BIG_FOUR(MiddleModule)
};

}   // namespace kaanh::module

#endif  // KAANH_MODULE_MIDDLE_MODULE_HPP_
