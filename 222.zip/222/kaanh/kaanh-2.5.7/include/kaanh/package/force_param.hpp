#ifndef KAANH_PACKAGE_FORCE_PARAM_HPP_
#define KAANH_PACKAGE_FORCE_PARAM_HPP_
#include "aris.hpp"
#include "kaanh/general/macro.hpp"
namespace kaanh::package{
    class AdmittanceParamBase{
        public:
        AdmittanceParamBase() = default;
        ~AdmittanceParamBase() = default;
        auto setFcOpen(const bool &val)->void{ is_open = val; }
        auto getFcOpen()const->const bool& { return is_open; }
        auto setReferToTool(const bool &is_tool)->void{ refer_to_tool = is_tool; }
        auto getReferToTool()const->const bool& { return refer_to_tool; }
        auto setM(const std::array<double, 6> &mass)->void{m = mass; }
        auto getM()const->const std::array<double, 6>&{ return m ;}
        auto setB(const std::array<double, 6> &beta)->void {b = beta;}
        auto getB()const->const std::array<double, 6>&{ return b; }
        auto setK(const std::array<double, 6> &koe)->void { k = koe;}
        auto getK()const->const std::array<double, 6>&{ return k; }

        auto setFDeadZone(const std::array<double, 6> &fdz)->void {f_dead_zone = fdz;}
        auto getFDeadZone()const->const std::array<double, 6>&{ return f_dead_zone; }
        auto setALimit(const std::array<double, 6> &a)->void {a_limit = a; }
        auto getALimit()const->const std::array<double, 6>&{ return a_limit; }
        auto setVLimit(const std::array<double, 6> &v)->void { v_limit = v; }
        auto getVLimit()const->const std::array<double, 6>&{ return v_limit; }
        auto setPLimit(const std::array<double, 6> &p)->void { p_limit = p;}
        auto getPLimit()const->const std::array<double, 6>&{ return p_limit; }

        auto setFTarget(const std::array<double, 6> &ft)->void {f_target = ft;}
        auto getFTarget()const->const std::array<double, 6>&{ return f_target; }



        auto checkAdmitanceBase(bool is_plan=true) ->void {
            for(int i=0;i<m.size();i++){
                if(std::abs(m[i])<1e-3) LOCALE_THROW("M cannot less than zero","M数值不能为0");
            }
            for(int i=0;i<m.size();i++){
                if(std::abs(m[i])>10.0) LOCALE_THROW("M larger than 10 is not recommended","M不推荐为10以上");
            }
            for(int i = 0; i <b.size();i++){
                if(std::abs(b[i])<400.0) LOCALE_THROW("B smaller than 400 is not recommended","B不推荐为400以下");
            }
            auto checkAbs=[&](std::array<double, 6> val){
                for(int i=0;i<val.size();i++){
                    if(val[i]<0) LOCALE_THROW("param cannot less than zero","除目标力外，其它数值不能小于0");
                }
            };
            checkAbs(m);
            checkAbs(b);
            checkAbs(k);
            checkAbs(f_dead_zone);
            checkAbs(a_limit);
            checkAbs(v_limit);
            checkAbs(p_limit);
        }

        protected:
        bool is_open{false};
        bool refer_to_tool{false};
        std::array<double,6> m{1.0, 1.0, 1.0, 1.0, 1.0, 1.0}; ///< 力控参数m
        std::array<double,6> b{15000.0, 15000.0, 15000.0, 15000.0, 15000.0, 15000.0}; ///< 力控参数b
        std::array<double,6> k{0.0, 0.0, 0.0, 0.0, 0.0, 0.0}; ///< 力控参数k
        std::array<double,6> f_target{0.0, 0.0, 0.0, 0.0, 0.0, 0.0}; ///< 目标力
        std::array<double,6> f_dead_zone{0.0, 0.0, 0.0, 0.0, 0.0, 0.0}; ///< 力死区
        std::array<double,6> a_limit{100.0, 100.0, 100.0, 100.0, 100.0, 100.0}; ///< 加速度限制
        std::array<double,6> v_limit{20.0, 20.0, 20.0, 20.0, 20.0, 20.0}; ///< 速度限制
        std::array<double,6> p_limit{0.0, 0.0, 0.0, 0.0, 0.0, 0.0}; ///< 位置限制

    };
}

#endif // KAANH_PACKAGE_FORCE_PARAM_HPP_
