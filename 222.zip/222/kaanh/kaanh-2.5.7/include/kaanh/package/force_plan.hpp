#ifndef KAANH_FORCE_PLAN_HPP_
#define KAANH_FORCE_PLAN_HPP_

#include "aris.hpp"
#include "kaanh/general/macro.hpp"
#include "kaanh/module/middle_module.hpp"
#include "kaanh/middleware/middleware.hpp"
#include "kaanh/multi_motion/motion_plan.hpp"
namespace kaanh::package {


//hpp中的plan模板  不用了
class KAANH_API forceedge
{
public:
        auto virtual getrisingedge()->bool { return is_risingedge; };
        auto virtual getfallingedge()->bool { return is_fallingedge; };
        auto virtual resetrisingedge()->void { is_risingedge = false; };
        auto virtual resetfallingedge()->void { is_fallingedge = false; };
        auto virtual updateforce(double f[6], double pe[6], double pe_now[6], double pe_target[6], std::array<double, 6> step)->void;
        int16_t rising_sign[6] = { 0,0,0,0,0,0 };
        int16_t falling_sign[6] = { 0,0,0,0,0,0 };

private:
        double f_last[6] = { 0,0,0,0,0,0 };
        double f_now[6] = { 0,0,0,0,0,0 };
        double threshold_up[6] = { 6,6,6,0.8,0.5,0.4 };
        double threshold_down[6] = { 4,4,4,0.5,0.2,0.2 };
        bool f_io_last[6] = { false,false,false,false,false,false };
        bool f_io_now[6] = { false,false,false,false,false,false };
        bool is_risingedge = false;
        bool is_fallingedge = false;
};



class KAANH_API Yuli : public aris::core::CloneObject<Yuli, aris::plan::Plan>
{
public:
        auto virtual prepareNrt()->void override;
        auto virtual executeRT()->int override;
        explicit Yuli(const std::string &name = "Yuli_plan");
};

class KAANH_API Ati : public aris::core::CloneObject<Ati, aris::plan::Plan>
{
public:
        auto virtual prepareNrt()->void override;
        auto virtual executeRT()->int override;
        explicit Ati(const std::string &name = "Ati_plan");
};

class KAANH_API Kunwei : public aris::core::CloneObject<Kunwei, aris::plan::Plan>
{
public:
        auto virtual prepareNrt()->void override;
        auto virtual executeRT()->int override;
        explicit Kunwei(const std::string &name = "Kunwei_plan");
};

// 停止拖拽
class FCStop : public aris::core::CloneObject<FCStop, aris::plan::Plan>
{
public:
    auto virtual prepareNrt()->void override;
    explicit FCStop(const std::string &name = "FCStop");
};

//轨迹复现  用于程序模块  程序停止 
// 走到一半只能重新开始  关节位置
class KAANH_API ForceTrace : public aris::core::CloneObject<ForceTrace, aris::plan::Plan>
{
public:
auto virtual prepareNrt()->void override;
auto virtual executeRT()->int override;
auto virtual collectNrt()->void override;
~ForceTrace();
explicit ForceTrace(const std::string &name = "ForceTrace");
KAANH_DECLARE_BIG_FOUR(ForceTrace)

private:
struct Imp;
aris::core::ImpPtr<Imp> imp_;
};

//轨迹复现 用于前端按钮发送指令  fc_status停止 
// 不再程序使用
class KAANH_API ForceTracePlan : public aris::core::CloneObject<ForceTracePlan, aris::plan::Plan>
{
public:
auto virtual prepareNrt()->void override;
auto virtual executeRT()->int override;
auto virtual collectNrt()->void override;
~ForceTracePlan();
explicit ForceTracePlan(const std::string &name = "ForceTracePlan");
KAANH_DECLARE_BIG_FOUR(ForceTracePlan)

private:
struct Imp;
aris::core::ImpPtr<Imp> imp_;
};

// 力控磨料补偿开启监控
class KAANH_API FCMonitor : public aris::core::CloneObject<FCMonitor, aris::plan::Plan>
{
public:
        auto virtual prepareNrt()->void override;
        auto virtual executeRT()->int override;
        auto virtual collectNrt()->void override;
        explicit FCMonitor(const std::string &name = "FCMonitor_plan");
};
// 每加工一片料补偿了多少的记录，用于后续加工
class KAANH_API SaveProXml : public aris::core::CloneObject<SaveProXml, aris::plan::Plan>
{
public:
        auto virtual prepareNrt()->void override;
        auto virtual executeRT()->int override;
        auto virtual collectNrt()->void override;
        explicit SaveProXml(const std::string &name = "SaveProXml_plan");
};
// 换轮子（刀具）   清除之前的所有补偿
class KAANH_API ResetFCMoitor : public aris::core::CloneObject<ResetFCMoitor, aris::plan::Plan>
{
public:
        auto virtual prepareNrt()->void override;
        explicit ResetFCMoitor(const std::string &name = "ResetFCMoitor");
private:
        int fs_id{-1};
};
// 
class KAANH_API SetFCMoitor : public aris::core::CloneObject<SetFCMoitor, aris::plan::Plan>
{
public:
auto virtual prepareNrt()->void override;
auto virtual executeRT()->int override;
explicit SetFCMoitor(const std::string &name = "SetFCMoitor");
};




class KAANH_API Assemble : public aris::core::CloneObject<Assemble, aris::plan::Plan>
{
public:
auto virtual prepareNrt()->void override;
auto virtual executeRT()->int override;
auto virtual collectNrt()->void override;
explicit Assemble(const std::string &name = "Assemble");

private:
        struct Imp;
        aris::core::ImpPtr<Imp> imp_;
};


class KAANH_API AxisAssemble : public aris::core::CloneObject<AxisAssemble, aris::plan::Plan>
{
public:
auto virtual prepareNrt()->void override;
auto virtual executeRT()->int override;
auto virtual collectNrt()->void override;
explicit AxisAssemble(const std::string &name = "AxisAssemble");

private:
        struct Imp;
        aris::core::ImpPtr<Imp> imp_;
};



class KAANH_API ForceGuidanceBeforeRealForce: public aris::core::CloneObject<ForceGuidanceBeforeRealForce, aris::plan::Plan>
{
public:
auto virtual prepareNrt()->void override;
auto virtual executeRT()->int override;
auto virtual collectNrt()->void override;
explicit ForceGuidanceBeforeRealForce(const std::string &name = "ForceGuidanceBeforeRealForce");
private:
        struct Imp;
        aris::core::ImpPtr<Imp> imp_;
};

class KAANH_API ForceMonitor : public aris::core::CloneObject<ForceMonitor, aris::plan::Plan>
{
public:
        auto virtual prepareNrt()->void override;
        auto virtual executeRT()->int override;
        auto virtual collectNrt()->void override;
        explicit ForceMonitor(const std::string &name = "ForceMonitor");
};

class KAANH_API SetZero : public aris::core::CloneObject<SetZero, aris::plan::Plan>
{
public:
    auto virtual prepareNrt()->void override;
    auto virtual executeRT()->int override;
    explicit SetZero(const std::string &name = "SetZero");
};



//class KAANH_API ForceControlInit : public aris::core::CloneObject<ForceControlInit, aris::plan::Plan>
//{
//public:
//auto virtual prepareNrt()->void override;
//auto virtual executeRT()->int override;
//auto virtual collectNrt()->void override;
//explicit ForceControlInit(const std::string &name = "ForceControlInit");
//~ForceControlInit();
//KAANH_DECLARE_BIG_FOUR(ForceControlInit)
//private:
//struct Imp;
//aris::core::ImpPtr<Imp> imp_;
//};

class KAANH_API SetForceLoadId : public aris::core::CloneObject<SetForceLoadId, aris::plan::Plan>
{
public:
auto virtual prepareNrt()->void override;
auto virtual executeRT()->int override;
auto virtual collectNrt()->void override;
private:
int force_load_id_{-1};
int fs_id{-1};
public:
SetForceLoadId();
};



} // namespace force_plan

#endif //KAANH_FORCE_PLAN_HPP_
