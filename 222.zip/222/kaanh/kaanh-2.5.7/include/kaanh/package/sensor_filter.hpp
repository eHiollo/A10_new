#ifndef KAANH_PACKAGE_SENSOR_FILTER_H
#define SKAANH_PACKAGE_ENSOR_FILTER_H

#include <string>
#include <vector>

namespace kaanh::package {

class SensorFilter {
    /*
    SMALLWINDOW: abs(freq_low - freq_high) = 2.55 * freq_sample / (17 - 1)
    MIDWINDOW: abs(freq_low - freq_high) = 2.55 * freq_sample / (33 - 1)
    BIGWINDOW: abs(freq_low - freq_high) = 2.55 * freq_sample / (65 - 1)
    */

public:
    enum class FilterModeType {
        MEANFILTER = 100,
        MEDIUMFILTER = 200,
        MIDMEANFILTER = 300,
        LOWPASSFILTER = 400,
        HIGHPASSFILTER = 500,
        BANDPASSFILTER = 600,
        BANDSTOPFILTER = 700
    };
    enum class WindowSizeType {
        SMALLWINDOW = 33,
        MIDWINDOW = 65,
        BIGWINDOW = 129
    };
    // Traditional filter
    SensorFilter(FilterModeType filter_mode, WindowSizeType win_size);
    // FIR fliter
    SensorFilter(FilterModeType filter_mode, int freq_low, int freq_high, int freq_sample, WindowSizeType win_size);

public:
    double getFilteredSignalPoint(double ori_signal_point);

private:
    void traditionalFilterInit();
    void firFilterInit(int freq_low, int freq_high, int freq_sample);
    double meanFilter();
    double mediumFilter();
    double midMeanFilter();
    double firFilter();
    double windowWeighting(const std::vector<double>& data_in_window);

private:
    FilterModeType filter_mode_;
    int win_size_;
    std::vector<double> filter_coef_;
    std::vector<double> ori_signal_databuff_;
    int data_index_;
};

}



#endif
