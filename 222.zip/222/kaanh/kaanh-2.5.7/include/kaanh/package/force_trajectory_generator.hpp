#ifndef KAANH_PACKAGE_FORCE_TRAJECTORY_GENERATOR_HPP_
#define KAANH_PACKAGE_FORCE_TRAJECTORY_GENERATOR_HPP_


#include "kaanh/package/force_algorithm.hpp"

using namespace kaanh::package;


namespace kaanh::package{
    /**
     * @brief 根据上一周期的速度，本周期的加速度，计算本周期的速度
     * 
     * @param v_last 上一周期的速度
     * @param a_now 本周期的加速度
     * @param delta_t 同步周期delta_t(单位s)
     * @param v_now 本周期的速度
     */
    auto calVel(const std::array<double, 6>&v_last, const std::array<double, 6>&a_now, const double &delta_t, std::array<double, 6>&v_now)->void;
    /**
     * @brief 根据上一周期的累计补偿位姿，本周期的速度，计算本周期的累计补偿位姿
     * 
     * @param pe_last 上一周期的累计补偿位姿
     * @param v_now 本周期的速度
     * @param delta_t 同步周期delta_t(单位s)
     * @param pe_now 本周期的累计补偿位姿
     * @param eu_type_out 欧拉角顺序
     */
    auto calPe(const std::array<double, 6> &pe_last, const std::array<double, 6> &v_now, const double &delta_t, std::array<double, 6> &pe_now, const char *eu_type_out="123")->void;
    /**
     * @brief 计算本周期速度产生的位姿矩阵
     * 
     * @param v_now 本周期的速度
     * @param delta_t 同步周期delta_t(单位s)
     * @param pm 速度产生的位姿矩阵
     */
    auto calPm(const std::array<double, 6> &v_now, const double &delta_t, std::array<double, 16> &pm)->void;
    /**
     * @brief 
     * 
     */
    class ForceTrajectoryGenerator{
    public:
        /**
         * @brief 隐式欧拉法对导纳公式进行离散化，用于力控拖拽，相比于其他方法，具有更强的数值稳定性，适用于高阻尼高刚度情况
         * 
         * @param m 质量向量
         * @param b 阻尼向量
         * @param fsl 力传感器负载ForceSensorLoad
         * @param f_dead_zone 力矩死区
         * @param v_last 上一周期速度
         * @param fs_to_base_pm 力传感器相对于base的位姿矩阵
         * @param fs_to_ref_pm 力传感器相对于目标坐标系的位姿矩阵 
         * @param deltaT 同步周期delta_t(单位s)
         * @param v_now 输出：本周期的速度
         */
        auto ImplicitEulerMB(const std::array<double,6> &m,const std::array<double,6> &b,const ForceSensorLoad &fsl,  
            const std::array<double, 6> &f_dead_zone, const std::array<double, 6> &v_last,
            const std::array<double, 16> &fs_to_base_pm, const std::array<double, 16> &fs_to_ref_pm, 
            const double deltaT,std::array<double, 6> &v_now)->void;
        /**
         * @brief 用于力控拖拽，生成周期加速度
         * 
         * @param m 质量向量
         * @param b 阻尼向量
         * @param k 刚度向量
         * @param fsl 力传感器负载ForceSensorLoad
         * @param f_dead_zone 力矩死区
         * @param v_last 上一周期速度
         * @param fs_to_base_pm 力传感器相对于base的位姿矩阵
         * @param fs_to_ref_pm 力传感器相对于目标坐标系的位姿矩阵
         * @param a_now 本周期的加速度
         */
        auto forceTrajectoryGenerator(const std::array<double,6> &m,const std::array<double,6> &b,const std::array<double,6> &k,const ForceSensorLoad &fsl,  const std::array<double, 6> &f_dead_zone, const std::array<double, 6> &v_last,
                                      const std::array<double, 16> &fs_to_base_pm, const std::array<double, 16> &fs_to_ref_pm, std::array<double, 6> &a_now)->void;
        /**
         * @brief 用于带力控移动
         * 
         * @param m 质量向量
         * @param b 阻尼向量
         * @param k 刚度向量
         * @param fsl 力传感器负载ForceSensorLoad
         * @param f_dead_zone 力矩死区
         * @param ft 期望力和力矩
         * @param v_last 上一周期速度
         * @param p_last 上一个周期的位置
         * @param fs_to_base_pm 力传感器相对于base的位姿矩阵
         * @param fs_to_ref_pm 力传感器相对于目标坐标系的位姿矩阵
         * @param a_now 本周期的加速度
         * @param v_now 本周期的速度
         * @param f_ref 力传感器读数去皮后，转换到参考坐标系下的力
         */
        auto forceTrajectoryGeneratorCompleteFv(const std::array<double,6> &m,const std::array<double,6> &b,const std::array<double,6> &k,const ForceSensorLoad &fsl, const std::array<double, 6> &f_dead_zone, const std::array<double, 6> &ft,
                                                const std::array<double, 6> &v_last, const std::array<double,6> &p_last , const std::array<double, 6>& f_last,
                                                const std::array<double, 16> &fs_to_base_pm, const std::array<double, 16> &fs_to_ref_pm, std::array<double, 6> &a_now,std::array<double, 6> &v_now,std::array<double, 6> &f_ref)->void;
        /**
         * @brief 
         * 
         * @param m 质量向量
         * @param b 阻尼向量
         * @param k 刚度向量
         * @param fsl 力传感器负载ForceSensorLoad
         * @param f_dead_zone 力矩死区
         * @param ft 期望力和力矩
         * @param v_last 上一周期速度
         * @param p_last 上一个周期的位置
         * @param fs_to_base_pm 力传感器相对于base的位姿矩阵
         * @param fs_to_ref_pm 力传感器相对于目标坐标系的位姿矩阵
         * @param a_now 本周期的加速度
         * @param v_now 本周期的速度
         */
        auto forceTrajectoryGeneratorCompleteFv2(const std::array<double,6> &m,const std::array<double,6> &b,const std::array<double,6> &k,const ForceSensorLoad &fsl, const std::array<double, 6> &f_dead_zone, const std::array<double, 6> &ft,
                                                const std::array<double, 6> &v_last, const std::array<double,6> &p_last ,const std::array<double, 16> &fs_to_base_pm, const std::array<double, 16> &fs_to_ref_pm, std::array<double, 6> &a_now,std::array<double, 6> &v_now)->void;

        /**
         * @brief 
         * 
         * @param func 
         */
        auto registerFunc(std::function<void(const std::array<double,6>&f_now,const std::array<double, 6> &ft,const std::array<double, 6> &f_dead_zone,  const std::array<double, 6> &v_last,
                                             const std::array<double,6> &p_last,const std::array<double,6> &m,const std::array<double,6> &b,const std::array<double,6> &k, std::array<double,6> &v_now)> func)->void{force_algorithm_func_=func;}
        //实时力控前的牵引 传入上次的位置
        /**
         * @brief 用于力控浮动，传入上一周期位姿速度和力，输出本周期的速度加速度
         * 
         * @param m 质量向量
         * @param b 阻尼向量
         * @param k 刚度向量
         * @param fsl 力传感器负载ForceSensorLoad
         * @param f_dead_zone 力矩死区
         * @param ft 期望力和力矩
         * @param v_last 上一周期速度
         * @param p_last 上一个周期的位置
         * @param fs_to_base_pm 力传感器相对于base的位姿矩阵
         * @param fs_to_ref_pm 力传感器相对于目标坐标系的位姿矩阵
         * @param a_now 本周期的加速度
         * @param v_now 本周期的速度
         * @param status 
         */
        auto forceGuidance(const std::array<double,6> &m,const std::array<double,6> &b,const std::array<double,6> &k,const ForceSensorLoad &fsl, const std::array<double, 6> &f_dead_zone, const std::array<double, 6> &ft,
                           const std::array<double, 6> &v_last, const std::array<double,6> &p_last , const std::array<double, 6>& f_last,
                           const std::array<double, 16> &fs_to_base_pm, const std::array<double, 16> &fs_to_ref_pm,  std::array<double, 6> &a_now,std::array<double, 6> &v_now,int &status,
                           std::array<double, 6>& f_ref)->void;

    private:
        std::function<void(const std::array<double,6>&f_now,const std::array<double, 6> &ft,const std::array<double, 6> &f_dead_zone,  const std::array<double, 6> &v_last,
                                                           const std::array<double,6> &p_last,const std::array<double,6> &m,const std::array<double,6> &b,const std::array<double,6> &k, std::array<double,6> &v_now)> force_algorithm_func_{NULL};
    };

}

#endif // KAANH_ALGORITHM_FORCE_TRAJECTORY_GENERATOR_HPP_
