#ifndef KAANH_PACKAGE_FORCE_ALGORITHM_HPP_
#define KAANH_PACKAGE_FORCE_ALGORITHM_HPP_

#include <aris.hpp>
#include "kaanh_lib_export.h"
#include "kaanh/general/json.hpp"
#include "kaanh/general/general.hpp"



namespace kaanh::package{


    constexpr double PI = 3.141592653589793;
    /**
     * @brief 这个类定义了力传感器负载。负载有以下属性：是否完成标定、时间、名称、力数据、
     * 标定结果（力传感器设置、机器人设置、重力向量、零偏、外部力）。可以使用json序列化存取。
     * 
     */
    class ForceSensorLoad{
    public:
        auto setTime(const std::string &s)->void{ time = s; }
        auto getTime()const->const std::string& { return time; }
        auto setName(const std::string &s)->void{ name = s; }
        auto getName()const->const std::string& { return name; }
        auto setForceData(const std::array<double, 6> &data)->void{ force_data = data; }
        auto getForceData()const->const std::array<double, 6>& { return force_data; }
        auto setForceSensorSetup(const std::array<double, 6> &fs_setup)->void{ force_sensor_setup = fs_setup; }
        auto getForceSensorSetup()const->const std::array<double, 6>&{ return force_sensor_setup; }
        auto setRobotSetup(const std::array<double, 2> &rt_setup)->void{ robot_setup = rt_setup; }
        auto getRobotSetup()const->const std::array<double, 2>&{ return robot_setup; }
        auto setGravityIndex(const std::array<double, 6> &g)->void{ gravity_index = g; }
        auto getGravityIndex()const->const std::array<double, 6>&{ return gravity_index; }
        auto setZeroOffset(const std::array<double, 6> &z)->void{ zero_offset = z; }
        auto getZeroOffset()const->const std::array<double, 6>&{ return zero_offset; }
        auto resetZeroOffset(const std::array<double, 16> &fs_to_base_pm)->void;
        auto getExternalForce(const std::array<double, 16> &fs_to_base_pm)const->std::array<double, 6>;
        auto setCalibrated(const bool b)->void{is_calibrated=b;}
        auto getCalibrated()const->bool{return is_calibrated;}


        auto toUi()->void{
            for(aris::Size i = 0; i < force_sensor_setup.size(); i++){
                if(i<3){
                    force_sensor_setup[i] = force_sensor_setup[i]*1000.0;
                }
                else{
                    force_sensor_setup[i] = force_sensor_setup[i]*180.0/PI;
                }
            }
        }


    private:
        std::array<double, 6> force_data; ///< 力数据

    public:
        std::string name; ///< 名称
        std::string time; ///< 时间
        std::array<double, 6> force_sensor_setup{0,0,0,0,0,0}; ///< 力传感器安装位置相对于tcp的偏移位姿{px,py,pz,rx,ry,rz}(单位：m,rad)
        std::array<double, 2> robot_setup{0,0}; ///< 机械臂安装倾角：世界坐标系绕X轴旋转角度U，世界坐标系绕基座坐标系的Y1轴选择V {U，V} (单位：rad)
        std::array<double, 6> gravity_index{0,0,0,0,0,0}; ///< 重心坐标xyz，重力分量xyz {x,y,z,fx,fy,fz} (单位：m,N)
        std::array<double, 6> zero_offset{0,0,0,0,0,0}; ///< 零偏 {fx,fy,fz,tx,ty,tz} (单位：N,Nm)
        bool is_calibrated{0}; ///< 是否完成标定

        NLOHMANN_DEFINE_TYPE_INTRUSIVE(ForceSensorLoad, name, time, force_sensor_setup)

    };

    auto crossVector(double* a, double* s, double* n)->int;



	
	class LowPass
	{
	public:
        void get_filter_data(int n_order, int fc, double Ts, double x_in, double &x_out);
	private:
		double Wc;
		double a[3]{};
		double b[3]{};
		double den = 1;
		double x_pre = 0;
		double x_last = 0;
		double y_pre = 0;
		double y_last = 0;
	};

    /**
     * @brief 轴孔装配的参数组
     * 
     */
    class KAANH_API AssembleAdmitParam{
    public:
        /**
         * @brief 初始化装配参数，将修正量置零
         * 
         */
        auto admit_cor_init()->void;
        /**
         * @brief 用于轴孔装配的力控算法
         * 
         * @param fsl 力传感器负载
         * @param fs2bpm_tmp 
         * @param pm_fce2target 
         * @param dt 时间间隔
         * @param ct 当前时间
         * @param timeout 超时时间
         * @param z_tool 当前工具z坐标
         * @param z_up 当孔的下端面接近孔平面时的z坐标读数
         * @param z_down 当孔的上端面接近孔平面时的z坐标读数
         * @param dis 
         * @param stop_fs 
         * @param fc_status 
         * @param is_stop 
         * @return std::array<double, 6> 返回力控算法计算的
         */
        auto get_assemble_pos3(const ForceSensorLoad &fsl, double fs2bpm_tmp[16],double pm_fce2target[16], double dt, int64_t ct,
        int64_t timeout, double z_tool, double z_up, double z_down, double dis,double stop_fs[6],int  fc_status, bool is_stop)->std::array<double, 6>;

        auto check(bool is_plan=true) ->void {
            for(int i=0;i<6;i++){
                if(std::abs(M[i])<1e-3) LOCALE_THROW("M cannot less than zero","M绝对值不能小于0.001");
            }
            for(int i=0;i<6;i++){
                if(std::abs(M[i])>10.0) LOCALE_THROW("M larger than 10 is not recommended","M不推荐为10以上");
            }
            for(int i = 0; i <6; i++){
                if(std::abs(B[i])<400.0) LOCALE_THROW("B smaller than 400 is not recommended","B不推荐为400以下");
            }
            auto checkAbs=[&]( double val[6],std::string name){
                for(int i=0;i<6;i++){
                    if(val[i]<0) LOCALE_THROW(name +" cannot less than zero",name+"数值不能小于0");
                }
            };
            checkAbs(M,"M");
            checkAbs(B,"B");
            checkAbs(K,"K");
            checkAbs(f_uplimit,"f_uplimit");
            checkAbs(f_downlimit,"f_downlimit");
            checkAbs(dead_zone,"dead_zone");
            checkAbs(a_limit,"a_limit");
            checkAbs(vel_limit,"vel_limit");
            checkAbs(cor_pos_limit,"cor_pos_limit");
           if(is_plan) unitConverion();
        }

        //前端单位为mm 度
        auto unitConverion()->void{
            if(!has_unit_conversioned){
                for(int i=0;i<6;i++){
                    if(i<3){
                        cor_pos_limit[i] = cor_pos_limit[i]/1000.0;
                        vel_limit[i] = vel_limit[i]/1000.0;
                        a_limit[i] = a_limit[i]/1000.0;
                    }
                    else{
                        cor_pos_limit[i] = cor_pos_limit[i] * PI/180.0;
                        vel_limit[i] = vel_limit[i] * PI/180.0;
                        a_limit[i] = a_limit[i] * PI/180.0;
                    }
                }
            }
            has_unit_conversioned=true;
        }
        // p v a的最大值限制 需要提前执行unitConversion
        auto setVlimitFromMax(std::array<double,6> v_limit_max){
            for(int i=0;i<6;i++){
                if(i<3) std::abs(vel_limit[i])<std::abs(v_limit_max[i]/1000.0) ? vel_limit[i]=std::abs(cor_pos_limit[i]) :vel_limit[i]=std::abs(v_limit_max[i]/1000.0);
                else  std::abs(vel_limit[i])<std::abs(v_limit_max[i]* PI/180.0) ? vel_limit[i]=std::abs(cor_pos_limit[i]) :vel_limit[i]=std::abs(v_limit_max[i]* PI/180.0);
            }
        }

        auto setAlimitFromMax(std::array<double,6> a_limit_max){
            for(int i=0;i<6;i++){
                if(i<3) std::abs(a_limit[i])<std::abs(a_limit_max[i]/1000.0) ? a_limit[i]=std::abs(cor_pos_limit[i]) :a_limit[i]=std::abs(a_limit_max[i]/1000.0);
                else  std::abs(a_limit[i])<std::abs(a_limit_max[i]* PI/180.0) ? a_limit[i]=std::abs(cor_pos_limit[i]) :a_limit[i]=std::abs(a_limit_max[i]* PI/180.0);
            }
        }

        auto setPlimitFromMax(std::array<double,6> p_limit_max){
            for(int i=0;i<6;i++){
                if(i<3) std::abs(a_limit[i])<std::abs(p_limit_max[i]/1000.0) ? a_limit[i]=std::abs(cor_pos_limit[i]) :a_limit[i]=std::abs(p_limit_max[i]/1000.0);
                else  std::abs(a_limit[i])<std::abs(p_limit_max[i]* PI/180.0) ? vel_limit[i]=std::abs(cor_pos_limit[i]) :vel_limit[i]=std::abs(p_limit_max[i]* PI/180.0);
            }
        }

        //传入参数
        bool is_open{false};
        double B[6]{30000,30000,30000,30000,30000,30000}, M[6]{1.0,1.0,1.0,1.0,1.0,1.0}, K[6]{0,0,0,0,0,0};    //M惯性参数,B阻尼参数,K刚度参数
        double z_up{0},z_down{0},stop_fs[6]{0,0,0,0,0,0};
        uint32_t timeout{0},tool{0},wobj{0},strategy{1},assemble_state{0};
        double ft_set[6]{0,0,0,0,0,0},f_uplimit[6]{20,20,20,3,3,3},f_downlimit[6]{5,5,5,0.5,0.5,0.5},dead_zone[6]{1,1,1,0.3,0.3,0.3},a_limit[6]{100,100,100,100,100,100},vel_limit[6]{5,5,5,1,1,1},cor_pos_limit[6]{0,0,0,0,0,0};
        //计算所需临时参数
        double cor_vel[6]{0,0,0,0,0,0}, cor_acc[6]{0,0,0,0,0,0},cor_pos_now[6]{0,0,0,0,0,0},cor_pos[6]{0,0,0,0,0,0};
        double pm_now[16] = { 1.0,0,0,0,
                        0,1.0,0,0,
                        0,0,1.0,0,
                        0,0,0,1.0 };

        AssembleAdmitParam()=default;
        ~AssembleAdmitParam()=default;
        private:
        bool has_unit_conversioned{false};

        NLOHMANN_DEFINE_TYPE_INTRUSIVE(AssembleAdmitParam,is_open,M,B,K,ft_set,f_uplimit,f_downlimit,dead_zone,a_limit,vel_limit,cor_pos_limit,z_up,z_down,timeout,tool,wobj,strategy,stop_fs)

    };

    // 齿轮装配参数
    class KAANH_API AxisAssembleAdmitParam{
    public:
        auto admit_cor_init()->void;
        auto get_axis_assemble_pos(const ForceSensorLoad &fsl, double fs2bpm_tmp[16],double pm_fce2target[16], double dt, int64_t ct,
        int64_t timeout, double z_tool, double z_down,double z_v_limit,int  fc_status, bool is_stop)->std::array<double, 6>;


        auto check(bool is_plan=true) ->void {
            for(int i=0;i<6;i++){
                if(std::abs(M[i])<1e-3) LOCALE_THROW("M cannot less than zero","M数值不能为0");
            }
            for(int i=0;i < 6;i++){
                if(std::abs(M[i])>10.0) LOCALE_THROW("M larger than 10 is not recommended","M不推荐为10以上");
            }
            for(int i = 0; i< 6;i++){
                if(std::abs(M[i])<1000.0) LOCALE_THROW("B smaller than 1000 is not recommended","B不s推荐为1000以下");
            }
            auto checkAbs=[&]( double val[6],std::string name){
                for(int i=0;i<6;i++){
                    if(val[i]<0) LOCALE_THROW(name +" cannot less than zero",name+"数值不能小于0");
                }
            };
            checkAbs(M,"M");
            checkAbs(B,"B");
            checkAbs(K,"K");
            checkAbs(f_uplimit,"f_uplimit");
            checkAbs(f_downlimit,"f_downlimit");
            checkAbs(dead_zone,"dead_zone");
            checkAbs(a_limit,"a_limit");
            checkAbs(vel_limit,"vel_limit");
            checkAbs(cor_pos_limit,"cor_pos_limit");
          if(is_plan)  unitConverion();
        }

        //a_limit v_limit cor_pos_limit单位转换
        auto unitConverion()->void{
            if(!has_unit_conversioned){
                for(int i=0;i<6;i++){
                    if(i<3){
                        cor_pos_limit[i] = cor_pos_limit[i]/1000.0;
                        vel_limit[i] = vel_limit[i]/1000.0;
                        a_limit[i] = a_limit[i]/1000.0;
                    }
                    else{
                        cor_pos_limit[i] = cor_pos_limit[i] * PI/180.0;
                        vel_limit[i] = vel_limit[i] * PI/180.0;
                        a_limit[i] = a_limit[i] * PI/180.0;
                    }
                }
            }
            has_unit_conversioned=true;
        }
        auto setVlimitFromMax(std::array<double,6> v_limit_max){
            for(int i=0;i<6;i++){
                if(i<3) std::abs(vel_limit[i])<std::abs(v_limit_max[i]/1000.0) ? vel_limit[i]=std::abs(cor_pos_limit[i]) :vel_limit[i]=std::abs(v_limit_max[i]/1000.0);
                else  std::abs(vel_limit[i])<std::abs(v_limit_max[i]* PI/180.0) ? vel_limit[i]=std::abs(cor_pos_limit[i]) :vel_limit[i]=std::abs(v_limit_max[i]* PI/180.0);
            }
        }

        auto setAlimitFromMax(std::array<double,6> a_limit_max){
            for(int i=0;i<6;i++){
                if(i<3) std::abs(a_limit[i])<std::abs(a_limit_max[i]/1000.0) ? a_limit[i]=std::abs(cor_pos_limit[i]) :a_limit[i]=std::abs(a_limit_max[i]/1000.0);
                else  std::abs(a_limit[i])<std::abs(a_limit_max[i]* PI/180.0) ? a_limit[i]=std::abs(cor_pos_limit[i]) :a_limit[i]=std::abs(a_limit_max[i]* PI/180.0);
            }
        }

        auto setPlimitFromMax(std::array<double,6> p_limit_max){
            for(int i=0;i<6;i++){
                if(i<3) std::abs(a_limit[i])<std::abs(p_limit_max[i]/1000.0) ? a_limit[i]=std::abs(cor_pos_limit[i]) :a_limit[i]=std::abs(p_limit_max[i]/1000.0);
                else  std::abs(a_limit[i])<std::abs(p_limit_max[i]* PI/180.0) ? vel_limit[i]=std::abs(cor_pos_limit[i]) :vel_limit[i]=std::abs(p_limit_max[i]* PI/180.0);
            }
        }

        //传入参数
        bool is_open{false};
        double B[6]{0,0,0,0,0,0}, M[6]{100000.0,100000.0,10000.0,100000.0,100000.0,100000.0}, K[6]{0,0,0,0,0,0};    //M惯性参数,B阻尼参数,K刚度参数
        double z_down{0},z_v_limit{0},stop_fs[6]{0,0,0,0,0,0};
        uint32_t timeout{0},tool{0},wobj{0},axis_assemble_state{0};
        double ft_set[6]{0,0,0,0,0,0},f_uplimit[6]{0,0,0,0,0,0},f_downlimit[6]{0,0,0,0,0,0},dead_zone[6]{0,0,0,0,0,0},a_limit[6]{0,0,0,0,0,0},vel_limit[6]{0,0,0,0,0,0},cor_pos_limit[6]{0,0,0,0,0,0};
        //计算所需临时参数
        double cor_vel[6]{0,0,0,0,0,0}, cor_acc[6]{0,0,0,0,0,0},cor_pos_now[6]{0,0,0,0,0,0},cor_pos[6]{0,0,0,0,0,0};
        double pm_now[16] = { 1.0,0,0,0,
                        0,1.0,0,0,
                        0,0,1.0,0,
                        0,0,0,1.0 };

        AxisAssembleAdmitParam()=default;
        ~AxisAssembleAdmitParam()=default;
    private:
        bool has_unit_conversioned{false};
        NLOHMANN_DEFINE_TYPE_INTRUSIVE(AxisAssembleAdmitParam,is_open,M,B,K,ft_set,f_uplimit,f_downlimit,dead_zone,a_limit,vel_limit,cor_pos_limit,z_down,z_v_limit,timeout,tool,wobj,stop_fs)

    };

    // 计算累计补偿值 
    // 利力控引导 ....
	class CalWobj
	{
	public:
		double wobj_pe[6];
		auto calwobj(double pe_input[6])->void;
		auto setpe_now(double pe[6])->void { std::copy(pe, pe + 6, pe_now); };
		auto setpe_last(double pe[6])->void { std::copy(pe, pe + 6, pe_last); };
		auto setwobj(double pe[6])->void { std::copy(pe, pe + 6, wobj_pe); };
		auto calwobj_init()->void;

	private:
		double pe_now[6] = { 0,0,0,0,0,0 };
		double pe_last[6] = {0,0,0,0,0,0};
	};
}

#endif	//KAANH_ALGOTITHM_FORCE_ALGORITHM_HPP_
