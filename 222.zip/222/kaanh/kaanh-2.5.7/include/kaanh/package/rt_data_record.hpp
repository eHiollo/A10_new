#ifndef KAANH_PACKAGE_RT_DATA_RECORD_HPP_
#define KAANH_PACKAGE_RT_DATA_RECORD_HPP_

#include "aris/core/data_structure.hpp"

#include "kaanh_lib_export.h"
#include "kaanh/general/general.hpp"
#include "kaanh/module/middle_module.hpp"
#include "kaanh/robot/robot.hpp"

#include <aris.hpp>
#include <aris/dynamic/screw.hpp>

#include <fstream>

namespace kaanh::package {


//mvl:pe{}
//t{};pe{};force{}
//t{};pe{};force{}
//...
//mvc:mid_pe{};end_pe{};
//t{};pe{};force{}
//t{};pe{};force{}
//t{};pe{};force{}

enum class RtDataType{
    LPosOrigin=1, //mvl原始点位 mvl:pe{}
    LPos,         //运动中的点位 pe{};
    CMidPosOrgin, //mvc原始点位 mvc_mid:pe{}
    CEndPosOrgin,
    CPos,
    Force,
    Counts
};

struct RtData{
    RtDataType type;
    uint8_t size;
    double data[64];
};

class  KAANH_API RtDataRecord: public kaanh::module::MiddleModule{
public:

    auto virtual init()->void override;
    auto virtual execute(const std::string &str, std::function<void(std::string)> send_ret) noexcept->std::pair<std::string, std::string> override;


    auto setRecordStatus(bool status)->void;
    auto recordStatus()const ->bool;

    auto setRecordCount(int count)->void;
    auto recordCount()const ->int;

    auto setFilename(std::string filename)->void ;
    auto filename()const ->std::string;

    auto pop(RtData & rt_data)->void{
        data_queue_.pop(rt_data,aris::core::AccessStrategy::kAbandon);
    }

    auto push(RtDataType type,uint8_t size,double* data)->void{
        RtData rt_data;
        rt_data.type=type;
        if(size >= 64) size=63;
        rt_data.size=size;
        std::copy(data,data+size,rt_data.data);
        data_queue_.push(rt_data,aris::core::AccessStrategy::kAbandon);
    }

    auto push(RtData rt_data)->void{
        data_queue_.push(rt_data,aris::core::AccessStrategy::kAbandon);
    }
    static auto instanceInCs()->RtDataRecord&;

private:
    aris::core::LockFreeArrayQueue<RtData> data_queue_;
    //用于
    std::ofstream ofstream_;

private:
    struct Imp;
    std::unique_ptr<Imp> imp_;

public:
    RtDataRecord();
    ~RtDataRecord();
    KAANH_DELETE_BIG_FOUR(RtDataRecord);

};

}//kaanh::package



#endif//#define KAANH_PACKAGE_RT_DATA_RECORD_HPP_
