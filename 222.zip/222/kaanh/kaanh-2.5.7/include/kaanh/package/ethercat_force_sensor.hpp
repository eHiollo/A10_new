#ifndef KAANH_PACKAGE_ETHERCAT_FORCE_SENSOR_HPP_
#define KAANH_PACKAGE_ETHERCAT_FORCE_SENSOR_HPP_

#include <memory>
#include <aris/control/control.hpp>
#include <aris/control/ethercat.hpp>
#include "kaanh/general/json.hpp"
#include "kaanh_lib_export.h"
#include "kaanh/package/force_trajectory_generator.hpp"
#include "kaanh/log/log.hpp"
#include "kaanh/multi_motion/motion_manager.hpp"


using namespace aris::control;


namespace kaanh::package{
    //力传感器保护模块
    class KAANH_API ForceProtectionModule{
    public:
        ForceProtectionModule(){};
        ~ForceProtectionModule()=default;
        // 力传感器是否启用
        auto setFSSwitch(const bool &s)->void{ fs_switch=s; }
        auto getFSSwitch()const->bool{ return fs_switch; }
        // 力控保护是否开启  原始力和坐标系下
        auto setFSProtectionSwitch(const bool &s)->void{ fs_protection_switch=s; }
        auto getFSProtectionSwitch()const->bool{ return fs_protection_switch; }
        // 原始力限制 绝对值
        auto setFSLimit(const std::array<double, 6> &v)->void{ fs_limit=v; }
        auto getFSLimit()const->std::array<double, 6>{ return fs_limit; }


        // 坐标系下的保护值
        auto setCoorMinFSLimit(const std::array<double, 6> &v)->void{ coordinate_min_limit=v; }
        auto getCoorMinFSLimit()const->std::array<double, 6>{ return coordinate_min_limit; }

        auto setCoorMaxFSLimit(const std::array<double, 6> &v)->void{ coordinate_max_limit=v; }
        auto getCoorMaxFSLimit()const->std::array<double, 6>{ return coordinate_max_limit; }
        // 限制在工具还是工件
        auto setLimitIsRefTool(const bool &s)->void{ limit_is_ref_tool=s; }
        auto getLimitIsRefTool()const->bool {return limit_is_ref_tool;}
        // 具体的坐标号 
        auto setFSProtectionCoorNum(const int &s)->void{ coordinate_num=s; }
        auto getFSProtectionCoorNum()const->int{ return coordinate_num; }
        // 坐标系下的方向
        auto setCoorFSLimitDirection(const std::array<bool, 6> &v)->void{ check_coordinate_direction=v; }
        auto getCoorFSLimitDirection()const->std::array<bool, 6>{ return check_coordinate_direction; }

        // 配合前端设置参数
        auto setCoordinateProtection(const ForceProtectionModule &fpm)->void{
            setCoorMinFSLimit(fpm.getCoorMinFSLimit());
            setCoorMaxFSLimit(fpm.getCoorMaxFSLimit());
            setLimitIsRefTool(fpm.getLimitIsRefTool());
            setFSProtectionCoorNum(fpm.getFSProtectionCoorNum());
            setCoorFSLimitDirection(fpm.getCoorFSLimitDirection());
        }


    private:
        bool fs_switch{false};
        bool fs_protection_switch{true};
        std::array<double, 6> fs_limit{{0.0,0.0,0.0,0.0,0.0,0.0}};

        //力控拖拽开启前的保护校验
        std::array<double,6> pre_forceguidance_limit{10,10,10,0,0,0};
        std::array<bool,6> check_dimension{true,true,true,true,true,true};

      //力控坐标系下的保护数值
        std::array<double,6> coordinate_max_limit{20,20,20,2,2,2};
        std::array<double,6> coordinate_min_limit{-20,-20,-20,-2,-2,-2};
        bool limit_is_ref_tool{true};
        int coordinate_num{0};
        std::array<bool,6> check_coordinate_direction{false,false,false,false,false,false};

        NLOHMANN_DEFINE_TYPE_INTRUSIVE(ForceProtectionModule, coordinate_max_limit, coordinate_min_limit, limit_is_ref_tool, coordinate_num, check_coordinate_direction)


    };

    //力控拖拽json解析参数类
    //保存多组参数，开启时选择一组
    /**
     * @brief 该类存储了力控拖拽的参数，包括质量，阻尼，刚度，力矩死区，加速度限制，速度限制，是否参考工具，坐标系号，力矩方向，是否开启。可以使用json序列化存取。
     * 
     */
    class KAANH_API ForceSensorGuidanceModule{
    public:
        auto setName(const std::string &s)->void{ name = s; }
        auto getName()const->const std::string& { return name; }
        auto setM(const std::vector<double> &mass)->void{
            std::vector<double> tmp;
            for(int i=0;i<mass.size();i++){
                tmp.push_back(std::abs(mass[i]) > 0.1 ? std::abs(mass[i]):0.1 );
            }
            m = tmp;
        }
        auto getM()const->const std::vector<double>&{ return m ;}
        auto setB(const std::vector<double> &beta)->void {
            std::vector<double> tmp;
            for(int i=0;i<beta.size();i++){
                tmp.push_back(std::abs(beta[i]));
            }
            b = tmp;
        }
        auto getB()const->const std::vector<double>&{ return b; }
        auto setK(const std::vector<double> &koe)->void {
            std::vector<double> tmp;
            for(int i=0;i<koe.size();i++){
                tmp.push_back(std::abs(koe[i]));
            }
            k = tmp;
        }
        auto getK()const->const std::vector<double>&{ return k; }
        auto setFDeadZone(const std::vector<double> &fdz)->void {
            std::vector<double> tmp;
            for(int i=0;i<fdz.size();i++){
                tmp.push_back(std::abs(fdz[i]));
            }
            f_dead_zone = tmp;
        }
        auto getFDeadZone()const->const std::vector<double>&{ return f_dead_zone; }
        auto setALimit(const std::vector<double> &a)->void {
            std::vector<double> tmp;
            for(int i=0;i<a.size();i++){
                tmp.push_back(std::abs(a[i]));
            }
            a_limit = tmp;
        }
        auto getALimit()const->const std::vector<double>&{ return a_limit; }
        auto setVLimit(const std::vector<double> &v)->void {
            std::vector<double> tmp;
            for(int i=0;i<v.size();i++){
                tmp.push_back(std::abs(v[i]));
            }
            v_limit = tmp;
        }
        auto getVLimit()const->const std::vector<double>&{ return v_limit; }
        auto setIsRefTool(const bool &v)->void { is_ref_tool = v; }
        auto getIsRefTool()const->const bool&{ return is_ref_tool; }
        auto setCoordinateNum(const int &v)->void { coordinate_num = v; }
        auto getCoordinateNum()const->const int&{ return coordinate_num; }
        auto setDirection(const std::array<bool, 6> &v)->void { direction = v; }
        auto getDirection()const->const std::array<bool, 6>& { return direction; }
        // 当前力传感器是否开拖拽
        auto setIsOpen(const bool &v)->void { is_open = v; }
        auto getIsOpen()const->const bool&{ return is_open; }


    private:
        std::string name;
        std::vector<double> m{1,1,1,1,1,1}; ///<质量系数
        std::vector<double> b{400,400,400,400,400,400}; ///<阻尼系数
        std::vector<double> k{0,0,0,0,0,0}; ///<刚度系数
        std::vector<double> f_dead_zone{1,1,1,0.5,0.5,0.5}; ///<力矩死区
        std::vector<double> a_limit{100,100,100,100,100,100}; ///<加速度限制
        std::vector<double> v_limit{50,50,50,10,10,10}; ///<速度限制
        bool is_ref_tool{false}; ///<是否参考工具
        int coordinate_num{0}; ///<坐标系号
        std::array<bool, 6> direction{false,false,false,false,false,false}; ///<力矩方向
        bool is_open{false}; ///<是否开启
        NLOHMANN_DEFINE_TYPE_INTRUSIVE(ForceSensorGuidanceModule, name, m, b, k, f_dead_zone, a_limit, v_limit,is_ref_tool,coordinate_num,direction,is_open)
    };

    //实时力控json解析参数类
    //用于json序列化，保存在文本中，将会有多个文本
    //json 解析的时候并不会调用setM getM!! 无法保证数据的正确性
    // 实时力控记录参数
    class KAANH_API ForceTrajectoryGeneratorMoveParam{
    public:
        auto setFcOpen(const bool &val)->void{ is_open = val; }
        auto getFcOpen()const->const bool& { return is_open; }
        auto setReferToTool(const bool &is_tool)->void{ refer_to_tool = is_tool; }
        auto getReferToTool()const->const bool& { return refer_to_tool; }
        auto setM(const std::array<double, 6> &mass)->void{m = mass; }
        auto getM()const->const std::array<double, 6>&{ return m ;}
        auto setB(const std::array<double, 6> &beta)->void {b = beta;}
        auto getB()const->const std::array<double, 6>&{ return b; }
        auto setK(const std::array<double, 6> &koe)->void { k = koe;}
        auto getK()const->const std::array<double, 6>&{ return k; }

        auto setFDeadZone(const std::array<double, 6> &fdz)->void {f_dead_zone = fdz;}
        auto getFDeadZone()const->const std::array<double, 6>&{ return f_dead_zone; }
        auto setALimit(const std::array<double, 6> &a)->void {a_limit = a; }
        auto getALimit()const->const std::array<double, 6>&{ return a_limit; }
        auto setVLimit(const std::array<double, 6> &v)->void { v_limit = v; }
        auto getVLimit()const->const std::array<double, 6>&{ return v_limit; }
        auto setPLimit(const std::array<double, 6> &p)->void { p_limit = p;}
        auto getPLimit()const->const std::array<double, 6>&{ return p_limit; }

        auto setFTarget(const std::array<double, 6> &ft)->void {f_target = ft;}
        auto getFTarget()const->const std::array<double, 6>&{ return f_target; }



        auto check(bool is_plan=true) ->void {
            for(int i=0;i<m.size();i++){
                if(std::abs(m[i])<1e-3) LOCALE_THROW("M cannot less than zero","M数值不能为0");
            }
            for(int i=0;i<m.size();i++){
                if(std::abs(m[i])>10.0) LOCALE_THROW("M larger than 10 is not recommended","M不推荐为10以上");
            }
            for(int i = 0; i <3;i++){
                if(std::abs(b[i])<400.0) LOCALE_THROW("translation B smaller than 400 is not recommended","B不推荐为400以下");
            }
            for(int i = 3; i <6;i++){
                if(std::abs(b[i])<40.0) LOCALE_THROW("rotation B smaller than  is not recommended","B不推荐为400以下");
            }
            auto checkAbs=[&](std::array<double, 6> val){
                for(int i=0;i<val.size();i++){
                    if(val[i]<0) LOCALE_THROW("param cannot less than zero","除目标力外，其它数值不能小于0");
                }
            };
            checkAbs(m);
            checkAbs(b);
            checkAbs(k);
            checkAbs(f_dead_zone);
            checkAbs(a_limit);
            checkAbs(v_limit);
            checkAbs(p_limit);
           if(is_plan) unitConversion();
        }

        auto unitConversion()->void{
            if(!has_unit_conversioned){
                for(int i=0;i<6;i++){
                    if(i<3){
                        p_limit[i] = p_limit[i]/1000.0;
                        v_limit[i] = v_limit[i]/1000.0;
                        a_limit[i] = a_limit[i]/1000.0;
                    }
                    else{
                        p_limit[i] = p_limit[i] * PI/180.0;
                        v_limit[i] = v_limit[i] * PI/180.0;
                        a_limit[i] = a_limit[i] * PI/180.0;
                    }
                }
            }
            has_unit_conversioned=true;
        }

        ForceTrajectoryGeneratorMoveParam()=default;
        ~ForceTrajectoryGeneratorMoveParam()=default;

    private:
        bool has_unit_conversioned{false};
        bool is_open{false};
        bool refer_to_tool{false};
        std::array<double, 6> m{1.0,1.0,1.0,1.0,1.0,1.0};
        std::array<double, 6> b{30000.0,30000.0,30000.0,30000.0,30000.0,30000.0};
        std::array<double, 6> k{0.0,0.0,0.0,0.0,0.0,0.0};

        std::array<double, 6> f_target{0.0,0.0,0.0,0.0,0.0,0.0};
        std::array<double, 6> f_dead_zone{1.0,1.0,1.0,0.30,0.30,0.30};
        std::array<double, 6> a_limit{100.0,100.0,100.0,100.0,100.0,100.0};
        std::array<double, 6> v_limit{5.0,5.0,5.0,0.5,0.5,0.5};
        std::array<double, 6> p_limit{0.0,0.0,0.0,0.0,0.0,0.0};

        NLOHMANN_DEFINE_TYPE_INTRUSIVE(ForceTrajectoryGeneratorMoveParam,is_open,refer_to_tool,m,b,k,f_target,f_dead_zone,a_limit,v_limit,p_limit)
    };


    //力控浮动（虚假力）/牵引
    class KAANH_API ForceGuidanceAdmitParam{
    public:
        // 解决多力传感器 
        auto setFcOpen(const bool &val)->void{ is_open = val; }
        auto getFcOpen()const->const bool& { return is_open; }
        auto setReferToTool(const bool &is_tool)->void{ refer_to_tool = is_tool; }
        auto getReferToTool()const->const bool& { return refer_to_tool; }
        auto setM(const std::array<double, 6> &mass)->void{m = mass; }
        auto getM()const->const std::array<double, 6>&{ return m ;}
        auto setB(const std::array<double, 6> &beta)->void {b = beta;}
        auto getB()const->const std::array<double, 6>&{ return b; }
        auto setK(const std::array<double, 6> &koe)->void { k = koe;}
        auto getK()const->const std::array<double, 6>&{ return k; }

        auto setFDeadZone(const std::array<double, 6> &fdz)->void {f_dead_zone = fdz;}
        auto getFDeadZone()const->const std::array<double, 6>&{ return f_dead_zone; }
        auto setALimit(const std::array<double, 6> &a)->void {a_limit = a; }
        auto getALimit()const->const std::array<double, 6>&{ return a_limit; }
        auto setVLimit(const std::array<double, 6> &v)->void { v_limit = v; }
        auto getVLimit()const->const std::array<double, 6>&{ return v_limit; }
        auto setPLimit(const std::array<double, 6> &p)->void { p_limit = p;}
        auto getPLimit()const->const std::array<double, 6>&{ return p_limit; }

        auto setFTarget(const std::array<double, 6> &ft)->void {f_target = ft;}
        auto getFTarget()const->const std::array<double, 6>&{ return f_target; }


        auto setCoordinateNum(int num)->void{coordinate_num=num;}
        auto getCoordinateNum()const->int{return coordinate_num;}
        auto setFindTimeOut(int time_out)->void{find_time_out=time_out;}
        auto getFindTimeOut()const->int{return find_time_out;}
        auto setHoldingTime(int time)->void{holding_time=time;}
        auto getHoldingTime()const->int{return holding_time;};

        auto check(bool is_plan=true) ->void {
            for(int i=0;i<m.size();i++){
                if(std::abs(m[i])<1e-3) LOCALE_THROW("M cannot less than zero","M数值不能为0");
            }
            for(int i=0;i<m.size();i++){
                if(std::abs(m[i])>10.0) LOCALE_THROW("M larger than 10 is not recommended","M不推荐为10以上");
            }
            for(int i = 0; i <b.size();i++){
                if(std::abs(b[i])<400.0) LOCALE_THROW("B smaller than 400 is not recommended","B不推荐为400以下");
            }
            auto checkAbs=[&](std::array<double, 6> val){
                for(int i=0;i<val.size();i++){
                    if(val[i]<0) LOCALE_THROW("param cannot less than zero","除目标力外，其它数值不能小于0");
                }
            };
            checkAbs(m);
            checkAbs(b);
            checkAbs(k);
            checkAbs(f_dead_zone);
            checkAbs(a_limit);
            checkAbs(v_limit);
            checkAbs(p_limit);
           if(is_plan) unitConversion();
        }

        auto unitConversion()->void{
            if(!has_unit_conversioned){
                for(int i=0;i<6;i++){
                    if(i<3){
                        p_limit[i] = p_limit[i]/1000.0;
                        v_limit[i] = v_limit[i]/1000.0;
                        a_limit[i] = a_limit[i]/1000.0;
                    }
                    else{
                        p_limit[i] = p_limit[i] * PI/180.0;
                        v_limit[i] = v_limit[i] * PI/180.0;
                        a_limit[i] = a_limit[i] * PI/180.0;
                    }
                }
            }
            has_unit_conversioned=true;
        }

        ForceGuidanceAdmitParam()=default;
        ~ForceGuidanceAdmitParam()=default;

    private:
        bool has_unit_conversioned{false};

        bool is_open{false};
        bool refer_to_tool{false};
        int coordinate_num{0};
        int  find_time_out{0};
        int  holding_time{0};
        std::array<double, 6> m{1.0,1.0,1.0,1.0,1.0,1.0};
        std::array<double, 6> b{30000.0,30000.0,30000.0,30000.0,30000.0,30000.0};
        std::array<double, 6> k{0.0,0.0,0.0,0.0,0.0,0.0};

        std::array<double, 6> f_target{0.0,0.0,0.0,0.0,0.0,0.0};
        std::array<double, 6> f_dead_zone{1.0,1.0,1.0,0.30,0.30,0.30};
        std::array<double, 6> a_limit{100.0,100.0,100.0,100.0,100.0,100.0};
        std::array<double, 6> v_limit{5.0,5.0,5.0,0.50,0.50,0.50};
        std::array<double, 6> p_limit{0.0,0.0,0.0,0.0,0.0,0.0};

        NLOHMANN_DEFINE_TYPE_INTRUSIVE(ForceGuidanceAdmitParam,is_open,refer_to_tool,coordinate_num,find_time_out,holding_time,m,b,k,f_target,f_dead_zone,a_limit,v_limit,p_limit)
    };




    //实时力控参数管理 主要是v_last 和 p_last 需要跨指令保存 上下两条指令直接参数保持

    class KAANH_API ForceTrajectoryGeneratorMoveManager{
    public:
        auto setFTGMoveGenerator(const ForceTrajectoryGenerator &g)->void{ ftg_move_generator = g; }
        auto getFTGMoveGenerator()->ForceTrajectoryGenerator &{ return ftg_move_generator; }
//        auto setFTGMoveParam(const ForceTrajectoryGeneratorMoveParam &par)->void{ ftg_move_param = par; }
//        auto getFTGMoveParam()->ForceTrajectoryGeneratorMoveParam &{ return ftg_move_param; }
        auto setVLast(const std::array<double, 6> &v)->void{ v_last = v; }
        auto getVLast()const->const std::array<double, 6>&{ return v_last; }
        auto setPeLast(const std::array<double, 6> &p)->void{ pe_last = p; }
        auto getPeLast()const->const std::array<double, 6>&{ return pe_last; }
        auto setFtLast(const std::array<double, 6> &f)->void{ ft_last = f; }
        auto getFtLast()const->const std::array<double, 6>&{ return ft_last; }

        ~ForceTrajectoryGeneratorMoveManager()=default;
    private:
        std::array<double, 6> v_last{ 0,0,0,0,0,0 };
        std::array<double, 6> pe_last{ 0,0,0,0,0,0 };
        std::array<double, 6> ft_last{ 0,0,0,0,0,0 };

        ForceTrajectoryGenerator ftg_move_generator;
//        ForceTrajectoryGeneratorMoveParam ftg_move_param;
    };



    // 力控磨料补偿参数
    class KAANH_API ForceParam {
    public:
        auto virtual init()->void;

        double fave[6]{0.0,0.0,0.0,0.0,0.0,0.0};										//力传感器滤波后平均值
        std::atomic_bool g_fcmonitor{false};						//true--false
        std::atomic_int64_t g_fc_counter{1};					//叠加器，用于求平均值
        std::atomic_uint32_t g_fc_index{1};					//第几个力控监测段
        std::atomic_uint32_t g_fc_direction{0};				//0:x方向，1:y方向，2:z方向，3:rx方向，4:ry方向，5:rz方向
    public:
        ForceParam() {};
        ~ForceParam() {};

    private:
        std::atomic_bool program_fc_switch = 0;
        std::atomic_int32_t fc_status = 0;      //0：力控未开启；1：力传感器拖动示教；2：姿态调整；3：寻孔；4：力控装配
    };



   //磨料补偿xml反射接口
    class KAANH_API FCValue
    {
    public:
        auto virtual getData(int index)->aris::core::Matrix {
            std::map<int, std::string>::iterator iter;
            iter = FCValueMap.find(index);
            aris::core::Matrix fc_data = { 0.0,0.0,0.0,0.0,0.0,0.0 };
            if (iter != FCValueMap.end()) {
                auto str = std::string(iter->second);
                auto iter= str.find("{",0);
                if(iter!=-1) str.replace(iter,1,"[");
                iter= str.find("}",0);
                if(iter!=-1) str.replace(iter,1,"]");
                std::vector<double> pos;
                pos.resize(6,0.0);
                try {
                    pos=nlohmann::json::parse(str).get<std::vector<double>>();
                }  catch (std::bad_any_cast& e) {
                    auto &cs=aris::server::ControlServer::instance();
                    cs.master().mout()<<e.what()<<std::endl;
                }
                for(int i=0; i< pos.size(); i++)
                    fc_data.data()[i] = pos[i];
            }
            return fc_data;
        }
        auto virtual setData(int index, std::string data)->void {
            std::map<int, std::string>::iterator iter;
            iter = FCValueMap.find(index);
            if (iter != FCValueMap.end())
                iter->second = data;
            else
                FCValueMap.insert(std::pair<int, std::string>(index, data));
        }
        auto virtual getMap()->std::map<int, std::string> { return FCValueMap; };
        auto virtual InitFCValue()->void { FCValueMap.clear(); }
        virtual ~FCValue() {};
        FCValue() {};

        std::map<int, std::string> FCValueMap;
    };

   enum class  ForceDataType{
       kRaw=0,
       kTool=1,
       kWobj=2
   };


    class KAANH_API EthercatForceSensor : public EthercatFtSensor{
    public:
        EthercatForceSensor();
        virtual ~EthercatForceSensor();
        // 负载
        auto setForceSensorLoadVec(const std::vector<ForceSensorLoad> &fsl)->void{ force_sensor_load_vec_ = fsl; }
        auto getForceSensorLoadVec()const->const std::vector<ForceSensorLoad>&{ return force_sensor_load_vec_; }
        auto setBindedEEId(const int ee_id)->void{binded_ee_id_=ee_id;}
        auto getBindedEEId()const ->int{return binded_ee_id_;}

        auto setBindedLoadId(const int load_id)->void{binded_load_id_=load_id;}
        auto getBindedLoadId()const ->int{return binded_load_id_;}

        auto getBindLoad()-> ForceSensorLoad &{ return force_sensor_load_vec_[getBindedLoadId()]; }

        // 力控保护   兼容多模型
        auto setForceProtectionModule(const ForceProtectionModule &fpm)->void;
        auto getForceProtectionModule() const->const ForceProtectionModule&;
        // 力控保护是否开启
        auto setFsProtectionSwitch(const bool val)->void;
        auto getFsProtectionSwitch()const->bool;
        
        // 力控拖拽 现在拖拽参数和负载一样
        auto setForceSensorGuidanceModuleVec(const std::vector<ForceSensorGuidanceModule> &fsgmv)->void;
        auto getForceSensorGuidanceModuleVec() const->const std::vector<ForceSensorGuidanceModule>&;
        auto getBindedForceSensorGuidanceModule() const->const ForceSensorGuidanceModule&{
            return getForceSensorGuidanceModuleVec()[binded_load_id_];
        };
        
        
        // 实力力控  兼容多模型
        auto setForceTrajectoryGeneratorManager(const ForceTrajectoryGeneratorMoveManager &ftgm)->void;
        auto getForceTrajectoryGeneratorManager()->ForceTrajectoryGeneratorMoveManager&;

        //设置滤波阶数 默认为2
        auto setFilterOrder(const uint8_t &order)->void;
        auto getFilterOrder()const->uint8_t;
        //设置采用时间，单位s 默认10  
        auto setFilterFc(const int fc)->void;
        auto getFilterFc()const->int;
        //设置采用时间，单位s 默认0.001
        auto setFilterTs(const double ts)->void;
        auto getFilterTs()const->double;


        // 力控拖拽轨迹文件
        auto setForceTraceFile(const std::string file)->void;
        auto getForceTraceFile()const->std::string;
        // 轨迹复线
        auto setIsOpenForceTrace(bool is_open_force_trace)->void;
        auto getIsOpenForceTrace()const->bool;
        // 补偿值+原始
        auto getTrajectoryPose()const->std::array<double,6>;
        auto setTrajectoryPose(const std::array<double,6>)->void;
        // 补偿值
        auto getForceCompensatePose()const->std::array<double,6>;
        auto setForceCompensatePose(const std::array<double,6>)->void;

        // 力传感器是否开启
        auto setFsSwitch(const bool val)->void;
        auto getFsSwictch()const->bool;

        // 不同工况下的状态  标志位i
        auto setFCStatus(const uint32_t &s)->void;
        auto getFCStatus()const->uint32_t;

          //LOCAL_THROW  每一个在使用的时候都需要进行修改
        auto checkEEType(int ee_id)const->bool;
        auto prePlanCheck()->void;

        auto setForceDataType(ForceDataType type)->void{data_type_=type;}
        auto getForceDataType()const->const ForceDataType&{return data_type_;}
        auto setCoordinateNum(int num)->void{if(num>0) coordinate_num_=num;}
        auto getCoordinateNum()const->int{return coordinate_num_;}
        // 力传感器原始数值
        auto setForceData(const std::array<double,6> &val)->void{f_data=val;}
        auto getForceData()const->const std::array<double,6>&{return f_data;}

        // 获取工具工件下的数值
        auto getWobjForceData(uint8_t num,std::array<double,6> &force_data)->void{
            auto &cs=aris::server::ControlServer::instance();
            auto model = dynamic_cast<aris::dynamic::MultiModel*>(&cs.model());
            auto &tool_wobj_manager=kaanh::multi_motion::ToolWobjManager::instance();
            //获取传感器对象
            auto &fsl = getBindLoad();


            static aris::dynamic::Marker *tool0 = tool_wobj_manager.getTool(getBindedEEId(),0);
            static aris::dynamic::Marker *wobj0 =tool_wobj_manager.getWobj(getBindedEEId(),0);
            aris::dynamic::Marker *wobj = tool_wobj_manager.getWobj(getBindedEEId(),num);

            std::array<double, 16> t2bpm, fs2tpm, fs2bpm, fs2rpm;
            std::atomic<std::array<double,6>> fs_raw_data, fs_car_data;
            static std::array<double, 6> fs_input_data = { 0,0,0,0,0,0 };
            static std::array<double, 6> fs_filtered_data = { 0,0,0,0,0,0 };
            static kaanh::package::LowPass lp[6];

            //tool0 相对于 wobj0  的位姿   t2bpm
            tool0->getPm(*wobj0, t2bpm.data());
            //将力传感器设置值数据由 pe转成pm  fs2tpm
            aris::dynamic::s_pe2pm(fsl.getForceSensorSetup().data(), fs2tpm.data(), "123");
            //点乘矩阵  工具坐标系 * 力传感器设置值pm 得到力传感器设置置基于基坐标数值 fs2bpm
            aris::dynamic::s_pm_dot_pm(t2bpm.data(), fs2tpm.data(),fs2bpm.data());
            //求外部力:fs_filtered_data=realdata-zero_value-G
            fs_filtered_data = fsl.getExternalForce(fs2bpm);


            double pm_tool02wobj[16];
            tool0->getPm(*wobj, pm_tool02wobj);
            aris::dynamic::s_pm_dot_pm(pm_tool02wobj, fs2tpm.data(), fs2rpm.data());
            std::array<double, 6> f_wobj = { 0,0,0,0,0,0 };
            aris::dynamic::s_fs2fs(fs2rpm.data(), fs_filtered_data.data(), f_wobj.data());
            force_data=f_wobj;
        }

        auto getToolForceData(uint8_t num,std::array<double,6> &force_data)->void{
            auto &cs=aris::server::ControlServer::instance();
            auto model = dynamic_cast<aris::dynamic::MultiModel*>(&cs.model());
            auto &tool_wobj_manager=kaanh::multi_motion::ToolWobjManager::instance();
            //获取传感器对象
            auto &fsl = getBindLoad();



            static aris::dynamic::Marker *tool0 = tool_wobj_manager.getTool(getBindedEEId(),0);
            static aris::dynamic::Marker *wobj0 =tool_wobj_manager.getWobj(getBindedEEId(),0);
            aris::dynamic::Marker *tool = tool_wobj_manager.getTool(getBindedEEId(),num);

            std::array<double, 16> t2bpm, fs2tpm, fs2bpm, fs2rpm;
            std::atomic<std::array<double,6>> fs_raw_data, fs_car_data;
            static std::array<double, 6> fs_input_data = { 0,0,0,0,0,0 };
            static std::array<double, 6> fs_filtered_data = { 0,0,0,0,0,0 };
            static kaanh::package::LowPass lp[6];


            //tool0 相对于 wobj0  的位姿   t2bpm
            tool0->getPm(*wobj0, t2bpm.data());
            //将力传感器设置值数据由 pe转成pm  fs2tpm
            aris::dynamic::s_pe2pm(fsl.getForceSensorSetup().data(), fs2tpm.data(), "123");
            //点乘矩阵  工具坐标系 * 力传感器设置值pm 得到力传感器设置置基于基坐标数值 fs2bpm
            aris::dynamic::s_pm_dot_pm(t2bpm.data(), fs2tpm.data(),fs2bpm.data());

    //        //获取力传感器数值
    //        fs->getFtData(fs_input_data.data());
    //        //数据滤波
    //        for (std::uint64_t i = 0; i < 6; i++){
    //            lp[i].get_filter_data(2, 10, 0.001, fs_input_data[i], fs_filtered_data[i]);
    //        }
    //        fsl.setForceData(fs_filtered_data);

    //        fs_raw_data.store(fs_filtered_data);

    //        std::atomic_bool force_sensor_reset_zero_ = 0;
            //零漂标定，此时必须确保末端不受外载
    //        if (force_sensor_reset_zero_.exchange(false))
    //            fsl.resetZeroOffset(fs2bpm);
            //求外部力:fs_filtered_data=realdata-zero_value-G
            fs_filtered_data = fsl.getExternalForce(fs2bpm);

            double pm_tool2wobj0[16];
            //当前工具 基于基坐标系的数值
            tool->getPm(*wobj0, pm_tool2wobj0);
            aris::dynamic::s_inv_pm_dot_pm(pm_tool2wobj0, fs2bpm.data(), fs2rpm.data());
            std::array<double, 6> f_tool = { 0,0,0,0,0,0 };
            aris::dynamic::s_fs2fs(fs2rpm.data(), fs_filtered_data.data(), f_tool.data());
            force_data=f_tool;
        }

        auto forceMoveReinit()->void{
            force_trajectory_generator_manager_.setVLast({0,0,0,0,0,0});
            force_trajectory_generator_manager_.setPeLast({0,0,0,0,0,0});
        }

    public:
        std::vector<ForceSensorLoad> force_sensor_load_vec_;
        //当前绑定的模型号，以便支持多模型  力传感器和模型一一对应的属性
        int binded_ee_id_{0};
        //当前绑定的负载号  力传感器和负载一一对应的属性
        int binded_load_id_{0};
        ForceProtectionModule force_protection_module_;
        //牵引参数
        std::vector<ForceSensorGuidanceModule> force_sensor_guidance_module_vec_;
        //实时力控参数管理
        ForceTrajectoryGeneratorMoveManager force_trajectory_generator_manager_;
        FCValue fc_value;
        ForceParam fc_param;

//        std::atomic_bool fs_switch=false;
//        std::atomic_bool fs_protection_switch=true;

        //0:none;1:force sensor guidance;//2:judge pose;//3:find hole;//4:assemble
        //5:axis_assemble 6:force_trace
        std::atomic_uint32_t fc_status_ = 0;
        std::atomic_bool force_sensor_reset_zero_ = 0; //?
        std::atomic<std::array<double,6>> fs_raw_data, fs_car_data;


        std::string forceTraceFile_;
        bool is_open_force_trace_{0};

        std::array<double,6> trajectory_pose_{0.0,0.0,0.0,0.0,0.0,0.0};
        std::array<double,6> force_compensate_pose_{0.0,0.0,0.0,0.0,0.0,0.0};

        //力控拖拽开启前的保护参数  由于工件坐标系的问题
        std::array<double,6> before_guidance_limit_{10,10,10,10,10,10};


        //力监控数据
        bool  is_fc_monitor_open{false};
        std::array<double,6> fc_monitor_data_{0,0,0,0,0,0};
        uint32_t fc_monitor_count_{0};
        bool is_fc_monitor_ref_tool_{false};
        uint32_t fc_monitor_coordinate_num_{0};

        //滤波参数
        uint8_t filter_order_{2};
        //截至频率
        int filter_fc_{10};
        //采样时间
        double filter_ts_{0.001};
    private:
        //力传感器数据文件记录值，输出给modbus的值
        ForceDataType data_type_{ForceDataType::kRaw};
        int coordinate_num_{0};
        std::array<double,6> f_data{0.0,0.0,0.0,0.0,0.0,0.0};

    };

    class EthercatFtSensorKW : public EthercatForceSensor {
    public:
        EthercatFtSensorKW();
        virtual auto getFtData(double *data_address)->void override;
    };

    class EthercatFtSensorYL : public EthercatForceSensor {
    public:
        EthercatFtSensorYL();
        virtual auto getFtData(double *data_address)->void override;
    };

    class EthercatFtSensorATI : public EthercatForceSensor {
    public:
        EthercatFtSensorATI();
        virtual auto getFtData(double *data_address)->void override;
    };

    class EthercatFtSensorKaanh : public EthercatForceSensor {
    public:
        EthercatFtSensorKaanh();
        virtual auto getFtData(double *data_address)->void override;
    };
// 现在用的
    class EthercatFtSensorKaanhZiYan : public EthercatForceSensor {
    public:
        EthercatFtSensorKaanhZiYan();
        virtual auto getFtData(double *data_address)->void override;
    };

    class EthercatFtSensorLandian : public EthercatForceSensor {
    public:
        EthercatFtSensorLandian();
        virtual auto getFtData(double *data_address)->void override;
    };

}

#endif
