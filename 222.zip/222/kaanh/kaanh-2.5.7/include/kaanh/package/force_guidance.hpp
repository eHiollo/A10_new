/**
 * @brief 用于实现基于末端力传感器的力控拖拽
 * 
 */
#ifndef KAANH_PACKAGE_FORCE_GUIDANCE_HPP
#define KAANH_PACKAGE_FORCE_GUIDANCE_HPP

#include "aris.hpp"
#include <kaanh/general/macro.hpp>

/**
 * @brief 实现力控拖拽的plan类
 * 
 */
class KAANH_API ForceSensorGuidance : public aris::core::CloneObject<ForceSensorGuidance, aris::plan::Plan>
{
public:
    auto virtual prepareNrt()->void override;
    auto virtual executeRT()->int override;
    auto virtual collectNrt()->void override;
    virtual ~ForceSensorGuidance();
    explicit ForceSensorGuidance(const std::string &name = "ForceSensorGuidance");
    ForceSensorGuidance(const ForceSensorGuidance &);				//拷贝构造
    ForceSensorGuidance(ForceSensorGuidance &);                     //移动构造
    ForceSensorGuidance& operator=(const ForceSensorGuidance &);	//拷贝赋值
    ForceSensorGuidance& operator=(ForceSensorGuidance &&);         //移动赋值

private:
    struct Imp;
    aris::core::ImpPtr<Imp> imp_;
};

/**
 * @brief 用于存储力控拖拽区域限制的参数类
 * 
 */
class ForceGuidanceRegionParam{
    public:
    ForceGuidanceRegionParam() = default;
    ~ForceGuidanceRegionParam() = default;
    KAANH_DECLARE_BIG_FOUR(ForceGuidanceRegionParam);
    auto getIsOpen()const->bool { return is_open; }
    auto setIsOpen(bool on)->void { is_open = on; }
    auto getUpperLimit()const->const double* { return upper_limit; }
    auto getLowerLimit()const->const double* { return lower_limit; }
    auto getDecelerateDistance()const->const double* { return decelerate_distance; }
    auto checkParam()const->void;
    private:
    
    bool is_open{false}; ///< 是否打开拖拽区域限制
    uint32_t tool_coordinate_num{0}; ///< 相对工具坐标系号,暂时没用到
    double upper_limit[6]{10, 10, 10, 15, 15, 15}; ///< 区域限制上限：x, y, z, rx, ry, rz ,unit:mm,deg
    double lower_limit[6]{-10, -10, -10, -15, -15, -15}; ///< 区域限制下限：x, y, z, rx, ry, rz, unit:mm,deg
    double decelerate_distance[6]{5, 5, 5, 7.5, 7.5, 7.5}; ///< 减速距离：x, y, z, rx, ry, rz, unit:mm,deg
    NLOHMANN_DEFINE_TYPE_INTRUSIVE(ForceGuidanceRegionParam, is_open, tool_coordinate_num, upper_limit, lower_limit, decelerate_distance);
};

#endif // KAANH_PACKAGE_FORCE_GUIDANCE_HPP