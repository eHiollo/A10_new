/**
 * @file force_search.hpp
 * @author Zhuchen Han (hanzhuchen666@gmail.com)
 * @brief Force search plan
 * @version 0.1
 * @date 2024-11-09
 * 
 * @copyright Copyright (c) 2024
 * 
 */
#ifndef KAANH_PACKAGE_FORCE_SEARCH_HPP
#define KAANH_PACKAGE_FORCE_SEARCH_HPP

#include "aris.hpp"
#include <kaanh/general/macro.hpp>
#include <kaanh/multi_motion/motion_plan.hpp>
#include <kaanh/package/force_param.hpp>


namespace kaanh::package{
/**
 * @brief This class is used to search the hole by force control
 * 
 */
class KAANH_API ForceSearchPlan :public aris::core::CloneObject<ForceSearchPlan,kaanh::multi_motion::MoveCartBase>
{
public:
    auto virtual prepareNrt()->void override;
    auto virtual executeRT()->int override;
    auto virtual collectNrt()->void override;
    explicit ForceSearchPlan(const std::string &name = "ForceSearchPlan");
    KAANH_DECLARE_BIG_FOUR(ForceSearchPlan)
    virtual ~ForceSearchPlan();
private:
    struct Imp;
    aris::core::ImpPtr<Imp> imp_;
};
class ForceSearchParam: public AdmittanceParamBase{
    public:
    ForceSearchParam() = default;
    ~ForceSearchParam() = default;
    auto getContactForcePercentage()const->const double& { return contact_force_percentage; }
    auto setContactForcePercentage(const double &val)->void { contact_force_percentage = val; }
    auto getApproachSuccessThreshold()const->const double& { return approach_success_threshold; }
    auto setApproachSuccessThreshold(const double &val)->void { approach_success_threshold = val; }
    auto getSearchSuspectThreshold()const->const double& { return search_suspect_threshold; }
    auto setSearchSuspectThreshold(const double &val)->void { search_suspect_threshold = val; }
    auto getConfirmTimeThreshold()const->const double& { return confirm_time_threshold; }
    auto setConfirmTimeThreshold(const double &val)->void { confirm_time_threshold = val; }
    auto getConfirmSuccessThreshold()const->const double& { return confirm_success_threshold; }
    auto setConfirmSuccessThreshold(const double &val)->void { confirm_success_threshold = val; }
    auto getCcDeltaR()const->const double& { return cc_deltaR; }
    auto setCcDeltaR(const double &val)->void { cc_deltaR = val; }
    auto getCcRMax()const->const double& { return cc_rMax; }
    auto setCcRMax(const double &val)->void { cc_rMax = val; }
    auto getSearchVel()const->const double& { return search_vel; }
    auto setSearchVel(const double &val)->void { search_vel = val; }
    auto getSearchAcc()const->const double& { return search_acc; }
    auto setSearchAcc(const double &val)->void { search_acc = val; }
    auto getSearchJerk()const->const double& { return search_jerk; }
    auto setSearchJerk(const double &val)->void { search_jerk = val; }
    auto getDecMaxAcc()const->const double& { return dec_max_acc; }
    auto setDecMaxAcc(const double &val)->void { dec_max_acc = val; }
    auto getDecMaxJerk()const->const double& { return dec_max_jerk; }
    auto setDecMaxJerk(const double &val)->void { dec_max_jerk = val; }
    auto getResumeMaxVel()const->const double& { return resume_max_vel; }
    auto setResumeMaxVel(const double &val)->void { resume_max_vel = val; }

    auto check()->void{
        checkAdmitanceBase();
        if(contact_force_percentage < 0) LOCALE_THROW("contact_force_percentage cannot less than zero","接触力百分比不能小于0");
        //TODO
    }

    
    private:
    double contact_force_percentage{0.5}; ///< 接触力百分比
    double approach_success_threshold{0.004}; ///< 接近成功阈值 m
    double search_suspect_threshold{0.002}; ///< 搜孔成功阈值 m
    double confirm_time_threshold{2000}; ///< 确认时间阈值 ms
    double confirm_success_threshold{0.003}; ///< 确认成功阈值 m
    double cc_deltaR{0.001}; ///< 同心圆半径变化 m
    double cc_rMax{0.003}; ///< 同心圆最大半径 m
    double search_vel{20}; ///< 搜孔速度 mm/s
    double search_acc{50}; ///< 搜孔加速度 mm/s^2
    double search_jerk{100}; ///< 搜孔加加速度 mm/s^3
    double dec_max_acc{50}; ///< 减速最大加速度 mm/s^2
    double dec_max_jerk{100}; ///< 减速最大加加速度 mm/s^3
    double resume_max_vel{20}; ///< 恢复搜索最大速度    mm/s

    NLOHMANN_DEFINE_TYPE_INTRUSIVE(ForceSearchParam, is_open, refer_to_tool, m, b, k, f_target, f_dead_zone, 
        a_limit, v_limit, p_limit, contact_force_percentage, approach_success_threshold, 
        search_suspect_threshold, confirm_time_threshold, confirm_success_threshold, 
        cc_deltaR, cc_rMax, search_vel, search_acc, search_jerk, dec_max_acc, dec_max_jerk, 
        resume_max_vel);
};
}

#endif // KAANH_PACKAGE_FORCE_SEARCH_HPP