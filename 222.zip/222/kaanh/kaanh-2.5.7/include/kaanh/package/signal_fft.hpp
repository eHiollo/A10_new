#ifndef KAANH_PACKAGE_SIGNAL_FFT_HPP
#define KAANH_PACKAGE_SIGNAL_FFT_HPP

#include <vector>
#include <complex>
#include <math.h>

namespace kaanh::package {
class SignalFFT {
public:
    SignalFFT();
    ~SignalFFT() = default;
public:
    std::vector<std::vector<double>> getFFT(const std::vector<double>& ori_data, int freq_sample);

private:
    std::complex<double> j;
};

}


#endif
