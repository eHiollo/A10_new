#include <aris.hpp>
#include <kaanh/general/macro.hpp>
#include "kaanh/multi_motion/motion_plan.hpp"

/**
 * @brief 实现力控拖拽的plan类
 * 
 */
class KAANH_API CheckInHole : public aris::core::CloneObject<CheckInHole, kaanh::multi_motion::MoveL>
{
public:
    auto virtual prepareNrt()->void override;
    auto virtual executeRT()->int override;
    auto virtual collectNrt()->void override;
    virtual ~CheckInHole();
    explicit CheckInHole(const std::string &name = "CheckInHole");
    KAANH_DECLARE_BIG_FOUR(CheckInHole)

private:
    struct Imp;
    aris::core::ImpPtr<Imp> imp_;
};