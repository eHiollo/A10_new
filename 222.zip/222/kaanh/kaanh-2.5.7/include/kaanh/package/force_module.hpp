#ifndef KAANH_PACKAGE_FORCE_MODULE_HPP_
#define KAANH_PACKAGE_FORCE_MODULE_HPP_

#include <aris.hpp>
#include <stdlib.h>
#include "kaanh/module/pgm_controller.hpp"
#include "kaanh/general/macro.hpp"
#include "kaanh/package/force_trajectory_generator.hpp"
#include "kaanh/package/ethercat_force_sensor.hpp"
#include "kaanh/package/force_guidance.hpp"
#include "kaanh/package/force_search.hpp"
#include "kaanh_lib_export.h"



namespace kaanh::package
{

    #ifndef FORCE_TRACE_FILE_PREFIX
    #define FORCE_TRACE_FILE_PREFIX "F_"
    #endif

    class KAANH_API  ForceMoveParamLimit{
    public:
        auto virtual checkMaxLimit(std::array<double,6> arr,std::array<double,6> max_limit)const->bool{
            for(int i=0;i<6;i++){
                if(abs(arr[i]) > abs(max_limit[i])) return false;
            }
            return true;
        }
        auto virtual checkMinLimit(std::array<double,6> arr,std::array<double,6> min_limit)const->bool{
            for(int i=0;i<6;i++){
                if(abs(arr[i]) < abs(min_limit[i])) return false;
            }
            return true;
        }
        auto check(const ForceTrajectoryGeneratorMoveParam &param)const ->bool{
            return checkMinLimit(param.getM(),m_min_limit)&& checkMaxLimit(param.getALimit(),a_max_limit) && checkMaxLimit(param.getVLimit(),v_max_limit)
                    && checkMaxLimit(param.getPLimit(),p_max_limit);
        }
    private:
        std::array<double,6> m_min_limit{500,500,500,50000,50000,50000},b_min_limit{100,100,100,100,100,100},k_min_limit{100,100,100,100,100,100};
        std::array<double,6> a_max_limit{500,500,500,0.01,0.01,0.01},v_max_limit{100,100,100,0.01,0.01,0.01},p_max_limit{50,50,50,0.01,0.01,0.01};

        NLOHMANN_DEFINE_TYPE_INTRUSIVE(ForceMoveParamLimit,m_min_limit,b_min_limit,k_min_limit,a_max_limit,v_max_limit,p_max_limit)
    };


    class KAANH_API AssembleParamLimit{
    public:
        auto virtual checkMaxLimit(double arr[6],std::array<double,6> max_limit)const->bool{
            for(int i=0;i<6;i++){
                if(abs(arr[i]) > abs(max_limit[i])) return false;
            }
            return true;
        }
        auto virtual checkMinLimit(double arr[6],std::array<double,6> min_limit)const->bool{
            for(int i=0;i<6;i++){
                if(abs(arr[i]) < abs(min_limit[i])) return false;
            }
            return true;
        }
        auto check( AssembleAdmitParam param)const ->bool{
            return checkMinLimit(param.M,m_min_limit)&& checkMaxLimit(param.cor_acc,a_max_limit) && checkMaxLimit(param.cor_vel,v_max_limit)
                    && checkMaxLimit(param.cor_pos_now,p_max_limit);
        }
    private:
        std::array<double,6> m_min_limit{100,100,100,50000,50000,50000},b_min_limit{100,100,100,100,100,100},k_min_limit{100,100,100,100,100,100};
        std::array<double,6> a_max_limit{100,100,100,100,100,100},v_max_limit{10,10,10,10,10,10},p_max_limit{150,150,150,150,150,150};
        NLOHMANN_DEFINE_TYPE_INTRUSIVE(AssembleParamLimit,m_min_limit,b_min_limit,k_min_limit,a_max_limit,v_max_limit,p_max_limit)
    };

    class KAANH_API AxisAssembleParamLimit{
    public:
        auto virtual checkMaxLimit(double arr[6],std::array<double,6> max_limit)const->bool{
            for(int i=0;i<6;i++){
                if(abs(arr[i]) > abs(max_limit[i])) return false;
            }
            return true;
        }
        auto virtual checkMinLimit(double arr[6],std::array<double,6> min_limit)const->bool{
            for(int i=0;i<6;i++){
                if(abs(arr[i]) < abs(min_limit[i])) return false;
            }
            return true;
        }
        auto check( AxisAssembleAdmitParam param)const ->bool{
            return checkMinLimit(param.M,m_min_limit)&& checkMaxLimit(param.cor_acc,a_max_limit) && checkMaxLimit(param.cor_vel,v_max_limit)
                    && checkMaxLimit(param.cor_pos_now,p_max_limit);
        }
    private:
        std::array<double,6> m_min_limit{100,100,100,50000,50000,50000},b_min_limit{100,100,100,100,100,100},k_min_limit{100,100,100,100,100,100};
        std::array<double,6> a_max_limit{100,100,100,100,100,100},v_max_limit{10,10,10,10,10,10},p_max_limit{150,150,150,150,150,150};
        NLOHMANN_DEFINE_TYPE_INTRUSIVE(AxisAssembleParamLimit,m_min_limit,b_min_limit,k_min_limit,a_max_limit,v_max_limit,p_max_limit)
    };

    //力控浮动
    class KAANH_API ForceGuidanceAdimitParamLimit{
    public:
        auto virtual checkMaxLimit(std::array<double,6>arr,std::array<double,6> max_limit)const->bool{
            for(int i=0;i<6;i++){
                if(abs(arr[i]) > abs(max_limit[i])) return false;
            }
            return true;
        }
        auto virtual checkMinLimit(std::array<double,6>arr,std::array<double,6> min_limit)const->bool{
            for(int i=0;i<6;i++){
                if(abs(arr[i]) < abs(min_limit[i])) return false;
            }
            return true;
        }
        auto check(const ForceGuidanceAdmitParam &param)->bool{
            return checkMinLimit(param.getM(),m_min_limit)&& checkMaxLimit(param.getALimit(),a_max_limit) && checkMaxLimit(param.getVLimit(),v_max_limit)
                    && checkMaxLimit(param.getPLimit(),p_max_limit);
        }
    private:
        std::array<double,6> m_min_limit{100,100,100,50000,50000,50000},b_min_limit{100,100,100,100,100,100},k_min_limit{100,100,100,100,100,100};
        std::array<double,6> a_max_limit{100,100,100,100,100,100},v_max_limit{10,10,10,10,10,10},p_max_limit{150,150,150,150,150,150};
        NLOHMANN_DEFINE_TYPE_INTRUSIVE(ForceGuidanceAdimitParamLimit,m_min_limit,b_min_limit,k_min_limit,a_max_limit,v_max_limit,p_max_limit)

    };

    class KAANH_API Force : public kaanh::module::MiddleModule {
    public:
        auto virtual init()->void override;
        auto virtual execute(const std::string &str, std::function<void(std::string)> send_ret) noexcept->std::pair<std::string, std::string> override;
        // 标定时停止在uodate刷新力传感器数值
        auto setFsUpdateStop(const bool val)->void;
        auto getFsUpdateStoped()const->bool;

        //检查力控数值 如果当前坐标系下的数据大于{20,20,20,4,4,4}，则报错，可屏蔽检查
        auto checkForceData(int fs_id)const->bool;

        auto getForceMoveParams()const ->const std::map<std::string,std::vector<ForceTrajectoryGeneratorMoveParam>>&;
        auto getAssembleAdmitParams()const->const std::map<std::string,std::vector<AssembleAdmitParam>>&;
        auto getAxisAssembleAdmitParams()const->const std::map<std::string,std::vector<AxisAssembleAdmitParam>>&;
        auto getForceGuidanceAdmitParams()const->const std::map<std::string,std::vector<ForceGuidanceAdmitParam>>&;
        auto getForceGuidanceRegionParams()const->const std::map<std::string,std::vector<ForceGuidanceRegionParam>>&;
        auto getSearchParam()const->const std::map<std::string, std::vector<ForceSearchParam>>&;

        auto saveForceMoveParam()const ->void;
        auto saveAssembleAdmitParam()const ->void;
        auto saveAxisAssembleAdmitParam()const ->void;
        auto saveForceGuidanceAdmitParam()const ->void;
        auto saveForceGuidanceRegionParam()const ->void; ///<保存力控牵引区域参数
        auto saveForceSearchParam()const ->void; ///<保存力控搜索参数

        // 力控浮动,到达期望力后保持一定时间
        // 力控装配用。。。
        auto setForceHoldingDetectTime(const int val)->void;
        auto getForceHoldingDetectTime()const->int;

        auto updateCheckForceSensor()->int;
        // L C中上次是否开启力控，切换用
        auto setForceMoveOpenLastStatus(int fs_id,bool status)->void;
        auto getForceMoveOpenLastStatus()const->const std::vector<bool>&;
        auto forceMovePlanReInit()->void;

        auto isForceMovePlanReInit(const std::vector<ForceTrajectoryGeneratorMoveParam> &params) const->bool;
        /**
         * @brief 力带控移动的力控部分实时线程
         * 
         * @param force_move_params 
         * @param ee_types 
         * @param ee_ids 
         * @param tool0s 
         * @param wobj0s 
         * @param tools 
         * @param wobjs 
         * @param cur_pe 
         * @param f_ref 
         */
        auto forceMovePlanExcute(const std::vector<ForceTrajectoryGeneratorMoveParam> &force_move_params,const std::vector<aris::dynamic::EEType> &ee_types ,const std::vector<aris::Size> &ee_ids,const std::vector<aris::dynamic::Marker*> &tool0s, const std::vector<aris::dynamic::Marker*> &wobj0s,
                                 const std::vector<aris::dynamic::Marker*> &tools,const std::vector<aris::dynamic::Marker*> &wobjs,std::vector<double> &cur_pe,std::array<double, 6> &f_ref)->void;

        // 轨迹提取
        auto forceMovePosRecord(const std::vector<aris::dynamic::EEType> &ee_types,const std::vector<aris::Size> &ee_ids,const std::vector<double> &cur_pe,const std::vector<aris::Size>&tools_id,const std::vector<aris::Size>&wobjs_id,int count,const std::array<double, 6> &f_ref,int pos_type=0)const->void;
        // 力控引导和拖拽
        auto setFsgStatus(bool val)->void;
        auto getFsgStatus()const->bool;
//        auto setForceGuidanceVLimitMax(const std::array<double,6>&v_limit_max)->void;
//        auto setForceGuidanceVLimitMax(std::array<double,6>)const -> std::array<double,6>;

    private:
        struct Imp;
        std::unique_ptr<Imp> imp_;

    public:
        static auto instanceInCs()->Force&;
        Force();
        virtual ~Force();
        KAANH_DELETE_BIG_FOUR(Force)

    };

}

#endif // KAANH_PACKAGE_FORCE_MODULE_HPP_
