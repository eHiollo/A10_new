/**
 * @file zig_zag_search.hpp
 * @author your name (you@domain.com)
 * @brief 
 * @version 0.1
 * @date 2025-04-01
 * 
 * @copyright Copyright (c) 2025
 * 
 */

 #ifndef KAANH_PACKAGE_ZIG_ZAG_SEARCH_HPP
#define KAANH_PACKAGE_ZIG_ZAG_SEARCH_HPP

#include "aris.hpp"
#include <kaanh/general/macro.hpp>
#include <kaanh/multi_motion/motion_plan.hpp>
#include <kaanh/package/force_param.hpp>

namespace kaanh::package
{
class KAANH_API ZigZagSearch :public aris::core::CloneObject<ZigZagSearch,kaanh::multi_motion::MoveCartBase>
{
public:
    auto virtual prepareNrt()->void override;
    auto virtual executeRT()->int override;
    auto virtual collectNrt()->void override;
    explicit ZigZagSearch(const std::string &name = "ZigZagSearch");
    KAANH_DECLARE_BIG_FOUR(ZigZagSearch)
    virtual ~ZigZagSearch();
private:
    struct Imp;
    aris::core::ImpPtr<Imp> imp_;
};
};

#endif