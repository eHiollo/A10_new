#ifndef KAANH_MULTI_MOTION_PLAN_HPP_
#define KAANH_MULTI_MOTION_PLAN_HPP_

#include <aris.hpp>
#include <stdlib.h>
#include "kaanh/module/pgm_controller.hpp"
#include "kaanh/robot/robot.hpp"
#include "kaanh/general/macro.hpp"
#include "kaanh/multi_motion/motion_config.hpp"
#include "kaanh/multi_motion/motion_manager.hpp"
#include "kaanh/robot/robot.hpp"
#include "kaanh/robot/error.hpp"
// #include "kaanh/package/force_module.hpp"

namespace kaanh{
    namespace package{
        class Force;
    }
} // 因为在Force类中同样使用了MoveCartBase类，为了避免循环包含，所以在这里使用前向声明

using namespace aris::plan;
using aris::Size;

namespace kaanh::multi_motion {


// #ifndef SIMULATION
// #define SIMULATION
// #endif


    enum class MotionType
    {
        MoveAbsJ = 1,
        MoveL,
        MoveLRel,
        MoveC,
        MoveArch,
        MoveArchP,
        RePlay
    };




class KAANH_API MultiModelControl : public kaanh::module::MiddleModule 
{
public:
    auto virtual init()->void;
    auto virtual execute(const std::string &str, std::function<void(std::string)> send_ret) noexcept->std::pair<std::string, std::string> override;
    static auto instanceInCs()->MultiModelControl&;

    auto setUseSp(const bool val)->void;
    auto getUseSp() const->const bool;

    auto setUseConfData(const bool val)->void;
    auto getUseConfData() const->const bool;

    auto setTgConfig(const std::vector<TgConfig> &tg_config)->void;
    auto tgConfig() const->const std::vector<TgConfig>&;
    
    auto setAccDecJerkLimit(const AccDecJerkLimit &limit)->void;
    auto getAccDecJerkLimit() const->const AccDecJerkLimit&;

    auto setSPeedLimit(const SpeedLimit &spl)->void;
    auto getSpeedLimit() const-> const SpeedLimit&;

    auto setZonelimit(const ZoneLimit &zn)->void;
    auto getZonelimit() const->const ZoneLimit&;

    auto setCouplingConfig(const CouplingConfig &cp_config)->void;
    auto getCouplingConfig() const->const CouplingConfig&;

    auto retSpeedZone() const-> std::string;

public:
    MultiModelControl();
    ~MultiModelControl();
    KAANH_DELETE_BIG_FOUR(MultiModelControl)

private:
    struct Imp;
    std::unique_ptr<Imp> imp_;
};

class KAANH_API MoveBase : public aris::core::CloneObject<MoveBase,Plan>
{
public:
    struct  Imp;
    aris::core::ImpPtr<Imp> imp_;
    
public:
    explicit MoveBase(const std::string& name = "MoveBase");
    virtual ~MoveBase();
    KAANH_DECLARE_BIG_FOUR(MoveBase)
    auto virtual saveLastStopMotorPos()->void;
    auto virtual setLastStopMotorPos()->void;

    auto virtual getInstance()->void;
    auto virtual getControlParam(Size tg_id)->void{};
    auto virtual tg()-> aris::plan::TrajectoryGenerator*{ return nullptr;} 

    // 全局单利快速索引
    auto multiModel()-> aris::dynamic::MultiModel*; 
    auto pgmCalculator()-> kaanh::program::PgmCalculator*;
    auto robot()-> kaanh::robot::Robot*;
    auto pgmController()-> kaanh::module::PgmController*;   
    auto moveParam()-> kaanh::multi_motion::MoveParam*; 
    auto forceModule()-> kaanh::package::Force*; 
    auto twManager()-> kaanh::multi_motion::ToolWobjManager*; 
    auto eeManager()-> kaanh::multi_motion::EeManager*; 
    auto tgManager()-> kaanh::multi_motion::TrajectoryGeneratorManager*; 
    auto spManager()-> kaanh::multi_motion::SingularProcessorManager*; 
    auto log()-> kaanh::log::Sqlite3Log*;
};

class KAANH_API MoveAjBase:public aris::core::CloneObject<MoveAjBase,MoveBase>
{
public:
    struct  Imp;
    aris::core::ImpPtr<Imp> imp_;
    
public:
    explicit MoveAjBase(const std::string& name = "MoveAjBase");
    virtual ~MoveAjBase();
    auto virtual collectNrt()->void override;
    KAANH_DECLARE_BIG_FOUR(MoveAjBase)
    // 仿真
    auto simulationOutput(MotionType type)->void;
    auto virtual getControlParam(Size tg_id)->void override;
    auto virtual getAllControlParam()->void;
    auto virtual tg()-> aris::plan::TrajectoryGenerator* override; 
    auto ctrlMotions()->std::vector<aris::dynamic::Motion*>;
    auto ctrlMotionTypes()->const std::vector<aris::dynamic::EEType>;
    auto ctrlMotionId()->const std::vector<aris::Size>;
    auto getPe(double*pos)->void;
    auto setPe(const double*cur_pos)->void;
};

class KAANH_API MoveCartBase:public aris::core::CloneObject<MoveCartBase,MoveBase>
{
public:
    struct  Imp;
    aris::core::ImpPtr<Imp> imp_;
    
public:
    explicit MoveCartBase(const std::string& name = "MoveCart");
    KAANH_DECLARE_BIG_FOUR(MoveCartBase)
    virtual ~MoveCartBase();
    auto virtual collectNrt()->void override;

    // 返回要控制的末端的信息
    auto virtual getControlParam(Size tg_id)->void override;
    auto virtual getAllControlParam()->void;
    auto virtual tg()-> aris::plan::TrajectoryGenerator* override; 
    auto sp()-> aris::plan::SingularProcessor*;
    auto ctrlEes()->std::vector<aris::dynamic::MotionBase*>;
    auto ctrlEeTypes()->const std::vector<aris::dynamic::EEType>;
    auto ctrlEeId()->const std::vector<aris::Size>;

    auto getCurrentPe(const int ee_id, double* out_pe)->void;

    auto getInitPe()->std::vector<std::vector<double>>;
    auto getInitConfData()->std::vector<std::array<int,4>>;
    auto getPe(const std::vector<std::tuple<std::vector<double>, std::vector<int>,std::vector<int>>>& pe,std::vector<std::vector<double>>& pe_out,std::vector<std::vector<int>>& confdata_out)->void;
    auto getPe(const std::vector<std::vector<double>>& pe_in,std::vector<double>& pe_out)->void;
    auto setPe(const double*cur_pe)->int;
    auto getSpeed(const std::vector<std::vector<double>>& v,std::vector<double>& vel,std::vector<double>& acc,std::vector<double>& jerk)->void;
    auto getSpeed(const std::vector<std::vector<double>>& v,std::vector<double>& vel)->void;
    auto getZone(const std::vector<std::vector<double>>& zone,std::vector<double>& zone_out)->void;
    auto getOffset(const std::vector<std::vector<double>>& offset,std::vector<std::vector<double>>& off_out)->void;
    auto calOffsetPe(const std::vector<std::vector<double>> offsets, std::vector<std::vector<double>>& pe)->void;
    // 校验offset是否合理   L C L_Find
    auto checkEndPe(const std::vector<std::vector<double>> end_pe,const std::vector<std::vector<int>>& confdata,const std::string pe_name = "")->void;

    // 仿真
    auto simulationOutput(MotionType type,int count,const std::vector<double>& cur_pe)->void;

    // 工具工件 不管是工具还是外部工具，只下发对应的1~16的号。工具1下发1 ，外部工具1 下发1
    auto getToolWobj(const std::vector<std::tuple<std::vector<double>, std::vector<int>, std::vector<int>>>& pe)->void;
    auto getToolWobj(const std::vector<Size>& tool_id,const std::vector<Size>& wobj_id,const std::vector<bool> is_ext_tool)->void;
    auto getToolsId()const->const std::vector<Size> &;
    auto getWobjsId()const->const std::vector<Size> &;
    auto getToolIds(const std::vector<Size>& tool_id,const std::vector<Size>& wobj_id,const std::vector<bool> is_ext_tool)->void;
    auto tool0s()->std::vector<aris::dynamic::Marker*>;
    auto tools()->std::vector<aris::dynamic::Marker*>;
    auto wobj0s()->std::vector<aris::dynamic::Marker*>;
    auto wobjs()->std::vector<aris::dynamic::Marker*>;
    auto hdWobjs()->std::vector<aris::dynamic::Marker*>;
    auto exTools()->std::vector<aris::dynamic::Marker*>;
    auto isExTools()->std::vector<bool>;
};



class KAANH_API MoveAbsJ :public aris::core::CloneObject<MoveAbsJ,MoveAjBase>
{

public:

    auto virtual prepareNrt()->void override;
    auto virtual executeRT()->int override;

    explicit MoveAbsJ (const std::string &name = "MoveAbsJ");
    KAANH_DECLARE_BIG_FOUR(MoveAbsJ)
    virtual ~MoveAbsJ ();
private:
    struct Imp;
    aris::core::ImpPtr<Imp> imp_; 
};


class KAANH_API MoveL :public aris::core::CloneObject<MoveL,MoveCartBase>
{
public:
    auto virtual prepareNrt()->void override;
    auto virtual executeRT()->int override;
    explicit MoveL(const std::string &name = "MoveL");
    KAANH_DECLARE_BIG_FOUR(MoveL)
    virtual ~MoveL();
private:
    struct Imp;
    aris::core::ImpPtr<Imp> imp_;
};


class KAANH_API MoveLRel :public aris::core::CloneObject<MoveLRel,MoveCartBase>
{
public:
    auto virtual prepareNrt()->void override;
    auto virtual executeRT()->int override;
    explicit MoveLRel(const std::string &name = "MoveLRel");
    KAANH_DECLARE_BIG_FOUR(MoveLRel)
    virtual ~MoveLRel();
private:
    struct Imp;
    aris::core::ImpPtr<Imp> imp_;
};

class KAANH_API MoveC :public aris::core::CloneObject<MoveC,MoveCartBase>
{
public:
    auto virtual prepareNrt()->void override;
    auto virtual executeRT()->int override;
    auto isCollinear()->bool;
    auto distance(aris::Size n, double* x,const double* y) noexcept ->double;
    explicit MoveC(const std::string &name = "MoveC");
    KAANH_DECLARE_BIG_FOUR(MoveC)
    virtual ~MoveC();
private:
    struct Imp;
    aris::core::ImpPtr<Imp> imp_;
};



// 门型指令暂不支持多模型和有外部轴的情况
class KAANH_API MoveArch :public aris::core::CloneObject<MoveArch,MoveCartBase>
{

public:

    auto virtual prepareNrt()->void override;
    auto virtual executeRT()->int override;
    auto calPe()->void;
    auto isCanMoveC(double* p1,double* p2,double* h_max)->bool;
    auto initPeSize()->void;
    explicit MoveArch(const std::string &name = "MoveArch");
    KAANH_DECLARE_BIG_FOUR(MoveArch)
    virtual ~MoveArch();

    struct Imp;
    aris::core::ImpPtr<Imp> imp_;
    
};

// 仅适用于单个scara模型
class KAANH_API MoveArchP :public aris::core::CloneObject<MoveArchP,MoveAjBase>
{

public:

    auto virtual prepareNrt()->void override;
    auto virtual executeRT()->int override;
    auto calP()->void;
    auto initPeSize()->void;
    explicit MoveArchP(const std::string &name = "MoveArchP");
    KAANH_DECLARE_BIG_FOUR(MoveArchP)
    virtual ~MoveArchP();

private:
    struct Imp;
    aris::core::ImpPtr<Imp> imp_;
    
};


class KAANH_API RePlay :public aris::core::CloneObject<RePlay,MoveAjBase>
{
public:
    auto virtual prepareNrt()->void override;
    auto virtual executeRT()->int override;
    auto virtual collectNrt()->void override;
    explicit RePlay(const std::string &name = "RePlay");
    KAANH_DECLARE_BIG_FOUR(RePlay)
    virtual ~RePlay();
private:
    struct Imp;
    aris::core::ImpPtr<Imp> imp_;
};


class KAANH_API ManualMoveAbsJ :public aris::core::CloneObject<ManualMoveAbsJ,MoveAjBase>
{

public:

    auto virtual prepareNrt()->void override;
    auto virtual executeRT()->int override;
    auto virtual collectNrt()->void override;

    explicit ManualMoveAbsJ (const std::string &name = "MoveAbsJ");
    KAANH_DECLARE_BIG_FOUR(ManualMoveAbsJ)
    virtual ~ManualMoveAbsJ ();
private:
    struct Imp;
    aris::core::ImpPtr<Imp> imp_; 
};

class KAANH_API Reset :public aris::core::CloneObject<Reset,Plan>
{
public:
    auto virtual prepareNrt()->void override;
    auto virtual executeRT()->int override;
    auto virtual collectNrt()->void override;
    explicit Reset(const std::string &name = "Reset");
    KAANH_DECLARE_BIG_FOUR(Reset)
    virtual ~Reset();
private:
    struct Imp;
    aris::core::ImpPtr<Imp> imp_;
};


class KAANH_API ManualMoveL :public aris::core::CloneObject<ManualMoveL,MoveCartBase>
{
public:
    auto virtual prepareNrt()->void override;
    auto virtual executeRT()->int override;
    auto virtual collectNrt()->void override;
    explicit ManualMoveL(const std::string &name = "ManualMoveL");
    KAANH_DECLARE_BIG_FOUR(ManualMoveL)
   // ManualMoveL(const ManualMoveL& other) = default;
    virtual ~ManualMoveL();
private:
    struct Imp;
    aris::core::ImpPtr<Imp> imp_;
};


class KAANH_API MoveDragTcp :public aris::core::CloneObject<MoveDragTcp,MoveCartBase>
{
public:
    auto virtual prepareNrt()->void override;
    explicit MoveDragTcp (const std::string &name = "MoveDrag");
    KAANH_DECLARE_BIG_FOUR(MoveDragTcp)
    virtual ~MoveDragTcp ();
private:
    struct Imp;
    aris::core::ImpPtr<Imp> imp_; 
};

class KAANH_API MoveDragBase :public aris::core::CloneObject<MoveDragBase,MoveCartBase>
{
public:
    auto virtual prepareNrt()->void override;
    explicit MoveDragBase (const std::string &name = "MoveDragBase");
    KAANH_DECLARE_BIG_FOUR(MoveDragBase)
    virtual ~MoveDragBase ();
private:
    struct Imp;
    aris::core::ImpPtr<Imp> imp_; 
};

// 正弦曲线 //
class MoveJS : public aris::core::CloneObject<MoveJS, aris::plan::Plan>
{
public:
    auto virtual prepareNrt()->void;
    auto virtual executeRT()->int;
    auto virtual collectNrt()->void;

    explicit MoveJS(const std::string& name = "MoveJS_plan");
private:
    struct Imp;
    aris::core::ImpPtr<Imp> imp_;


};


}   // namespace kaanh::multi_motion

#endif  // KAANH_MULTI_MOTION_PLAN_HPP_

