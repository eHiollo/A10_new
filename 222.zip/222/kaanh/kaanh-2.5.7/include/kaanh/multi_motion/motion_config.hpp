#ifndef KAANH_MULTI_MOTION_CONFIG_HPP_
#define KAANH_MULTI_MOTION_CONFIG_HPP_

#include <aris.hpp>
#include <stdlib.h>
#include <atomic>

#include "kaanh/general/macro.hpp"
#include "kaanh_lib_export.h"
#include "kaanh/module/middle_module.hpp"
#include "kaanh/program/pgm_calculator.hpp"
#include "kaanh/module/pgm_controller.hpp"
#include "kaanh/robot/robot.hpp"

using namespace aris::plan;
using aris::Size;


namespace kaanh::multi_motion
{

    // TODO: 名称讨论
#define ROBOT_TARGET "RobotTarget"
#define CONFIG_DATA "ConfigData"
#define EE_XYZABC "EE_XYZABC"
#define EE_ABC "EE_ABC"
#define EE_XYZT "EE_XYZT"
#define EE_XYZ "EE_XYZ"
#define EE_XYT "EE_XYT"
#define EE_XY "EE_XY"
#define EE_X "EE_X"
#define EE_A "EE_A"

#define JOINT_TARGET "JointTarget"

#define SPEED "Speed"
#define SPEED_MEMBER_PERCENT "w_per"
#define SPEED_MEMBER_TCP "v_tcp"
#define SPEED_MEMBER_ORI "w_tcp"

#define ZONE "Zone"
#define ZONE_MEMBER_PZONETCP "pzone_tcp"
#define ZONE_MEMBER_ZONEORI "zone_ori"

#define OFFSET "Offset"
#define OFF_XYZABC "OFF_XYZABC"
#define OFF_ABC "OFF_ABC"
#define OFF_XYZT "OFF_XYZT"
#define OFF_XYZ "OFF_XYZ"
#define OFF_XYT "OFF_XYT"
#define OFF_XY "OFF_XY"
#define OFF_X "OFF_X"
#define OFF_A "OFF_A"

	auto IsSingular(aris::plan::Plan &plan)->bool;
 
  KAANH_API auto errorIint()->void;

    enum class ErrorCode2 : int{

        // aris中的错误
        ePREPARE_EXCEPTION = -2,
        eSERVER_IN_ERROR = -10,
        eSERVER_NOT_STARTED = -11,
        
        eSLAVE_AT_INIT = -101,
        eSLAVE_AT_SAFEOP = -102,
        eSLAVE_AT_PREOP = -103,
        eSLAVE_AT_OP = -104,
        eMOTION_NOT_ENABLED = -501,
        eMOTION_POS_BEYOND_MIN = -502,
        eMOTION_POS_BEYOND_MAX = -503,
        eMOTION_POS_NOT_CONTINUOUS = -504,
        eMOTION_POS_NOT_CONTINUOUS_SECOND_ORDER = -505,
        eMOTION_POS_FOLLOWING_ERROR = -506,
        eMOTION_POS_INFINITE = -507,
        eMOTION_VEL_BEYOND_MIN = -527,
        eMOTION_VEL_BEYOND_MAX = -528,
        eMOTION_VEL_NOT_CONTINUOUS = -529,
        eMOTION_VEL_FOLLOWING_ERROR = -530,
        eMOTION_INVALID_MODE = -541,



        // 标定类错误  0x1000-0x108f
        eChoosenToolError = 0x1001,
        eChoosenWobjError = 0x1002,
        eToolWobjModeError = 0x1003,
        eInputDataError = 0x1004,

        eGetWobjFailed = 0x1005,
        eManualSetWobjFailed = 0x1006,
        eCanNotChangeWobj0 = 0x1007,
        eWobjOverRange = 0x1008,
        eExToolOverRange =0x100a,

        eGetToolFailed = 0x100b,
        eManualSetToolFailed = 0x110c,
        eCanNotChangeTool0 = 0x110d,
        eToolOverRange = 0x1010,
        eHdWobjOverRange = 0x1011,

        eToolNumOverRange = 0x1012,
        eWobjNumOverRange = 0x1013,
        eToolNumNotMatchWobjNum = 0x1014,


        // 电流环标定 0x1090~0x109f
        eCurrentOverLoaded  =         0x1091,
        eCurrentNotCalibrated  =      0x1092,
        eCurrentNotSetRatedTorque =   0x1093,
        eCurrentCalibDynParDataError = 0x1094,
        eCurrentGuidanceParamError = 0x1095,

        // 模型相关 0x10a0~0x10af
        eForwardKinematics = 0x10a0,
        eInverseKinematics = 0x10a1,
        eCloseToSingularPoints = 0x10a2,
        eCanNotJogC = 0x10a3,
        eCanNotReach = 0x10a4,

        // 点动 0x10b0~0x10bf
        eJogJRunModeNotAtAxis = 0x10b0,
        eJogCRunModeAtAxis = 0x10b1,
        eJogSParamError = 0x10b2,
        eJogCParamError = 0x10b3,

        // 运动 0x10c0~0x10ff
        eParamError = 0x10c0,

        eMoveCPointsInLine = 0x10c1,
        eMoveArchHmaxTooSmall = 0x10c2,

        eMoveArchPNotScaraModel = 0x10c3,
        eMoveArchPHmaxOverRange = 0x10c4,
        eMoveArchPHmaxTooSmall = 0x10c5,
        eMoveLFindIdOverRange = 0x10c6,


        // 其他操作指令 0x2100~0x21ff
        eSetPdoIdOverRange = 0x2101,
        eSetPdoValueOverRange = 0x2102,
        eModeNotSupported = 0x2103,
        eCommandOverTime = 0x2104,
        eSleepParam = 0x2105,
        eSetXmlFailed = 0x2106,
        eCanNotSetXml = 0x2107,
        eCheckModeFaild = 0x2108,

        // 其他场景 0x2200~0x22ff
        eMotorConfigError = 0x2201,
        eAreaWraning = 0x2202,
        eReadPdoFuncParamError = 0x2203,

        // 外部自动 0x3200~0x3204
        eExtLoadError = 0x3200,
        eExtStartError = 0x3201,
        eExtPauseError = 0x3202,
        eExtUnloadError = 0x3203,
        eExtResetError = 0x3204,

        // 驱动器相关错误
        eDriverBreakRelease = 0x3300,
        eDriverWraning = 0x3301,
        eDriverConfigError = 0x3302,
        eDriverInitFaild = 0x3303,
        eDriverSycnPeriodError = 0x3304,


        // 信号相关错误
        eTeacherEmergency = 0x3500,
        eExternalEmergency = 0x3501,
        eRasterTriggered = 0x3502,
        eGateTriggered = 0x3503,
        eSlaveLoseConnection = 0x3504,
        eDriverSTOTrigger = 0x3505,
        eModbusLoseConnection = 0x3506,
        eIterfaceAreaTrigger = 0x3507,
        eEnableOverTime = 0x3508,
        eSlaveConfigError = 0x3509,


        // 0x3a00~0x3aff 力控异常
        // eForceSensorDataHolding~0x3aff 力控异常
        eForceSensorDataHolding = 0x3a00, ///< 力传感器数据保持不动
        eForceNoBindedId = 0x3a01,  ///<
        eForceBindedModelIdOutOfRange = 0x3a02, ///<
        eForceSensorOnlySupportPePqPmType = 0x3a03, ///<
        eForceEeIdRepeat = 0x3a04,
        eForceLoadIdOutOfRange = 0x3a05,
        eForceSensorOverloadWrtRef = 0x3a06,
        eCurrentForceSensorChoosenToolWobjError = 0x3a07,
        eCurrentForceSensorChoosenProtectionToolWobjError = 0x3a08,
        eCurrentForceSensorDataOutputChoosenToolWobjError = 0x3a09,
        eForceSensorOverloadWrtJoint = 0x3a0a,
        eForceSensorInputParam = 0x3a10,
        eForceSensorInvalidSetupConfig = 0x3a11,
        eRealForceControlConfigOpenFailed = 0x3a12,
        eAssembleConfigOpenFailed = 0x3a13,
        eFcMonitorNotOpen = 0x3a14,
        eSaveParamFailed = 0x3a15,
        eSingular = 0x3a20,
        eAssembleOvertime = 0x3a30,
        eAssembleOverload = 0x3a31,
        eAssembleForceControlOperatorStop = 0x3a32,
        eForceAssembleZUpOrZDownParamError = 0x3a33,
        eBadAssembleParam = 0x3a34,
        eForceSearchNotOne = 0x3a40,
        eBadForceSearchParam = 0x3a41,
        eBadForceGuidanceParam = 0x3a50
    };

 
    class KAANH_API TgConfig
    {
    public:
        bool is_cart_;
        std::vector<Size> ee_ids_;
        Size tg_id_;
        auto eeIds()->aris::core::Matrix;
        auto setEeIds(const aris::core::Matrix data);
    };

    class KAANH_API AccDecJerkLimit{
    public:
        double joint_jerk=10.0;     //10.0
        double cart_line_acc=5.0;        //5.0
        double cart_line_jerk=10.0;      //10.0
        double cart_angle_acc=5.0;        //5.0
        double cart_angle_jerk=10.0;      //10.0

        auto check() const->void {
            if (joint_jerk > 1000000 || joint_jerk <= 1e-9) LOCALE_THROW("joint_jerk must be bigger than 0 and less than 1000000", "关节加加速度倍率必须在0～1000000之间");
            if (cart_line_acc > 100 || cart_line_acc <= 1e-9) LOCALE_THROW("cart_line_acc must be bigger than 0 and less than 100", "末端直线加速度系数必须在0～100之间");
            if (cart_line_jerk > 1000000 || cart_line_jerk <= 1e-9) LOCALE_THROW("cart_line_jerk must be bigger than 0 and less than 1000000", "末端直线加加速度倍率必须在0～1000000之间");
            if (cart_angle_acc > 100 || cart_angle_acc <= 1e-9) LOCALE_THROW("cart_angle_acc must be bigger than 0 and less than 100", "末端姿态加速度系数必须在0～100之间");
            if (cart_angle_jerk > 1000000 || cart_angle_jerk <= 1e-9) LOCALE_THROW("cart_angle_jerk must be bigger than 0 and less than 1000000", "末端姿态加加速度倍率必须在0～1000000之间");
        }

        NLOHMANN_DEFINE_TYPE_INTRUSIVE(AccDecJerkLimit, joint_jerk, cart_line_acc, cart_line_jerk,cart_angle_acc,cart_angle_jerk)
    };

    class KAANH_API SpeedLimit

    {
    public:
        double v_tcp_max=6.0; //6.0;
        double v_tcp_min=0.0; //0.0;
        double w_tcp_max=62.8318531; //6.28318531;
        double w_tcp_min=0.0; //0.0;
        double max_manual_line_speed = 0.2;
        double max_manual_angle_speed = 30;

        auto fromUi()->void{
            v_tcp_max /= 1000.0;
            v_tcp_min /= 1000.0;
            w_tcp_max = w_tcp_max/180.0*aris::PI;
            w_tcp_min = w_tcp_min/180.0*aris::PI;
            max_manual_line_speed /= 1000;
        }

        auto toUi()->void{
            v_tcp_max *= 1000.0;
            v_tcp_min *= 1000.0;
            w_tcp_max = w_tcp_max*180.0/aris::PI;
            w_tcp_min = w_tcp_min*180.0/aris::PI;
            max_manual_line_speed *= 1000;
        }

        auto check() const->void {
            if (v_tcp_max > 10.0 || v_tcp_max <= 0.0) LOCALE_THROW("v_tcp_max must be bigger than 0 and less than 10000mm/s", "末端线速度上限必须在0～10000mm/s之间");
            if (v_tcp_min < 0.0) LOCALE_THROW("v_tcp_min must be bigger than 0", "末端线速度下限必须大于0");
            if (w_tcp_max > 62.8318531 || w_tcp_max <= 0.0) LOCALE_THROW("w_tcp_max must be bigger than 0 and less than 3600deg/s", "末端角速度上限必须在0～3600deg/s之间");
            if (w_tcp_min < 0.0) LOCALE_THROW("w_tcp_min must be bigger than 0", "末端角速度下限必须大于0");
            if (max_manual_line_speed < 0.0 || max_manual_line_speed > 0.5) LOCALE_THROW("max_manual_line_speed must be bigger than 0 and less than 500mm/s", "手动模式最大线速度必须在0～500mm/s之间");
            if (max_manual_angle_speed > 100 || max_manual_angle_speed <= 0.0) LOCALE_THROW("max_manual_angle_speed must be bigger than 0 and less than 100", "手动模式最大角速度百分比上限必须在0～100之间");
        }

        NLOHMANN_DEFINE_TYPE_INTRUSIVE(SpeedLimit, v_tcp_max, w_tcp_max, max_manual_line_speed,max_manual_angle_speed)
    };

    class KAANH_API ZoneLimit
    {
    public:
        double dis_max=0.1; //0.1;
        double dis_min=0.0; //0.0;
        double per_max=0.5; //0.5;
        double per_min=0.0; //0.0;

        auto check() const->void {
            if (dis_max > 0.100001 || dis_max <= 0.0) LOCALE_THROW("dis_max must be bigger than 0 and less than 100mm", "转弯距离上限必须在0～100mm之间");
            if (dis_min < 0.0) LOCALE_THROW("dis_min must be bigger than 0", "转弯距离下限必须大于0");
            if (per_max > 0.5 || per_max <= 0.0) LOCALE_THROW("per_max must be bigger than 0 and less than 50", "转弯百分比上限必须在0～50之间");
            if (per_min < 0.0) LOCALE_THROW("per_min must be bigger than 0", "转弯百分比下限必须大于0");
        }

        NLOHMANN_DEFINE_TYPE_INTRUSIVE(ZoneLimit, dis_max, dis_min, per_max, per_min)
    };

enum class KAANH_API CouplingType : int
{
    kToolTool = 1, // 外部移动工具情形
    // kWovjWobj
};

NLOHMANN_JSON_SERIALIZE_ENUM(CouplingType, {{CouplingType::kToolTool, "ToolTool"}})


class KAANH_API CouplingConfig
{
public:
    bool is_coupling = false;
    CouplingType type {CouplingType::kToolTool};

    NLOHMANN_DEFINE_TYPE_INTRUSIVE(CouplingConfig, is_coupling, type)
};






class KAANH_API MoveParam {
public:
    auto init()->void;
    auto setAccDecJerkLimit(const AccDecJerkLimit& a)->void;
    auto getAccDecJerkLimit()const->const AccDecJerkLimit&;
    auto setSPeedLimit(const SpeedLimit& spl)->void;
    auto getSpeedLimit()const->const SpeedLimit&;
    auto setZonelimit(const ZoneLimit& zn)->void;
    auto getZonelimit()const->const ZoneLimit&;
    auto setCouplingConfig(const CouplingConfig& cp_config)->void;
    auto getCouplingConfig()const->const CouplingConfig&;
    auto setConfDataCheckState(bool val) -> void;
    auto getConfDataCheckState() -> bool;
    auto setSp(bool val) -> void;
    auto isUseSp() -> bool;

    std::atomic_bool manual_stopped {false};
    std::vector<double> motion_pos_;
    std::function<void(int32_t, bool)>rtTrigCallBack{nullptr};
    std::function<void(int32_t)>nrtTrigCallBack{nullptr};
    auto registerRtTrigFunc(std::function<void(int32_t, bool)> cbk)->void;
    auto registerNrtTrigFunc(std::function<void(int32_t)> cbk)->void;
    auto setLastPos(const std::vector<double> &pos)->void;
    auto lastPos()->const std::vector<double>&;
    static MoveParam& instance() {
        static MoveParam inst;
        return inst;
    }
private:
    AccDecJerkLimit adjlimit;
    SpeedLimit speedlimit;
    ZoneLimit zonelimit;
    CouplingConfig coupling_config;
    std::atomic_bool check_confdata_ {true};
    std::atomic_bool use_sp {false};


    explicit MoveParam() {}
    MoveParam(const MoveParam &) = delete;
    MoveParam& operator=(const MoveParam &) = delete;
};


	class KAANH_API Speed
	{
	public:
		double w_per;
		double v_tcp;
		double w_tcp;
        double v_ext;
        double w_ext;
	};

    auto toJsonADJ(nlohmann::json& j, const AccDecJerkLimit& adj)->void;
    auto toJsonSL(nlohmann::json& j, const SpeedLimit& sl)->void;
    auto fromJsonADJ(const nlohmann::json& j, AccDecJerkLimit& adj)->void;
    auto fromJsonSL(const nlohmann::json& j, SpeedLimit& sl)->void;


class KAANH_API ClassGeneratorAndParser {
public:
    class KAANH_API RobotTarget {
    public:
        static auto registerClass()->const kaanh::program::UType&;
        static auto registerConfigData()->const kaanh::program::UType&;
        static auto parse(const kaanh::program::RValue &rv)->std::vector<std::tuple<std::vector<double>,std::vector<int>,std::vector<int>>>;

    public:
        //! 根据末端类型生成成员变量列表
        static auto generateEeTypeMembers(aris::dynamic::EEType ee_type)->std::vector<std::pair<std::string, kaanh::program::RValue>>;
        //! 根据末端类型获取末端类名称(末端类也可能没有注册)
        static auto getEeTypeName(aris::dynamic::EEType ee_type)->std::string;
        //! 根据末端类型集合，注册末端类
        static auto registerEeTypes(const std::set<aris::dynamic::EEType> &ee_types)->void;
        //! 根据末端类类型名称对末端数据进制转换
        static auto convertUnit(std::vector<double> &val, const std::string &type_name, bool to_si)->void;
    };

    class KAANH_API JointTarget {
    public:
        static auto registerClass()->kaanh::program::UType&;
        static auto parse(const kaanh::program::RValue &rv)->std::vector<double>;
    };

    class KAANH_API Speed {
    public:
        static auto registerClass()->kaanh::program::UType&;
        static auto parseJ(const kaanh::program::RValue &rv)->std::vector<int>;
        static auto parseC(const kaanh::program::RValue &rv)->std::vector<std::vector<double>>;
    };

    class KAANH_API Zone {
    public:
        static auto registerClass()->kaanh::program::UType&;
        static auto parseJ(const kaanh::program::RValue &rv)->std::vector<std::vector<double>>;
        static auto parseC(const kaanh::program::RValue &rv)->std::vector<std::vector<double>>;
    };

    class KAANH_API Offset {
    public:
        static auto registerClass()->kaanh::program::UType&;
        static auto parse(const kaanh::program::RValue &rv)->std::vector<std::vector<double>>;
        static auto registerEeTypes(const std::set<aris::dynamic::EEType> &ee_types)->void;
        static auto generateEeTypeMembers(aris::dynamic::EEType ee_type)->std::vector<std::pair<std::string, kaanh::program::RValue>>;
        static auto getEeTypeName(aris::dynamic::EEType ee_type)->std::string;
    };

public:
    static auto registerClass()->void;
    static auto parse(const kaanh::program::RValue &rv)->std::vector<aris::Size>;
private:

};

}

#endif // KAANH_MOTION_MOTION_HPP_

