#ifndef KAANH_MULTI_MOTION_MANAGER_HPP_
#define KAANH_MULTI_MOTION_MANAGER_HPP_

#include <aris.hpp>
#include "kaanh_lib_export.h"
#include "kaanh/general/macro.hpp"
#include "kaanh/multi_motion/motion_config.hpp"
#include"kaanh/general/macro.hpp"
using namespace aris::dynamic;
using aris::Size;
namespace kaanh::multi_motion
{
// 要求反解出来的值一定是在正负360
// puma : 校验1 4 6轴
// scara: 校验1 4 轴
auto deg_to_cfi(double input_deg) -> int;
// 迪卡尔转轴空间时，角度可能与示教时相差360,按照示教时的相位信息将关节角度转到期望象限内
auto deg_to_cfi_deg(double& deg,int cfi) -> void;

class KAANH_API BasePe
{
public:

    auto virtual getPe(const Marker* tool,const Marker*wobj, double* out_pe,int* confdata,bool is_std_unit)->aris::Size = 0;
    auto virtual getVa(const Marker* tool,const Marker*wobj, double* out_vel,bool is_std_unit)->aris::Size;
    auto getEe() -> const MotionBase* {return ee_;}
    auto getInputPos() -> const std::vector<double>;
    auto currentWhichRoot()->int;
    auto setCurrentWhichRoot(int which_root);
    explicit BasePe(MotionBase* ee);
    ~BasePe() = default;
private:
    MotionBase* ee_{nullptr};
    std::vector<double> inputpos;
    std::atomic<int> cur_which_root = -1;
};

class KAANH_API AxisPe : public BasePe
{
    public:
    auto virtual getPe(const Marker* tool,const Marker*wobj, double* out_pe,int* confdata,bool is_std_unit)->aris::Size override;
    explicit AxisPe(MotionBase* ee = nullptr) : BasePe(ee){};
    ~AxisPe() = default;
};

class KAANH_API LinePe : public BasePe
{
    public:
    auto virtual getPe(const Marker* tool,const Marker*wobj, double* out_pe,int* confdata,bool is_std_unit)->aris::Size override;
    explicit LinePe(MotionBase* ee = nullptr) : BasePe(ee){};
    ~LinePe() = default;
};

class KAANH_API ScaraPe : public BasePe
{
public:
    auto virtual getPe(const Marker* tool,const Marker*wobj, double* out_pe,int* confdata,bool is_std_unit)->aris::Size override;
    explicit ScaraPe(MotionBase* ee = nullptr) : BasePe(ee){};
    ~ScaraPe() = default;
};

class KAANH_API DeltaPe : public BasePe
{
    public:
    auto virtual getPe(const Marker* tool,const Marker*wobj, double* out_pe,int* confdata,bool is_std_unit)->aris::Size override;
    explicit DeltaPe(MotionBase* ee = nullptr) : BasePe(ee){};
    ~DeltaPe() = default;
};

class KAANH_API PumaPe : public BasePe
{
 public:
    auto virtual getPe(const Marker* tool,const Marker*wobj, double* out_pe,int* confdata,bool is_std_unit)->aris::Size override;
    explicit PumaPe(MotionBase* ee = nullptr) : BasePe(ee){};
    ~PumaPe() = default;
};

class KAANH_API SevenAxisPe : public BasePe
{
 public:
    auto virtual getPe(const Marker* tool,const Marker*wobj, double* out_pe,int* confdata,bool is_std_unit)->aris::Size override;
    explicit SevenAxisPe(MotionBase* ee = nullptr) : BasePe(ee){};
    ~SevenAxisPe() = default;
};

class KAANH_API AbenicsPe : public BasePe
{
 public:
    auto virtual getPe(const Marker* tool,const Marker*wobj, double* out_pe,int* confdata,bool is_std_unit)->aris::Size override;
    explicit AbenicsPe(MotionBase* ee = nullptr) : BasePe(ee){};
    ~AbenicsPe() = default;
};

class KAANH_API WaferPe : public BasePe
{
    public:
    auto virtual getPe(const Marker* tool,const Marker*wobj, double* out_pe,int* confdata,bool is_std_unit)->aris::Size override;
    explicit WaferPe(MotionBase* ee = nullptr) : BasePe(ee){};
    ~WaferPe() = default;
};

// 在twm之后初始化
class KAANH_API EeManager
{

public:

    auto getPe(const std::vector<Marker*> tools,const std::vector<Marker*> wobjs,
               const std::vector<aris::Size> ctrl_ee_id,  std::vector<double> *out_pe,std::array<int,4> *confdata,bool is_std_unit)->void;

    auto getPe(const Marker* tool,const Marker* wobj,const aris::Size ctrl_ee_id, double *out_pe,int *confdata,bool is_std_unit)->void;
    auto getPq(const std::vector<aris::Size> ctrl_ee_id,const std::vector<std::vector<double>>&pe,std::vector<std::vector<double>>& pq)->void;
    auto getPq(const aris::Size ctrl_ee_id,const std::vector<double>&pe,std::vector<double>& pq)->void;
    auto getVa(const std::vector<Marker*> tools,const std::vector<Marker*> wobjs,
               const std::vector<aris::Size> ctrl_ee_id,  double *out_vel,bool is_std_unit)->void;
    auto getControlEes(std::vector<aris::Size> ee_ids)->std::vector<aris::dynamic::MotionBase*>; //获取要控制的笛卡尔末端
    auto getControlEeTypes(std::vector<aris::Size> ee_ids)->std::vector<aris::dynamic::EEType>; //获取要控制的笛卡尔末端
    auto getControlMotions(std::vector<aris::Size> motion_ids)->std::vector<aris::dynamic::Motion*>; // 获取要控制的轴空间末端
    auto getControlMotionTypes(std::vector<aris::Size> motion_ids)->std::vector<aris::dynamic::EEType>; // 获取要控制的轴空间末端
    auto getAllEes()->std::vector<aris::dynamic::MotionBase*>;
    auto getAllEeTypes()->std::vector<aris::dynamic::EEType>;
    auto getAllMotions()->std::vector<aris::dynamic::Motion*>;
    auto getAllMotionTypes()->std::vector<aris::dynamic::EEType>;
    auto getModels(std::vector<aris::Size> model_ids)->std::vector<aris::dynamic::ModelBase*>;
    auto getModel(aris::Size model_id)->aris::dynamic::ModelBase*;
    auto getModelMotions(std::vector<aris::Size> model_ids)->std::vector<aris::dynamic::Motion*>;
    auto getModelMotion(aris::Size model_id)->std::vector<aris::dynamic::Motion*>;
    auto getModelMotionIds(std::vector<aris::Size> model_ids)->std::vector<aris::Size>;
    auto getModelNum(aris::Size model_id)->aris::Size;
    
    // 配置
    auto getPeConfig()->const std::vector<std::vector<std::pair<std::string,std::string>>>;
    auto getPosConfig()->const std::vector<std::vector<std::pair<std::string,std::string>>>;
    auto getJogcConfig()->const std::vector<std::vector<std::pair<std::string,std::string>>>;

    auto init()->void;

    // 校验工作空间之外的点   不同解空间的点
    auto isReach(aris::Size ee_id,aris::Size tool_id,aris::Size wobj_id, const std::vector<double>  ee_pos,const int* confdata,const bool check_axis = true)->bool;
    auto twToOutput(const Model*m, const Marker* tool,const Marker* wobj,std::vector<double>& output)->void;

    EeManager();
    ~EeManager();
    static EeManager& instance(); 
    KAANH_DELETE_BIG_FOUR(EeManager);

private:
    struct Imp;
    std::unique_ptr<Imp> imp_;
};



enum class KAANH_API ToolMode {
    kTool = 1,        //!< 正常工具
    kExTool,         //!< 外部工具
};

NLOHMANN_JSON_SERIALIZE_ENUM(ToolMode, {
    {ToolMode::kTool, "Tool"},
    {ToolMode::kExTool, "ExTool"}
})


class KAANH_API ToolWobjManager
{

public:
    static ToolWobjManager& instance() {
        static ToolWobjManager ins;
        return ins;
    }
    auto init()->void;

    // 正常工具工件 取 1 号时下发id为 1
    auto getTools(std::vector<Size> ee_ids,std::vector<Size> tool_ids)->std::vector<aris::dynamic::Marker*>;
    auto getWobjs(std::vector<Size> ee_ids,std::vector<Size> wobj_ids)->std::vector<aris::dynamic::Marker*>;
    // 外部工具和手持工件 取 1 号时下发id为 0
    auto getExtTools(std::vector<Size> ee_ids,std::vector<Size> ext_tool_ids)->std::vector<aris::dynamic::Marker*>;
    auto getHdWobjs(std::vector<Size> ee_ids,std::vector<Size> hd_wobj_ids)->std::vector<aris::dynamic::Marker*>;

    // 正常工具工件 取 1 号时下发id为 1
    auto getTool(Size ee_id,Size tool_id)->aris::dynamic::Marker*;
    auto getWobj(Size ee_id,Size wobj_id)->aris::dynamic::Marker*;
    // 外部工具和手持工件 取 1 号时下发id为 0
    auto getExtTool(Size ee_id,Size ext_tool_id)->aris::dynamic::Marker*;
    auto getHdWobj(Size ee_id,Size hd_wobj_id)->aris::dynamic::Marker*;

    auto getModelId(Size ee_id)->Size;
    auto eeToModelMap()->std::map<aris::Size,aris::Size>;
    auto getModels(std::vector<aris::Size> ee_ids)->std::vector<aris::dynamic::ModelBase*>;
    auto getModel(aris::Size ee_id)->aris::dynamic::ModelBase*;


    auto toolNum()->std::vector<int>;
    auto wobjNum()->std::vector<int>;
    auto exToolNum()->std::vector<int>;
    auto hdWobjNum()->std::vector<int>;

    auto toolMode()->const std::vector<ToolMode>;
    auto setToolMode(const std::vector<ToolMode> tool_mode)->void;

    ToolWobjManager();
    ~ToolWobjManager();

private:
    struct Imp;
    std::unique_ptr<Imp> imp_;

};

class KAANH_API TrajectoryGeneratorManager
{

public:
    static TrajectoryGeneratorManager& instance()
    {
        static TrajectoryGeneratorManager ins;
        return ins;
    }
    auto init()->void;// 初始化表 和 规划器
    auto setTgConfig(const std::vector<TgConfig> &tg_config)->void;
    auto tgConfig() const->const std::vector<TgConfig>&;
    auto getTrajectoryGenerator(Size tg_id)->aris::plan::TrajectoryGenerator&;
    auto getAjTg()->aris::plan::TrajectoryGenerator&;
    auto getCartTg()->aris::plan::TrajectoryGenerator&;
    auto getControlId(Size tg_id)->std::vector<Size>;  //获取要控制的末端号
    auto getControlEes(Size tg_id)->std::vector<aris::dynamic::MotionBase*>; //获取要控制的笛卡尔末端
    auto getControlEeTypes(Size tg_id)->std::vector<aris::dynamic::EEType>; //获取要控制的笛卡尔末端
    auto getControlMotions(Size tg_id)->std::vector<aris::dynamic::Motion*>; // 获取要控制的轴空间末端
    auto getControlMotionTypes(Size tg_id)->std::vector<aris::dynamic::EEType>; // 获取要控制的轴空间末端

    auto getAllEes()->std::vector<aris::dynamic::MotionBase*>; //获取All笛卡尔末端
    auto getAllEeTypes()->std::vector<aris::dynamic::EEType>; //获取All笛卡尔末端
    auto getAllMotions()->std::vector<aris::dynamic::Motion*>; // 获取All轴空间末端
    auto getAllMotionTypes()->std::vector<aris::dynamic::EEType>; // 获取All轴空间末端

private:

    TrajectoryGeneratorManager();
    TrajectoryGeneratorManager(const TrajectoryGeneratorManager& other);
    ~TrajectoryGeneratorManager();
private:
    struct Imp;
    std::unique_ptr<Imp> imp_;
};


class KAANH_API SingularProcessorManager
{

public:
    static SingularProcessorManager& instance()
    {
        static SingularProcessorManager ins;
        return ins;
    }
    auto init()->void;// 
    auto cartMoveSp()->aris::plan::SingularProcessor*;
    auto manualMoveSp()->aris::plan::SingularProcessor*;

private:

    SingularProcessorManager();
    SingularProcessorManager(const SingularProcessorManager& other);
    ~SingularProcessorManager();
private:
    struct Imp;
    std::unique_ptr<Imp> imp_;
};

}

#endif
