#ifndef KAANH_JOG_PLAN_HPP_
#define KAANH_JOG_PLAN_HPP_

#include "kaanh/module/middle_module.hpp"
#include "kaanh/general/macro.hpp"
#include <aris.hpp>
#include <stdlib.h>
#include <vector>
#include <atomic>
#include "kaanh//general/macro.hpp"
#include "kaanh/general/json.hpp"
using namespace aris::plan;
using aris::Size;

namespace kaanh::multi_motion 
{

enum class JogCouplingMode
{
	kJogEe, //控制单个末端
	kJogMultiEe // 控制多个末端
};
NLOHMANN_JSON_SERIALIZE_ENUM(JogCouplingMode, {{JogCouplingMode::kJogEe, "JogEe"},{JogCouplingMode::kJogMultiEe, "JogMultiEe"}})


class AxisParam
{

public:
	auto setJogJVel(const std::vector<double> vel)->void;
	auto jogJVel() const-> std::vector<double>;

	auto setJogJAcc(const std::vector<double> acc)->void;
	auto jogJAcc() const-> std::vector<double>;

	auto setJogJDec(const std::vector<double> dec)->void;
	auto jogJDec() const-> std::vector<double>;

	auto setJogJJerk(const std::vector<double> jerk)->void;
	auto jogJJerk() const->std::vector<double>;

	AxisParam();
	~AxisParam();
private:
	struct Imp;
	std::unique_ptr<Imp> imp_;
};


class CartParam
{

public:

	auto setJogCVel(const std::vector<double> vel)->void;
	auto jogCVel() const-> std::vector<double>;

	auto setJogCAcc(const std::vector<double> acc)->void;
	auto jogCAcc() const-> std::vector<double>;

	auto setJogCDec(const std::vector<double> dec)->void;
	auto jogCDec() const-> std::vector<double>;

    auto setJogCJerk(const std::vector<double> jerk)->void;
    auto jogCJerk() const->std::vector<double>;

	CartParam();
	~CartParam();
private:
	struct Imp;
	std::unique_ptr<Imp> imp_;
};

class KAANH_API JogControl : public kaanh::module::MiddleModule {


public:
	auto virtual init()->void override;
	auto virtual execute(const std::string &str, std::function<void(std::string)> send_ret) noexcept->std::pair<std::string, std::string> override;
	static auto instanceInCs()->JogControl&;

	auto JogJParamPool()->aris::core::PointerArray<AxisParam>&;
	auto JogJParamPool() const->const aris::core::PointerArray<AxisParam>& { return const_cast<JogControl*>(this)->JogJParamPool(); }
	auto resetJogJParamPool(aris::core::PointerArray<AxisParam> *pool)->void;
	auto getJogJParamIdMap() const-> const std::map<int,std::pair<int,int>>;

	auto JogCParamPool()->aris::core::PointerArray<CartParam>&;
	auto JogCParamPool() const->const aris::core::PointerArray<CartParam>& { return const_cast<JogControl*>(this)->JogCParamPool(); }
	auto resetJogCParamPool(aris::core::PointerArray<CartParam> *pool)->void;

	auto setJogMode(const JogCouplingMode mode) ->void;
	auto getJogMode() const -> JogCouplingMode;

	auto setMultiJogIds(const std::set<int> ids)->void;
	auto multiJogIds() const->const std::set<int>;

	// auto setJogJVel(const std::vector<double> vel)->void;
	// auto jogJVel() const-> std::vector<double>;

	// auto setJogJAcc(const std::vector<double> acc)->void;
	// auto jogJAcc() const-> std::vector<double>;

	// auto setJogJDec(const std::vector<double> dec)->void;
	// auto jogJDec() const-> std::vector<double>;

	// auto setJogJJerk(const std::vector<double> jerk)->void;
	// auto jogJJerk() const->std::vector<double>;

	// auto setJogCVel(const std::vector<double> vel)->void;
	// auto jogCVel() const-> std::vector<double>;

	// auto setJogCAcc(const std::vector<double> acc)->void;
	// auto jogCAcc() const-> std::vector<double>;

	// auto setJogCDec(const std::vector<double> dec)->void;
	// auto jogCDec() const-> std::vector<double>;

    // auto setJogCJerk(const std::vector<double> jerk)->void;
    // auto jogCJerk() const->std::vector<double>;

	auto isStop() const->bool;
	auto setStop(bool val) -> void;

	auto isRealStop() const->bool;
	auto setRealStop(bool val) -> void;

	auto isStopInSingular() const->bool;
	auto setStopInSingular(bool val) -> void;

	auto lastDir() const->std::string;
	auto setLastDir(const std::string) -> void;

	auto totalCount() ->std::int32_t;
	auto setTotalCount(std::uint32_t count)->void;


private:
	struct Imp;
	std::unique_ptr<Imp> imp_;

public:

	JogControl();
	virtual ~JogControl();
	KAANH_DECLARE_BIG_FOUR(JogControl)

};

class KAANH_API JogJ : public aris::core::CloneObject<JogJ, aris::plan::Plan>
{
public:
	auto virtual prepareNrt()->void override;
	auto virtual executeRT()->int override;
	auto virtual collectNrt()->void override;
	auto getControlParam()->void;
	KAANH_DECLARE_BIG_FOUR(JogJ)

	virtual ~JogJ();
	explicit JogJ(const std::string &name = "JogJ");

private:
	struct Imp;
	aris::core::ImpPtr<Imp>imp_;
};

class KAANH_API JogC : public aris::core::CloneObject<JogC, aris::plan::Plan>
{
public:
	auto virtual prepareNrt()->void override;
	auto virtual executeRT()->int override;
	auto virtual collectNrt()->void override;
	auto getControlParam()->void;
	KAANH_DECLARE_BIG_FOUR(JogC)
	virtual ~JogC();
	explicit JogC(const std::string &name = "JogC");

private:
	struct Imp;
	aris::core::ImpPtr<Imp>imp_;
};

class JogS : public aris::core::CloneObject<JogS, aris::plan::Plan>
{
public:
	auto virtual prepareNrt()->void override;
	auto virtual executeRT()->int override;
	auto virtual collectNrt()->void override;
	auto getControlParam()->void;
	KAANH_DECLARE_BIG_FOUR(JogS)
	virtual ~JogS();
	explicit JogS(const std::string &name = "JogS");

private:
	struct Imp;
	aris::core::ImpPtr<Imp>imp_;
};

}

#endif  // KAANH_MULTI_JOG_PLAN_HPP_

