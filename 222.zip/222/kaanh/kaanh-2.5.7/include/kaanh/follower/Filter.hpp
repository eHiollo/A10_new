/**
 * @file Filter.hpp
 * @author hanzhuchen666@gmail.com
 * @brief 定义了滤波器的接口，和各种类型的滤波器
 * @version 0.1
 * @date 2024-12-09
 * 
 * @copyright Copyright (c) 2024
 * 
 */
#ifndef FILTER_HPP
#define FILTER_HPP
#include <numeric>
#include <vector>
#include <memory>
#include <algorithm>

/**
 * @brief 这个类提供了一个环形缓冲区。即使缓冲区已满，也可以继续添加元素，新元素会覆盖最旧的元素。同时提供了获取全部数据的功能。
 * 
 * @tparam T 存储类型
 */
template<typename T>
class RollingBuffer {
public:
    RollingBuffer(int capacity) 
        : capacity_(capacity), 
          data_(std::make_shared<std::vector<T>>(capacity)), 
          sum_(0) {}

    auto push(const T &val) -> bool {
        if (full()) {
            // 缓冲区已满，需要覆盖最旧元素
            // 最旧元素在front_位置
            sum_ -= (*data_)[front_]; 
            front_ = (front_ + 1) % capacity_;
        }
        (*data_)[rear_] = val;
        rear_ = (rear_ + 1) % capacity_;
        size_ = std::min(size_ + 1, capacity_);
        
        sum_ += val;

        return true;
    }

    auto full() const -> bool { return size_ == capacity_; }
    auto empty() const -> bool { return size_ == 0; }
    auto size() const -> int { return size_; }
    auto capacity() const -> int { return capacity_; }

    // 返回底层数据的只读指针
    auto getDataPtr() const -> std::shared_ptr<const std::vector<T>> {
        return std::shared_ptr<const std::vector<T>>(data_);
    }

    // 全部数据的有序拷贝
    auto getAllData() const -> std::vector<T> {
        std::vector<T> result;
        result.reserve(size_);
        for (int i = 0; i < size_; i++) {
            result.push_back((*data_)[(front_ + i) % capacity_]);
        }
        return result;
    }

    auto clear() -> void {
        size_ = 0;
        front_ = 0;
        rear_ = 0;
        sum_ = 0;
    }

    // 新增方法：获取当前平均值
    auto getMean() const -> double {
        if (empty()) {
            return 0.0; // 或者根据需要返回nan或抛出异常
        }
        return static_cast<double>(sum_) / size_;
    }

    RollingBuffer(const RollingBuffer &q) {
        capacity_ = q.capacity_;
        data_ = std::make_shared<std::vector<T>>(*q.data_);
        size_ = q.size_;
        front_ = q.front_;
        rear_ = q.rear_;
        sum_ = q.sum_;
    }

    RollingBuffer& operator=(const RollingBuffer &q) {
        if (this != &q) {
            capacity_ = q.capacity_;
            data_ = std::make_shared<std::vector<T>>(*q.data_);
            size_ = q.size_;
            front_ = q.front_;
            rear_ = q.rear_;
            sum_ = q.sum_;
        }
        return *this;
    }

    RollingBuffer(RollingBuffer &&q) noexcept {
        capacity_ = q.capacity_;
        data_ = std::move(q.data_);
        size_ = q.size_;
        front_ = q.front_;
        rear_ = q.rear_;
        sum_ = q.sum_;

        q.size_ = 0;
        q.front_ = 0;
        q.rear_ = 0;
        q.sum_ = 0;
        q.data_.reset();
    }

    RollingBuffer& operator=(RollingBuffer &&q) noexcept {
        if (this != &q) {
            capacity_ = q.capacity_;
            data_ = std::move(q.data_);
            size_ = q.size_;
            front_ = q.front_;
            rear_ = q.rear_;
            sum_ = q.sum_;

            q.size_ = 0;
            q.front_ = 0;
            q.rear_ = 0;
            q.sum_ = 0;
            q.data_.reset();
        }
        return *this;
    }

private:
    int capacity_;
    std::shared_ptr<std::vector<T>> data_;
    int size_{0};
    int front_{0};
    int rear_{0};
    T sum_; // 用于快速计算均值
};

/**
 * @brief 滤波器接口
 * 
 * @tparam T 滤波器数据类型
 */
template<typename T>
class Filter{
    public:
    virtual ~Filter() = default;
    virtual auto update(T input)->T = 0;
    virtual auto reset()->void = 0;
};
/**
 * @brief 均值滤波类
 * 
 * @tparam T 均值滤波类型
 */

class MeanFilter : public Filter<double> {
public:
    explicit MeanFilter(int window_size) : buffer_(window_size) {}

    virtual double update(double val) override {
        buffer_.push(val);
        return buffer_.getMean();
    }

    virtual void reset() override {
        buffer_.clear();
    }

private:
    RollingBuffer<double> buffer_;
};


#endif // !FILTER_HPP