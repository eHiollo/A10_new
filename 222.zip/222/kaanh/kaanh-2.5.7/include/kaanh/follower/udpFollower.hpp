/**
 * @file udpFollower.hpp
 * @author Zhuchen Han hanzhuchen666@gmail.com
 * @brief 
 * @version 0.1
 * @date 2024-11-22
 * 
 * @copyright Copyright (c) 2024
 * 
 */
#ifndef KAANHBIN_UDP_FOLLOWER_HPP_
#define KAANHBIN_UDP_FOLLOWER_HPP_
#include "kaanh/module/middle_module.hpp"
#include "kaanh/general/macro.hpp"
#include "kaanh_lib_export.h"
#include "kaanh/multi_motion/motion_plan.hpp"
#include "aris.hpp"
#include "kaanh/multi_motion/motion_manager.hpp"
namespace kaanh::follower{

    class FollowerParamBase
    {
    private:
        struct Imp;
        std::unique_ptr<Imp> imp_;
    public:


        auto virtual init()->void{};
        auto tg()-> aris::plan::TrajectoryGenerator*;
        auto tgId()->int;
        auto setTgId(const int tg_id) ->void;

        auto socketServer()->aris::core::SocketServer&;
        auto setSocketServer(aris::core::SocketServer *server)->void;
        
        auto setLastId(const std::uint64_t id)->void;
        auto lastId()->std::uint64_t;

        // 全局单利快速索引
        auto multiModel()-> aris::dynamic::MultiModel*; 
        auto pgmCalculator()-> kaanh::program::PgmCalculator*;
        auto robot()-> kaanh::robot::Robot*;
        auto pgmController()-> kaanh::module::PgmController*;   
        auto moveParam()-> kaanh::multi_motion::MoveParam*; 
        auto forceModule()-> kaanh::package::Force*; 
        auto twManager()-> kaanh::multi_motion::ToolWobjManager*; 
        auto eeManager()-> kaanh::multi_motion::EeManager*; 
        auto tgManager()-> kaanh::multi_motion::TrajectoryGeneratorManager*; 
        auto spManager()-> kaanh::multi_motion::SingularProcessorManager*; 
        auto log()-> kaanh::log::Sqlite3Log*;

        auto getInstance()->void;

        FollowerParamBase(/* args */);
        ~FollowerParamBase();
    };
    

    class FollowerAjParam : public FollowerParamBase
    {
    private:
        struct Imp;
        std::unique_ptr<Imp> imp_;
    public:
        auto virtual init()->void override;
        auto ctrlMotions()-> const std::vector<aris::dynamic::Motion*>;
        auto ctrlMotionId()-> const std::vector<aris::Size>;
        auto addAjDataToTg(const std::vector<double>& pos,const std::vector<double>& vel = std::vector<double>())->void;

        // 不规划直接写入电机
        auto addAjDataToQueue(const std::vector<double>& pos)->void;
        auto getAjDataFromQueue(std::vector<double>& cur_pos)->bool;
        auto clearAjDataQueue()->void;
        auto ajDataToQueue()->const aris::core::LockFreeArrayQueue<std::vector<double>>&;

        FollowerAjParam(/* args */);
        ~FollowerAjParam();
    };
    
    class FollowerCartParam : public FollowerParamBase
    {
    private:
        struct Imp;
        std::unique_ptr<Imp> imp_;
    public:
        auto virtual init()->void override;
        auto ctrlEes()-> const std::vector<aris::dynamic::MotionBase*>;
        auto ctrlEeTypes()-> const std::vector<aris::dynamic::EEType>;
        auto ctrlEeId()-> const std::vector<aris::Size>;

        auto getSpeed(const std::vector<std::vector<double>>& v,std::vector<double>& vel,std::vector<double>& acc,std::vector<double>& jerk)->void;
        auto getZone(const std::vector<std::vector<double>>& zone,std::vector<double>& zone_out)->void;
        auto getPe(const std::vector<std::tuple<std::vector<double>, std::vector<int>,std::vector<int>>>& pe,std::vector<std::vector<double>>& pe_out)->void;
        auto getPe(const std::vector<std::vector<double>>& pe_in,std::vector<double>& pe_out)->void;
        auto setPe(const double*cur_pe,aris::plan::Plan*plan)->int;

        auto addCartDataToTg(const std::vector<double>& pos,const std::vector<double>& vel)->void;

        auto getToolWobj()->void;
        auto getInitPe()->std::vector<std::vector<double>>;



        auto tool0s()->std::vector<aris::dynamic::Marker*>;
        auto tools()->std::vector<aris::dynamic::Marker*>;
        auto wobj0s()->std::vector<aris::dynamic::Marker*>;
        auto wobjs()->std::vector<aris::dynamic::Marker*>;

        // 无锁队列传输
        auto addDataToQueue(const std::vector<std::vector<double>>& pe)->void;
        auto getDataFromQueue(std::vector<std::vector<double>>& cur_pe)->bool;
        auto clearDataQueue()->void;
        auto dataToQueue()->const aris::core::LockFreeArrayQueue<std::vector<std::vector<double>>>&;


        FollowerCartParam(/* args */);
        ~FollowerCartParam();
    };
    

    enum class FollowerMode{
        kNone = 0,
        kAixs,
        kCart
    };
    NLOHMANN_JSON_SERIALIZE_ENUM(FollowerMode, {{FollowerMode::kNone, "None"},{FollowerMode::kAixs, "Axis"},{FollowerMode::kCart, "Cart"}})

    class UDPFollower : public kaanh::module::MiddleModule{
    public:



        auto virtual init()->void override;
        auto virtual execute(const std::string &str, std::function<void(std::string)> send_ret) noexcept->std::pair<std::string, std::string> override;
        static auto instanceInCs()->UDPFollower&;
       
        auto isRunning()->bool;
        auto setRunningState(const bool val)->void;

        auto setFollowerMode(const FollowerMode mode)->void;
        auto getFollowerMode() -> const FollowerMode&;

        auto followerParamPool()->aris::core::PointerArray<FollowerParamBase>&;
        auto followerParamPool() const->const aris::core::PointerArray<FollowerParamBase>& { return const_cast<UDPFollower*>(this)->followerParamPool(); }
        auto resetFollowerParamPool(aris::core::PointerArray<FollowerParamBase> *pool)->void;

    private:
        struct Imp;
        std::unique_ptr<Imp> imp_;
    public:
        UDPFollower();
        ~UDPFollower();
        KAANH_DELETE_BIG_FOUR(UDPFollower)
    };
class KAANH_API FollowerAjTg :public aris::core::CloneObject<FollowerAjTg, aris::plan::Plan>
{

public:

    auto virtual prepareNrt()->void override;
    auto virtual executeRT()->int override;
    auto virtual collectNrt()->void override;
    explicit FollowerAjTg (const std::string &name = "FollowerAjTg");
    KAANH_DECLARE_BIG_FOUR(FollowerAjTg)
    virtual ~FollowerAjTg ();
private:
    struct Imp;
    aris::core::ImpPtr<Imp> imp_; 
};

// 直接写入电机
class KAANH_API FollowerAj :public aris::core::CloneObject<FollowerAj, aris::plan::Plan>
{

public:

    auto virtual prepareNrt()->void override;
    auto virtual executeRT()->int override;
    auto virtual collectNrt()->void override;
    explicit FollowerAj (const std::string &name = "FollowerAj");
    KAANH_DECLARE_BIG_FOUR(FollowerAj)
    virtual ~FollowerAj ();
private:
    struct Imp;
    aris::core::ImpPtr<Imp> imp_; 
};
/**
 * @brief 使用MoveAbsolute2函数进行规划的跟随类
 * 
 */
class KAANH_API FollowerAjAbsolute2: public aris::core::CloneObject<FollowerAjAbsolute2, aris::plan::Plan>
{
public:
    auto virtual prepareNrt()->void;
    auto virtual executeRT()->int;
    auto virtual collectNrt()->void;
    explicit FollowerAjAbsolute2(const std::string &name = "FollowerAjAbsolute2");
    KAANH_DECLARE_BIG_FOUR(FollowerAjAbsolute2)
    virtual ~FollowerAjAbsolute2();
private:
    struct Imp;
    aris::core::ImpPtr<Imp> imp_;
};


// 下发的是相对原点的增量
class KAANH_API FollowerCart : public aris::core::CloneObject<FollowerCart, aris::plan::Plan>
{
public:
	auto virtual prepareNrt()->void override;
	auto virtual executeRT()->int override;
	auto virtual collectNrt()->void override;
	auto getControlParam()->void;
	KAANH_DECLARE_BIG_FOUR(FollowerCart)
	virtual ~FollowerCart();
	explicit FollowerCart(const std::string &name = "FollowerCart");

private:
	struct Imp;
	aris::core::ImpPtr<Imp>imp_;
};

} // namespace kaanh::follower

#endif // KAANHBIN_UDP_FOLLOWER_HPP_
