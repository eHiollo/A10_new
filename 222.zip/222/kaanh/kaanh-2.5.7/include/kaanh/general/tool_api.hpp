#ifndef KAANH_GENERAL_TOOL_API_HPP_
#define KAANH_GENERAL_TOOL_API_HPP_

#include <string>
#include <filesystem>
#include <cstddef>
#include "kaanh/general/macro.hpp"
namespace kaanh::general {
    /**
     * @brief: 生成随机字符串(a-zA-Z0-9)
     * @param {unsigned} length 字符串长度, 默认为0
     * @return {string} 生成的随机字符串
     * @remark 如果长度为0, 则默认生成长度1～32的随机字符串
     */
    //auto randomString(unsigned length = 0) noexcept->std::string;

KAANH_API auto isChildPath(const std::filesystem::path &child, const std::filesystem::path &parent)->bool;

KAANH_API auto saveCs()->void;

KAANH_API auto s_mm2m(double *v, std::size_t len)->void;

KAANH_API auto s_m2mm(double *v, std::size_t len)->void;

KAANH_API auto s_deg2rad(double *v, std::size_t len)->void;

KAANH_API auto s_rad2deg(double *v, std::size_t len)->void;

} // namespace kaanh::general


#endif // KAANH_GENERAL_TOOL_API_HPP_
