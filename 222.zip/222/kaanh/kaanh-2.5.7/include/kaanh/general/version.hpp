#ifndef KAANH_GENERAL_VERSION_HPP_
#define KAANH_GENERAL_VERSION_HPP_

#include <map>
#include <cstring>
#include "kaanh/general/macro.hpp"
namespace kaanh::general {

    // 返回值 <版本号, 版本描述>
KAANH_API auto version()->std::pair<std::string, std::string>;

}   // namespace kaanh::general

#endif  // KAANH_GENERAL_VERSION_HPP_
