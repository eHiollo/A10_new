#ifndef KAANH_GENERNAL_MACRO_HPP_
#define KAANH_GENERNAL_MACRO_HPP_

#include "kaanh/log/log.hpp"

#define ATOMIC_LOAD(ato_var) ato_var.load(std::memory_order_acquire)
#define ATOMIC_STORE(ato_var, val) ato_var.store(val, std::memory_order_release)
#define LOCALE_SELECT(en_msg, chn_msg) kaanh::log::LocaleString::select({en_msg, chn_msg})
#define LOCALE_THROW(en_msg, chn_msg) throw std::runtime_error(kaanh::log::LocaleString::select({en_msg, chn_msg}))

#define KAANH_UNUSED(var) (void)var;

//#define KAANH_DECLARE_BIG_FOUR(type_name) \
//	type_name(const type_name &other); \
//	type_name(type_name &&other) noexcept; \
//	type_name& operator=(const type_name &other); \
//	type_name& operator=(type_name &&other) noexcept;
//
//#define KAANH_DEFINE_BIG_FOUR(type_name) \
//	type_name(const type_name &other) = default; \
//	type_name(type_name &&other) noexcept = default; \
//	type_name& operator=(const type_name &other) = default; \
//	type_name& operator=(type_name &&other) noexcept = default;
//
//#define KAANH_DEFINE_BIG_FOUR_CPP(type_name) \
//	type_name::type_name(const type_name &other) = default; \
//	type_name::type_name(type_name &&other) noexcept = default; \
//	type_name& type_name::operator=(const type_name &other) = default; \
//	type_name& type_name::operator=(type_name &&other) noexcept = default;
//
//#define KAANH_DELETE_BIG_FOUR(type_name) \
//	type_name(const type_name &other) = delete; \
//	type_name(type_name &&other) = delete; \
//	type_name& operator=(const type_name &other) = delete; \
//	type_name& operator=(type_name &&other) = delete;

#define KAANH_DECLARE_BIG_FOUR(type_name) \
	type_name(const type_name &other); \
	type_name(type_name &&other); \
	type_name& operator=(const type_name &other); \
	type_name& operator=(type_name &&other);

#define KAANH_DECLARE_BIG_FOUR_NOEXCEPT(type_name) \
	type_name(const type_name &other); \
	type_name(type_name &&other)noexcept; \
	type_name& operator=(const type_name &other); \
	type_name& operator=(type_name &&other)noexcept;

#define KAANH_DEFINE_BIG_FOUR(type_name) \
	type_name(const type_name &other) = default; \
	type_name(type_name &&other) = default; \
	type_name& operator=(const type_name &other) = default; \
	type_name& operator=(type_name &&other) = default;

#define KAANH_DEFINE_BIG_FOUR_NOEXCEPT(type_name) \
	type_name(const type_name &other) = default; \
	type_name(type_name &&other)noexcept = default; \
	type_name& operator=(const type_name &other) = default; \
	type_name& operator=(type_name &&other)noexcept = default;

#define KAANH_DEFINE_BIG_FOUR_CPP(type_name) \
	type_name::type_name(const type_name &other) = default; \
	type_name::type_name(type_name &&other) = default; \
	type_name& type_name::operator=(const type_name &other) = default; \
	type_name& type_name::operator=(type_name &&other) = default;

#define KAANH_DEFINE_BIG_FOUR_CPP_NOEXCEPT(type_name) \
	type_name::type_name(const type_name &other) = default; \
	type_name::type_name(type_name &&other)noexcept = default; \
	type_name& type_name::operator=(const type_name &other) = default; \
	type_name& type_name::operator=(type_name &&other)noexcept = default;

#define KAANH_DELETE_BIG_FOUR(type_name) \
	type_name(const type_name &other) = delete; \
	type_name(type_name &&other) = delete; \
	type_name& operator=(const type_name &other) = delete; \
	type_name& operator=(type_name &&other) = delete;
#endif // KAANH_GENERNAL_MACRO_HPP_