#ifndef KAANH_GENERAL_FILE_ATOMIC_OPERATE_HPP_
#define KAANH_GENERAL_FILE_ATOMIC_OPERATE_HPP_

#include <iostream>
#include <filesystem>
#include <string>
#include <vector>
#include <atomic>

namespace kaanh::general {

//!文件操作类型
enum class FileOperateSet : int {
    kDirCreate = 1,         //!< 创建文件夹
    kFileCreate,            //!< 创建文件
    kRename,                //!< 重命名文件或文件夹
    kModify,                //!< 修改文件或文件夹
    kDelete,                //!< 删除文件或文件夹
    kCopy,                  //!< 复制文件或文件夹
    kCut,                   //!< 剪切文件或文件夹
    kPaste,                 //!< 粘贴文件或文件夹
    kBatchCopy,             //!< 批量复制文件或文件夹
    kBatchCut               //!< 批量剪切文件或文件夹
};

/*!
* @brief 路径的节点类，用作剪切板的元素
* @note 
*/
struct PathListNode
{
    std::filesystem::path file_path;
    PathListNode* next;
    PathListNode() = default;
    PathListNode(std::filesystem::path in_file_path):file_path(in_file_path), next(NULL){}
};

/*!
* @brief 路径的链表，用作剪切板
*具有头节点head_ 链表的首节点从1开始
* @note 
*/
class PathList{
    public:
    /**如果没有函数体，即如果声明了构造函数，又没有定义，会导致报错 
    这种在构造函数中初始化链表虚拟头节点的方式，好处在于，可以在析构函数中释放资源*/
    PathList(){head_=new PathListNode();}
    ~PathList(){delete head_;} 
    /**头插入值*/
    void headInsert(std::filesystem::path in_file_path);
    /**尾插入值*/
    void tailInsert(std::filesystem::path in_file_path);
    /**按位插入值*/
    void insertList(int i,std::filesystem::path in_file_path);
    /**按位删除*/
    void deleteList(int i);
    /**获取第i个元素*/
    PathListNode *getElement(int i);
    /**定位元素在第几位*/
    int LocateElem(std::filesystem::path in_file_path);
    /**获取链表长度*/
    int ListLength();
    /**打印链表*/
    void showList();
    /**反转链表*/
    void reverseList();
    /**释放链表资源，注意在成员函数使用new产生的资源，在析构函数执行时不会被释放,所以需要手动释放*/
    void freeList();

    private:
    //链表头节点，数据区域为空
    PathListNode *head_;
};


/*!
* @brief 单个文件操作信息结构体
* @note 
*/
struct FileOperateInformation
{
    enum FileOperateSet file_operation;         /**< 文件操作类型 */
    std::filesystem::path file_path;            /**< 相对目录  */
    std::string context;                        /**< 依据操作类型不同，含义不同。操作类型为重命名时，该变量是文件名。其他为文件内容。 */
};

/*!
* @brief 多个文件操作原子化类
* @note 
*/
class FileAtomicOperate{
    public:
        /**文件夹创建*/
        static void dirCreate(const std::filesystem::path in_inter_absolute_path,const std::filesystem::path in_backup_root_path,bool is_atomic_operate=0);
        /**文件创建*/
        static void fileCreate(const std::filesystem::path in_inter_absolute_path,const std::filesystem::path in_backup_root_path,bool is_atomic_operate=0);
        /**文件或目录重命名*/
        static void fileRename(const std::filesystem::path in_inter_absolute_path, const std::filesystem::path in_inter_file_context,const std::filesystem::path in_backup_root_path,bool is_atomic_operate=0);
        /**文件修改*/
        static void fileModify(const std::filesystem::path in_inter_absolute_path,const std::string in_inter_file_context,const std::filesystem::path in_backup_root_path,bool is_atomic_operate=0);
        /**文件或目录删除*/
        static void fileDelete(const std::filesystem::path in_inter_absolute_path,const std::filesystem::path in_backup_root_path,bool is_atomic_operate=0);
        /**文件或目录粘贴*/
        static void filePaste(const std::filesystem::path in_inter_absolute_path,const std::filesystem::path in_backup_root_path,bool is_atomic_operate=0);
        /**文件或目录复制*/
        static void fileCopy(const std::filesystem::path in_inter_absolute_path);
        /**文件或目录剪切*/
        static void fileCut(const std::filesystem::path in_inter_absolute_path);
        /**多个文件或目录复制，开始前清空剪切板*/
        static void fileBatchCopy(const std::vector<std::filesystem::path> in_path_vector);
        /**多个文件或目录复制*/
        static void fileBatchCut(const std::vector<std::filesystem::path> in_path_vector);
        /**回溯函数，即重启后对上次的userOperate过的文件遍历进行状态检查，如果状态不对，则将备份文件还原。*/
        static void backTrack(const std::filesystem::path in_backup_root_path);
        /**原子操作函数，此为静态成员函数
        * 传入多个文件操作信息的集合，备份文件目录默认为 ./。文件信息需传入绝对路径，在这一步中，会对进行过操作的文件备份，以便后续还原*/
        static void sBatchOperate(const std::vector<FileOperateInformation> file_oprate_assembly, const std::filesystem::path backup_root_path = "./");       
        /**原子操作函数，此为普通成员函数 */
        void batchOperate(const std::vector<FileOperateInformation> file_oprate_assembly);
        /**构造函数，根据用户输入构造文件系统根目录，备份文件目录，记录文件状态目录（用于记录被操作过的文件路径包括原路径和目标路径） 
        * ！！！ 要求用户输入的备份文件目录和 记录文件状态目录足够安全且拥有操作权限  */
        FileAtomicOperate(const std::filesystem::path in_root_directory,const std::filesystem::path in_backup_root_path);
        /**构造函数，用户只能输入根目录，备份文件目录、记录文件状态目录自动生成*/
        FileAtomicOperate(const std::filesystem::path in_root_directory);
    private:
        std::filesystem::path root_directory_;
        std::filesystem::path backup_root_directory_;
        /**当copy时，置1，cut时，置2。所以，如果状态为0，则不进行paste，如果状态为1，可以paste,如果状态为2，可以paste */
        static int copy_cut_flag_ ;
        static PathList cut_path_list_;
        static void dirCreate(const std::filesystem::path in_inter_absolute_path);
        static void fileCreate(const std::filesystem::path in_inter_absolute_path);
        static void fileRename(const std::filesystem::path in_inter_absolute_path, const std::filesystem::path in_inter_file_context);
        static void fileModify(const std::filesystem::path in_inter_absolute_path,const std::string in_inter_file_context);
        static void fileDelete(const std::filesystem::path in_inter_absolute_path);
        /**单个文件或目录批量复制，不清空剪切板！*/
        static void fileBatchCopy(const std::filesystem::path in_inter_absolute_path);
        /**单个文件或目录批量剪切，不清空剪切板！*/
        static void fileBatchCut(const std::filesystem::path in_inter_absolute_path);
        static void filePaste(const std::filesystem::path in_inter_absolute_path);
        static void backUp(const std::vector<FileOperateInformation> file_oprate_assembly, const std::filesystem::path  in_backup_root_path ,const std::filesystem::path in_root_directory = "");
};

}   // namespace kaanh::general

#endif  // KAANH_GENERAL_FILE_ATOMIC_OPERATE_HPP_