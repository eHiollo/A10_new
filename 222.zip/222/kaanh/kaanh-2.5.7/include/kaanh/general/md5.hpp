#ifndef KAANH_GENERAL_MD5_HPP_
#define KAANH_GENERAL_MD5_HPP_

#include <string>
#include "kaanh/general/macro.hpp"
namespace kaanh::general {

KAANH_API auto md5(const std::string &str)->std::string;

}	// namespace kaanh::general

#endif	// KAANH_GENERAL_MD5_HPP_