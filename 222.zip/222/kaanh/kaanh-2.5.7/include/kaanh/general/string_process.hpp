#ifndef KAANH_GENERAL_STRING_PROCESS_HPP_
#define KAANH_GENERAL_STRING_PROCESS_HPP_

#include <string>
#include <string_view>
#include <regex>
#include "kaanh/general/macro.hpp"
namespace kaanh::general {

// 匹配一个C++的合法变量/函数名称, 如stric为false, 则两端允许有空格
KAANH_API auto isLegalWord(std::string_view word, bool strict = true)->bool;

KAANH_API auto ltrimString(std::string &str)->void;

KAANH_API auto rtrimString(std::string &str)->void;

KAANH_API auto trimString(std::string &str)->void;

KAANH_API auto cltrimString(const std::string &str)->std::string;

KAANH_API auto crtrimString(const std::string &str)->std::string;

KAANH_API auto ctrimString(const std::string &str)->std::string;

KAANH_API auto ltrimStringView(std::string_view &sv)->void;

KAANH_API auto rtrimStringView(std::string_view &sv)->void;

KAANH_API auto trimStringView(std::string_view &sv)->void;

KAANH_API auto splitStringView(std::string_view sv, std::string_view sepa)->std::vector<std::string_view>;

KAANH_API auto splitString(const std::string &str, std::string_view sepa)->std::vector<std::string>;

KAANH_API auto toLower(std::string &str)->void;

KAANH_API auto toUpper(std::string &str)->void;

KAANH_API auto ctoLower(const std::string &str)->std::string;

KAANH_API auto ctoUpper(const std::string &str)->std::string;

} // namespace kaanh::general

#endif // KAANH_GENERAL_STRING_PROCESS_HPP_