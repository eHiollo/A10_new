#ifndef ZERO_CALIBRATION_H
#define ZERO_CALIBRATION_H

#include <string>
#include <vector>
#include "kaanh/general/macro.hpp"

namespace kaanh::algorithm{
class KAANH_API ZeroCalibration {
public:
	enum class RobotType {
		PUMA = 100,
		UR = 200,
		SCARA = 300
	};
public:
	ZeroCalibration( std::vector<double>& link_length, std::vector<double>& q_mea_, RobotType rob_type_);

public:
	std::vector<double> getPointConsResult();
	//std::vector<double> getPlaneConsResult(std::vector<double> p_t_e_);

private:
	std::vector<double> buildDH(std::vector<double>& q, std::vector<double>& x);
	double tcpCal(std::vector<double>& x);
	std::vector<double> kineticErrorModel(std::vector<double>& q);
	void pointConstraintModel();
	double fmin_func_point(std::vector<double>& x);

	void fminsearch(std::vector<double>& x0);

	std::vector<double> zcmatAdd(const std::vector<double>& A, const std::vector<double>& B);
	std::vector<double> zcmatSubtract(const std::vector<double>& A, const std::vector<double>& B);
	std::vector<double> zcmatMultiply(const std::vector<double>& A, const std::vector<double>& B, int m, int n, int r);
	std::vector<double> zcmatTranspose(const std::vector<double>& A, int m, int n);
	std::vector<double> zcmatInverse(const std::vector<double>& A, int n);
	std::vector<double> zcmatEye(int n);
	std::vector<double> zcmatCross(const std::vector<double>& A, const std::vector<double>& B);
	std::vector<double> zcmatDelCol(const std::vector<double>& A, int m, int n, int col);
	std::vector<double> zcmatDelRow(const std::vector<double>& A, int m, int n, int row);
	std::vector<double> zcmatCombine(const std::vector<double>& A, const std::vector<double>& B, 
									 const std::vector<double>& C, const std::vector<double>& D,
									 const std::vector<double>& E, const std::vector<double>& F,
									 const std::vector<double>& G, int m);
	double zcmatNorm(const std::vector<double>& A);

	std::vector<double> sort_order(std::vector<double>& A);

private:
	std::vector<double> link_L;
	std::vector<double> q_mea;
	std::vector<double> p_t_e;
	std::vector<double> J_point;
	std::vector<double> P_point;
	std::vector<double> x_iden;
	double fval;
	RobotType rob_type;
	int DOF;
};
}
#endif
