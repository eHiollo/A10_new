#ifndef KAANH_ALGORITHM_PLANFUNS_HPP_
#define KAANH_ALGORITHM_PLANFUNS_HPP_

#include <aris.hpp>
#include <iostream>
#include <fstream>
#include <typeinfo>
#include <vector>
#include <memory>
#include <atomic>
#include <string> 
#include <algorithm>
#include "kaanh/general/macro.hpp"
namespace kaanh::algorithm{

	using Size = std::size_t;

	class KAANH_API planconfig{
	public:
		planconfig();
		void DoubleSVelocity(const double jMax, const double aMax, const double vMax, const double sMax, double* T, double &vlim, double &alim);
		void RealSVelocity(const double t, const double jMax, const double aMax, const double vMax, const double sMax, const double* Tt, const double vlim, const double alim, double &st, double &vt, double &at, double &jt);
	};
	KAANH_API	auto moveAbsolute(double i, double begin_pos, double end_pos, double vel, double acc, double dec, double &current_pos, double &current_vel, double &current_acc, Size& total_count)->void;
	KAANH_API	auto sCurveParam(double q0, double q1, double vmax, double amax, double jmax, double &taj, double &ta, double &tv, double &tdj, double &td, double &vlim, double &alima, double &alimd)->void;
	KAANH_API	auto sCurve(double t, double q0, double q1, double vmax, double amax, double jmax, double &qcrt, double &vcrt, double &acrt, double &jcrt, size_t &T)->void;
	KAANH_API	auto sCurved(double t, double q0, double q1, double vmax, double amax, double jmax, double &qcrt, double &vcrt, double &acrt, double &jcrt, double &T, double &atime, double &vtime)->void;
	KAANH_API	auto sCurve0Param(double q0, double q1, double vmax, double amax, double jmax, double &taj, double &ta, double &tv, double &tdj, double &td, double &vlim, double &alima, double &alimd)->void;
	KAANH_API	auto sCurve0(double t, double q_start, double q_end, double v_max, double a_max, double j_max, double &q_crt, double &v_crt, double &a_crt, double &j_crt, size_t &count)->void;
	KAANH_API	auto timeStop(double i, double begin_pos, double end_pos, double t, double k, double &current_pos, double &current_vel, double &current_acc, Size& total_count)->void;
	KAANH_API	auto calOffsetPe(const std::vector<double>& offset,const aris::dynamic::EEType ee_type, double *pe)->void;
	KAANH_API	auto calOffsetPe(const std::vector<std::vector<double>>& offsets,const std::vector<aris::dynamic::EEType> ee_types, std::vector<std::vector<double>> *pe)->void;


}

#endif
