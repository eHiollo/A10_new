﻿// #ifndef KAANH_ROBOT_ERROR_HPP_ 
// #define KAANH_ROBOT_ERROR_HPP_

// #include <string_view>
// #include <any>
// #include <aris.hpp>
// #include "kaanh/general/macro.hpp"
// using namespace aris::dynamic;
// using namespace aris::plan;


// namespace kaanh::robot{

//     enum class ErrorCode : std::int32_t{
//         eForceReference = -4000,
//         eWithoutForceSensor,
//         eForceSensorOverLoaded,
//         eForceSensorGuidanceParamError,

//         eForceControlInitDataError = -3900,
//         eForceAssembleDataError,

//         // eSetPdoIdOverRange = -2001,
//         // eSetPdoValueOverRange = -2000,


//         eMoveEaMotorNumber = -1901,
//         // eSleepParam = -1801,

//         eJointJerkOverRange = -1505,
//         eJointDecOverRange,
//         eJointAccOverRange,
//         eJointVelOverRange,
//         eJointPosOverRange,

//         // eModeNotSupported = -1421,

//         eMoveArchParam = -1400,
//         eMoveArchTcpWOverRange,
//         eMoveArchTcpVOverRange,
//         // eMoveArchHmaxTooSmall,

//         eMoveCToolOrWobjDiffer = -1369,
//         // eMoveCPointsInLine,
//         eMoveCSpeedCloseToZero,
//         eMoveCZonePerOverRange,
//         eMoveCZoneDisOverRange,
//         eMoveCTcpWOverRange,
//         eMoveCTcpVOverRange,
//         eMoveCExtWOverRange,
//         eMoveCExtVOverRange,
//         // eMoveCParam,

//         eMoveLSpeedCloseToZero = -1349,
//         eMoveLZonePerOverRange,
//         eMoveLZoneDisOverRange,
//         // eMoveLTcpWOverRange,
//         // eMoveLTcpVOverRange,
//         // eMoveLExtWOverRange,
//         // eMoveLExtVOverRange,
//         // eMoveLParam,

//         eMoveJSpeedCloseToZero = -1329,
//         eMoveJZonePerOverRange,
//         eMoveJJPerOverRange,
//         eMoveJExtWOverRange,
//         eMoveJExtVOverRange,
//         // eMoveJParam,

//         eMoveAbsJSpeedCloseToZero = -1309,
//         eMoveAbsJZonePerOverRange,
//         eMoveAbsJJPerOverRange,
//         eMoveAbsJExtWOverRange,
//         eMoveAbsJExtVOverRange,
//         // eMoveAbsJParam,

//         eMoveLFindSpeedCloseToZero = -1289,
//         // eMoveLFindTcpWOverRange,
//         // eMoveLFindTcpVOverRange,
//         // eMoveLFindExtWOverRange,
//         // eMoveLFindExtVOverRange,
//         // eMoveLFindIdOverRange,
//         // eMoveLFindParam,

//         // eMoveJFindSpeedCloseToZero = -1269,
//         // eMoveJFindZonePerOverRange,
//         // eMoveJFindJPerOverRange,
//         // eMoveJFindExtWOverRange,
//         // eMoveJFindExtVOverRange,
//         // eMoveJFindIdOverRange,
//         // eMoveJFindParam,

//         eManualMoveLSpeedCloseToZero = -1249,
//         // eManualMoveLTcpWOverRange,
//         // eManualMoveLTcpVOverRange,
//         // eManualMoveLExtWOverRange,
//         // eManualMoveLExtVOverRange,
//         // eManualMoveLParam,

//         eManualMoveAbsJSpeedCloseToZero = -1229,
//         eManualMoveAbsJZonePerOverRange,
//         eManualMoveAbsJJPerOverRange,
//         eManualMoveAbsJExtWOverRange,
//         eManualMoveAbsJExtVOverRange,
//         // eManualMoveAbsJParam,

//         // eSetXmlFailed = -1122,
//         // eCanNotSetXml,

//         eJogCDimIdOverRange = -1115,
//         eJogCRunModeAtAxis,
//         eJogCRunModeAtErrorToolsOrWobjs,
//         eJogCDecSize,
//         eJogCAccSize,
//         eJogCVelSize,
//         eJogCIncCountOverRange,
//         eJogCTgIdOverRange,
//         eJogJTgIdOverRange,

//         // eJogJMotorIdOverRange = -1104,
//         eJogJRunModeNotAtAxis,
//         // eJogJIncCountOverRange,

//         eForwardKinematics = -1004,
//         eInverseKinematics,
//         eCloseToSingularPoints,
//         // eCommandOverTime,

//         eVelFollowing = -510,
//         eVelNotContinuous,
//         eVelExceedMaxValue,
//         eVelExceedMinValue,
//         ePosFollowing,
//         ePosSeondOrderNotContinuous,
//         ePosNotContinuous,
//         ePosExceedMaxValue,
//         ePosExceedMinValue,
//         eMotorsDisabled,

//         eMotorsLoseConnection = -105,
//         eMotorsSafeOP = -103,
//         eMotorsPrepOP,
//         eMotorsInit,

//         eNormal = 0

//     };

// 	class KAANH_API RobotError{
// 	public:
//         auto virtual setError(ErrorCode errorCode)->void;
//         auto virtual insertError(std::pair<ErrorCode, std::string> e)->void;
//         auto virtual setError(ErrorCode errorCode, aris::plan::Plan &plan)->void;
//         auto virtual setErrorAndRtLog(ErrorCode errorCode)->void;
//         auto virtual setErrorAndNotRunExecute(ErrorCode errorCode, aris::plan::Plan &plan) ->void;
//         auto virtual setErrorAndLogAndNotRunExecute(ErrorCode errorCode, aris::plan::Plan &plan)->void;
// 		auto virtual InitErrorConfig()->void;
//         auto virtual errorMap()->void;
// 		virtual ~RobotError() {};

// 		static RobotError& get_instance() {
// 			static RobotError instance;
// 			return instance;
// 		}
// 	private:
// 		explicit RobotError() {};
// 		RobotError(const RobotError &) = delete;
// 		RobotError& operator=(const RobotError &) = delete;
//         std::map<ErrorCode, std::string> ErrorMap;
// 	};
// }	//namespace kaanh::robot

// #endif // KAANH_ROBOT_ERROR_HPP_
