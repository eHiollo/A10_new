#ifndef KAANH_ROBOT_MOTOR_CONFIG_HPP_
#define KAANH_ROBOT_MOTOR_CONFIG_HPP_

#include <aris/control/control.hpp>
#include <kaanh/general/json.hpp>
#include "kaanh/general/macro.hpp"
#include "kaanh_lib_export.h"



namespace kaanh::robot {

class KAANH_API CustomWritePdo : public aris::core::CloneObject<CustomWritePdo, aris::plan::Plan>
{
public:
    auto virtual prepareNrt()->void override;
    auto virtual executeRT()->int override;
    auto virtual collectNrt()->void override;
    explicit CustomWritePdo(const std::string &name = "WritePdo_plan");
private:
    struct Imp;
    aris::core::ImpPtr<Imp> imp_;
    
};

class KAANH_API CustomReadPdo : public aris::core::CloneObject<CustomReadPdo, aris::plan::Plan>
{
public:
    auto virtual prepareNrt()->void override;
    auto virtual executeRT()->int override;
    auto virtual collectNrt()->void override;
    explicit CustomReadPdo(const std::string &name = "ReadPdo_plan");
private:
    struct Imp;
    aris::core::ImpPtr<Imp> imp_;
};

class KAANH_API DaHuanJaw : public aris::control::EthercatCustomSlave
{
public :
    auto virtual readPdo()->void override {};
    auto virtual writePdo()->void override {};
    virtual ~DaHuanJaw();
    DaHuanJaw();
    DaHuanJaw(const DaHuanJaw &other) = delete;
    DaHuanJaw(DaHuanJaw &&other) = delete;
    DaHuanJaw& operator=(const DaHuanJaw &other) = delete;
    DaHuanJaw& operator=(DaHuanJaw &&other) = delete;

private:
    struct Imp;
    aris::core::ImpPtr<Imp> imp_;
};

class KAANH_API KaanhEthercatCustomSlave : public aris::control::EthercatCustomSlave
{
public :
    auto virtual readPdo()->void override {};
    auto virtual writePdo()->void override {};
    virtual ~KaanhEthercatCustomSlave();
    KaanhEthercatCustomSlave();
    KAANH_DELETE_BIG_FOUR(KaanhEthercatCustomSlave)

private:
    struct Imp;
    aris::core::ImpPtr<Imp> imp_;
};


}

#endif//KAANH_ROBOT_MOTOR_CONFIG_HPP_
