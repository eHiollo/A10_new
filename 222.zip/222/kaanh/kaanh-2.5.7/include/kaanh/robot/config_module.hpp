#ifndef KAANH_ROBOT_CONFIG_MODULE_HPP_
#define KAANH_ROBOT_CONFIG_MODULE_HPP_

#include "kaanh/module/middle_module.hpp"

namespace kaanh::robot {

//100个电机
struct ActualVal{
    std::array<std::array<double,4>,100> val_;
    bool is_effective;
};

class KAANH_API ConfigModule:public kaanh::module::MiddleModule{
public:
    auto virtual init()->void override;

    auto virtual execute(const std::string &str, std::function<void(std::string)> send_ret) noexcept->std::pair<std::string, std::string> override;

private:
    struct Imp;
    std::unique_ptr<Imp> imp_;

public:
    ConfigModule();
    virtual ~ConfigModule();
    KAANH_DELETE_BIG_FOUR(ConfigModule)
};
}//KAANH_ROBOT_CONFIG_MODULE_HPP_



#endif//KAANH_ROBOT_CONFIG_MODULE_HPP_
