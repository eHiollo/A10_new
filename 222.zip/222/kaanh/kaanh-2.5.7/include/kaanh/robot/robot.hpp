#ifndef KAANH_ROBOT_ROBOT_HPP_
#define KAANH_ROBOT_ROBOT_HPP_

#include <functional>

#include "kaanh/general/json.hpp"
#include "kaanh/general/macro.hpp"
#include "aris/server/control_server.hpp"

namespace kaanh::robot {

enum class RobotStatus : std::int32_t {
    kHeStopped = -3,    //!< 硬急停
    KSeStopped,         //!< 软急停
    kError,             //!< 错误
    kNormal             //!< 正常运行
};

NLOHMANN_JSON_SERIALIZE_ENUM(RobotStatus, {
    {RobotStatus::kHeStopped, "HeStopped"},
    {RobotStatus::KSeStopped, "SeStopped"},
    {RobotStatus::kError, "Error"},
    {RobotStatus::kNormal, "Normal"}
})

enum class RobotOpMode : std::int32_t {
    kManual = 0x01,         //!< 手动模式
    kAuto = 0x02,           //!< 自动模式
    kExternalAuto = 0x04,   //!< 外部自动模式
    kDrag = 0x08            //!< 拖动模式
};

NLOHMANN_JSON_SERIALIZE_ENUM(RobotOpMode, {
    {RobotOpMode::kManual, "Manual"},
    {RobotOpMode::kAuto, "Auto"},
    {RobotOpMode::kExternalAuto, "ExternalAuto"},
    {RobotOpMode::kDrag, "Drag"}
})

enum class RobotActivate : std::int32_t {
    kDisabled = 0,          //!< 去使能
    kWaiting,               //!< 中间状态
    kEnabled                //!< 使能
};

NLOHMANN_JSON_SERIALIZE_ENUM(RobotActivate, {
    {RobotActivate::kDisabled, "Disabled"},
    {RobotActivate::kWaiting, "Waiting"},
    {RobotActivate::kEnabled, "Enabled"}
})

enum class RobotMotion : std::int32_t {     // 预留
    kStopped = 0,           //!< 停止状态
    kRunning                //!< 运动状态
};

NLOHMANN_JSON_SERIALIZE_ENUM(RobotMotion, {
    {RobotMotion::kStopped, "Stopped"},
    {RobotMotion::kRunning, "Running"}
})

enum class JogRunMode : std::int32_t {
    kContinuous = 0x01,  //!< 连续手动
    kStep                //!< 阶越手动
};

NLOHMANN_JSON_SERIALIZE_ENUM(JogRunMode, {
    {JogRunMode::kContinuous, "Continuous"},
    {JogRunMode::kStep, "Step"}
})

enum class JogCoordinate : std::int32_t {
    kAxis = 0x01,           //!< 轴空间
    kBase,                  //!< 法兰盘相对于足部
    kTool,                  //!< 选定工具相对于足部
    kWobj                   //!< 选定工具相对于选定工件
};

NLOHMANN_JSON_SERIALIZE_ENUM(JogCoordinate, {
    {JogCoordinate::kAxis, "Axis"},
    {JogCoordinate::kBase, "Base"},
    {JogCoordinate::kTool, "Tool"},
    {JogCoordinate::kWobj, "Wobj"}
})

class KAANH_API Robot : public aris::server::CustomModule {
public:
    enum class GetType : int {
        kInfo = 1,
        kConfig,
        kDebug
    };

public:
    Robot();
    virtual ~Robot();

private:
    struct Imp;
	std::unique_ptr<Imp> imp_;

public:
    auto robotStatus() const->RobotStatus;
    auto setRobotStatus(RobotStatus status)->void;
    auto robotOpMode() const->RobotOpMode;
    auto setRobotOpMode(RobotOpMode op_mode)->void;
    auto robotActivate() const->RobotActivate;
    auto setRobotActivate(RobotActivate activate)->void;
    auto robotMotion() const->RobotMotion;
    auto setRobotMotion(RobotMotion motion)->void;
    auto vel() const->std::uint8_t;
    auto setVel(std::uint8_t vel)->void;
    auto pgmVel() const->std::uint8_t;
    auto setPgmVel(std::uint8_t vel)->void;
    auto choosenTool() const->std::vector<aris::Size>;
    auto setChoosenTool(std::vector<aris::Size> tool)->void;
    auto choosenWobj() const->std::vector<aris::Size>;
    auto setChoosenWobj(std::vector<aris::Size> wobj)->void;
    auto jogRunMode() const->JogRunMode;
    auto setJogRunMode(JogRunMode run_mode)->void;
    auto jogStep() const->std::pair<double, double>;
    auto setJogStep(std::pair<double, double> jog_step)->void;
    auto jogCoordinate() const->JogCoordinate;
    auto setJogCoordinate(JogCoordinate coor_)->void;

    /**
     * @brief: 注册Update中执行的函数
     * @param {int} priority 优先级
     * @param {std::function<void(aris::server::ControlServer&)>} cbk 回调函数
     * @remark 优先级支持0～10, 最高优先级为10, 优先级越高, 越先执行, 同优先级按注册顺序执行 
     */  
    auto registerUpdateFunc(std::function<void(aris::server::ControlServer&)> cbk, int priority = 5)->void;
    auto rtUpdate(aris::server::ControlServer &cs)->void;

    auto registerGetFunc(std::function<nlohmann::json(aris::server::ControlServer&)> cbk, const std::string &key, GetType type)->void;
    auto getJson(GetType type) const->nlohmann::json;

    static auto instanceInCs()->Robot&;
};

}   // namespace kaanh::robot

#endif // KAANH_ROBOT_ROBOT_HPP_

