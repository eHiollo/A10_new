#ifndef KAANH_ROBOT_MOTOR_CONFIG_HPP_
#define KAANH_ROBOT_MOTOR_CONFIG_HPP_

#include <aris/control/control.hpp>
#include <kaanh/general/json.hpp>
#include "kaanh/general/macro.hpp"
#include "kaanh_lib_export.h"



namespace kaanh::robot {
struct DriverSDO{
    std::string name_;
    std::string chinese_description_;
    std::uint16_t index_;
    std::uint32_t min_val_;
    std::uint32_t max_val_;
    std::uint16_t subindex_;
    bool restart_enable_;
    bool is_float_data;
    DriverSDO(){};
    DriverSDO(std::string name,std::string chinese_description,std::uint16_t index,std::uint32_t min_val,std::uint32_t max_val,std::uint16_t subindex=0x00,bool restart_enable=false):
        name_(name),chinese_description_(chinese_description),index_(index),min_val_(min_val),max_val_(max_val),subindex_(subindex),restart_enable_(restart_enable){}
    NLOHMANN_DEFINE_TYPE_INTRUSIVE(DriverSDO,name_,chinese_description_,index_,min_val_,max_val_,subindex_,restart_enable_)

};


struct MotorConfigPar{
    double max_pos;
    double min_pos;
    double max_vel;
    double min_vel;
    double max_acc;
    double min_acc;
    double max_pos_following_error;
    double max_vel_following_error;   //单位系数--直线轴:1000.0;旋转轴:57.295779513------
    double feed_constant = 360.0;           //当量比(机械结构行程/减速机输出端转1圈)--直线轴:导程mm/1圈;旋转轴:360度/1圈
    double gear_ratio = 1.0;                //减速比
    int resolution = 131072;                //电机分辨率
    int direction = 1;                      //1：电机顺时针方向；-1：电机逆时针方向------
    std::string motion_type = "rotatory"; //驱动类型--旋转轴 rotatory:1 直线轴 linear：2--
    std::string mode = "";
    std::uint16_t slave_id = -1;
    auto check() const->void {
        double unit_factor{1.0};
        if(motion_type=="rotatory"){
            unit_factor = 180.0/aris::PI;
        }else if(motion_type=="linear") {
            unit_factor=1000;
        }else {
            LOCALE_THROW("motion_type must be rotatory or linear", "电机驱动类型错误，必须为旋转轴或直线轴");
        }
        if (max_pos <= min_pos) LOCALE_THROW("max_pos must be bigger than min pos", "电机位置上限必须大于电机位置下限");
        if (max_vel <= min_vel) LOCALE_THROW("max_vel must be bigger than min vel", "电机速度上限必须大于电机速度下限");
        if (max_acc <= min_acc) LOCALE_THROW("max_acc must be bigger than min acc", "电机加速度上限必须大于电机加速度下限");
        if (max_pos_following_error <= 0) LOCALE_THROW("max_pos_following_error must be positive", "电机位置跟随误差上限必须为正数");
        if (max_vel_following_error <= 0) LOCALE_THROW("max_vel_following_error must be positive", "电机速度跟随误差上限必须为正数");
        if (unit_factor <= 0) LOCALE_THROW("unit_factor must be positive", "电机单位系数必须为正数");
        if (feed_constant <= 0) LOCALE_THROW("feed_constant must be positive", "电机当量比必须为正数");
        if (gear_ratio <= 0) LOCALE_THROW("gear_ratio must be positive", "电机减速比必须大于0");
        if (resolution <= 0) LOCALE_THROW("resolution must be positive", "电机分辨率必须为正数");
        if ((direction != 1)&&(direction != -1)) LOCALE_THROW("direction must be 1 or -1", "电机旋转方向必须为1或-1");
        if ((motion_type=="rotatory")&&(std::abs(unit_factor- 180.0/aris::PI)>1e-3))LOCALE_THROW("rotatory axis's unit_factor must close to 57.295779513", "旋转轴单位系数必须为57.295779513");
        if ((motion_type=="linear")&&(std::abs(unit_factor-1000.0)>1e-6))LOCALE_THROW("linear axis's unit_factor must close to 1000.0", "直线轴单位系数必须为1000");
    }
    auto toMotor( aris::control::Motor *m)const->void{
        double unit_factor{1.0};
        if(motion_type=="rotatory"){
            unit_factor = 180.0/aris::PI;
        }else if(motion_type=="linear") {
            unit_factor=1000;
        }else {
            LOCALE_THROW("motion_type must be rotatory or linear", "电机驱动类型错误，必须为旋转轴或直线轴");
        }
        double pos_factor{0.0};
        pos_factor = direction*resolution*gear_ratio/feed_constant*unit_factor;
        m->setPosFactor(pos_factor);
        m->setMaxPos(max_pos/unit_factor);
        m->setMinPos(min_pos/unit_factor);
        m->setMaxVel(max_vel/unit_factor);
        m->setMinVel(min_vel/unit_factor);
        m->setMaxAcc(max_acc/unit_factor);
        m->setMinAcc(min_acc/unit_factor);
        m->setMaxPosFollowingError(max_pos_following_error/unit_factor);
        m->setMaxVelFollowingError(max_vel_following_error/unit_factor);
    }

    NLOHMANN_DEFINE_TYPE_INTRUSIVE(MotorConfigPar, max_pos, min_pos, max_vel, min_vel, max_acc, min_acc, max_pos_following_error, max_vel_following_error, feed_constant, gear_ratio, resolution, direction, motion_type,mode,slave_id)
};


class KAANH_API  MotorConfig:public aris::control::EthercatMotor{

public:
    //map<string,tuple>  名称（可以中英切换）：单位/值
    auto readMotor()const->MotorConfigPar;
    //传入MotorConfigPar
    auto writeMotor(const MotorConfigPar& motor_config_par )->void;

    auto setFeedConstant(double feed_constant)->void;
    auto getFeedConstant()const->double;

    auto setGearRatio(double gear_ratio)->void;
    auto getGearRatio()const->double;

    auto setResolution(int resolution)->void;
    auto getResolution()const ->int;

    auto setDirection(int direction)->void;
    auto getDirection()const ->int;

    auto setMotionType(std::string motion_type)->void;
    auto getMotionType()const->std::string;
private:
    struct Imp;
    aris::core::ImpPtr<Imp>imp_;
public:
    virtual ~MotorConfig();
    MotorConfig(aris::control::EthercatSlave* slave = nullptr
        , double max_pos = 1.0, double min_pos = -1.0, double max_vel = 1.0, double min_vel = -1.0, double max_acc = 1.0, double min_acc = -1.0
        , double max_pos_following_error = 1.0, double max_vel_following_error = 1.0, double pos_factor = 1.0, double pos_offset = 0.0, double home_pos = 0.0
        , double unit_factor=180.0/aris::PI, double feed_constant=360.0, double gear_ratio=1.0, int resolution=131072, int direction=1, int motion_type=1);
    MotorConfig(const MotorConfig &other) = delete;
    MotorConfig(EthercatMotor &&other) = delete;
    MotorConfig& operator=(const MotorConfig &other) = delete;
    MotorConfig& operator=(MotorConfig &&other) = delete;
};

}

#endif//KAANH_ROBOT_MOTOR_CONFIG_HPP_
