#ifndef KAANH_MIDDLEWARE_SHELL_HPP_
#define KAANH_MIDDLEWARE_SHELL_HPP_

#include "kaanh/module/middle_module.hpp"

#include "kaanh_lib_export.h"
#include "aris.hpp"

namespace kaanh::middleware {

class KAANH_API Shell : public aris::server::MiddleWare {
public:
    using aris::server::MiddleWare::executeCmd;
    
public:
    auto virtual init()->void override;
    auto virtual executeCmd(std::string_view str, std::function<void(std::string)> send_ret, aris::server::Interface *interface_)->int override;
    auto modulePool()->aris::core::PointerArray<kaanh::module::MiddleModule>& { return *module_pool_; }
    auto modulePool() const->const aris::core::PointerArray<kaanh::module::MiddleModule>& { return const_cast<Shell *>(this)->modulePool(); }
    auto setModulePool(aris::core::PointerArray<kaanh::module::MiddleModule> *module_pool)->void;
    auto getModule(const std::string &name)->kaanh::module::MiddleModule&;
    auto getModule(const std::string &name) const->const kaanh::module::MiddleModule& { return const_cast<Shell *>(this)->getModule(name); }
    auto getCaller() const->aris::server::Interface* { return caller_; }
    auto noPrints() const->std::string;
    auto resetNoPrints(const std::string &white_list)->void;

    static auto instanceInCs()->Shell& { return *(dynamic_cast<Shell*>(&aris::server::ControlServer::instance().middleWare())); }

private:
    std::unique_ptr<aris::core::PointerArray<kaanh::module::MiddleModule>> module_pool_;
    std::map<std::string, int> name_idx_;
    aris::server::Interface *caller_{nullptr};
    std::set<std::string> no_prints_;

public:
    Shell() : module_pool_(new aris::core::PointerArray<kaanh::module::MiddleModule>) {};
    virtual ~Shell() = default;

    ARIS_DELETE_BIG_FOUR(Shell);
};

}   // namespace kaanh::middleware

#endif // KAANH_MIDDLEWARE_SHELL_HPP_