#ifndef KAANH_PROTOCOL_FILESOCKET_HPP_
#define KAANH_PROTOCOL_FILESOCKET_HPP_

#include "aris.hpp"
#include "aris/core/version.hpp"


namespace kaanh::protocol {
#define FILESIZE 8192
class FileSocket{
public:
    struct Filemsg{
        uint32_t datesize{0};//此次传输文件数据大小
        uint32_t counts{0};//此次count
        uint32_t totalcounts{0};//总传输counts
        char filename[256];
        char filedata[FILESIZE];//文件数据
    };
    FileSocket();
    ~FileSocket();
    auto sendFile(const std::string &filename,const std::string &filename2)->bool;
    
    auto connect(const std::string& remote_ip,const std::string& port)->void;
	auto reconnect()->void;
    auto isconnected()->bool;
    auto startserver(const std::string& port)->void;
    auto getfilenums()->uint32_t;
    auto findfs(const std::string& filename)->bool;
    auto addfs(const std::string& filename)->void;
    auto getfs(const std::string& filename)->std::ofstream*;
    auto delfs(const std::string& filename)->void;

    static auto GetInstance()->FileSocket*;
private:
    static auto OnReceivedMsg(aris::core::Socket* socket_, aris::core::Msg & msg_)->int;
    static auto OnLoseConnection(aris::core::Socket* socket_)->int;
private:
	struct Imp;
	std::unique_ptr<Imp> imp_;

};
static FileSocket* filesocket = new (std::nothrow) FileSocket();
auto FileSocket::GetInstance()->FileSocket*{
    return filesocket;
}

}// namespace kaanh::protocol

#endif  // KAANH_PROTOCOL_FILESOCKET_HPP_