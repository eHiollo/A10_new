#ifndef KAANH_PROTOCOL_MODBUS_TCP_CLIENT_HPP_
#define KAANH_PROTOCOL_MODBUS_TCP_CLIENT_HPP_

#include <vector>
#include <memory>

#include "kaanh/general/macro.hpp"
#include "kaanh_lib_export.h"

namespace kaanh::protocol {

class KAANH_API ModbusTcpClient {
public:
    auto connect(const std::string &ip, int port)->void;
    auto isConnected()->bool;
    auto setSlave(int slave)->void;
    auto readBits(int addr, int nb = 1)->std::vector<bool>;
    auto readInputBits(int addr, int nb = 1)->std::vector<bool>;
    auto readRegisters(int addr, int nb = 1)->std::vector<uint16_t>;
    auto readInputRegisters(int addr, int nb = 1)->std::vector<uint16_t>;
    auto writeBit(int addr, bool status)->void;
    auto writeBits(int addr, const std::vector<bool> &status)->void;
    auto writeRegister(int addr, uint16_t val)->void;
    auto writeRegisters(int addr, const std::vector<uint16_t> &vals)->void;
    auto close()->void;

public:
    struct Imp;
    std::unique_ptr<Imp> imp_;

public:
    ModbusTcpClient();
    ~ModbusTcpClient();
    KAANH_DELETE_BIG_FOUR(ModbusTcpClient)
};

}   // namespace kaanh::protocol

#endif  // KAANH_PROTOCOL_MODBUS_TCP_CLIENT_HPP_

