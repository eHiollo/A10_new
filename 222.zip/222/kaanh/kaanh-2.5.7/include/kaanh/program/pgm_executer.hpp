#ifndef KAANH_PROGRAM_PGM_EXECUTER_HPP_
#define KAANH_PROGRAM_PGM_EXECUTER_HPP_

#include <string_view>
#include <utility>
#include <functional>
#include <map>

#include "kaanh_lib_export.h"
#include "kaanh/program/pgm_calculator.hpp"
#include "kaanh/program/pgm_translator.hpp"
#include "kaanh/general/macro.hpp"
#include "kaanh/general/json.hpp"

#include "aris/core/object.hpp"

namespace kaanh::program {

enum class KAANH_API StatementType : int {
    kEmpty = -1,
    kComment,
    kMain,
    kEndMain,
    kFunction,
    kEndFunction,
    kReturn,
    kCall,
    kIf,
    kElif,
    kElse,
    kEndIf,
    kSwitch,
    kCase,
    kDefault,
    kEndSwitch,
    kWhile,
    kEndWhile,
    kLoop,
    kEndLoop,
    kContinue,
    kBreak,
    kLabel,
    kGoto,
    kPlan,
    kExpr
};

NLOHMANN_JSON_SERIALIZE_ENUM(StatementType, {
    {StatementType::kEmpty, "Empty"},
    {StatementType::kComment, "Comment"},
    {StatementType::kMain, "Main"},
    {StatementType::kEndMain, "EndMain"},
    {StatementType::kFunction, "Function"},
    {StatementType::kEndFunction, "EndFunction"},
    {StatementType::kReturn, "Return"},
    {StatementType::kCall, "Call"},
    {StatementType::kIf, "If"},
    {StatementType::kElif, "Elif"},
    {StatementType::kElse, "Else"},
    {StatementType::kEndIf, "EndIf"},
    {StatementType::kSwitch, "Switch"},
    {StatementType::kCase, "Case"},
    {StatementType::kDefault, "Default"},
    {StatementType::kEndSwitch, "EndSwitch"},
    {StatementType::kWhile, "While"},
    {StatementType::kEndWhile, "EndWhile"},
    {StatementType::kLoop, "Loop"},
    {StatementType::kEndLoop, "EndLoop"},
    {StatementType::kContinue, "Continue"},
    {StatementType::kBreak, "Break"},
    {StatementType::kLabel, "Label"},
    {StatementType::kGoto, "Goto"},
    {StatementType::kPlan, "Plan"},
    {StatementType::kExpr, "Expr"},
})

using StatementParseFunc = std::function<std::pair<bool, std::any>(std::string_view)>;

//! 语句节点
class KAANH_API StatementNode {
public:
    //! 获取语句字符串
    auto statement() const noexcept->const std::string&;

    //! 获取语句类型
    auto type() const noexcept->StatementType;

    //! 获取语句上下文
    auto context() noexcept->std::any&;
    auto context() const noexcept->const std::any& { return const_cast<StatementNode*>(this)->context(); }

    /**
     * @brief: 重置语句节点
     * @param {std::string_view} statement 语句字符串
     * @param {const std::vector<std::weak_ptr<StatementNode>>&} last_nodes 语句节点前节点列表
     * @param {const std::vector<std::weak_ptr<StatementNode>>&} next_nodes 语句节点后节点列表
     * @remark 如重置不成功则抛异常，节点保持不变
     */    
    auto reset(std::string_view statement,
               const std::vector<std::weak_ptr<StatementNode>> &last_nodes = {},
               const std::vector<std::weak_ptr<StatementNode>> &next_nodes = {})->void;

    //! 获取前节点列表
    auto lastNodes() noexcept->std::vector<std::weak_ptr<StatementNode>>&;
    auto lastNodes() const noexcept->const std::vector<std::weak_ptr<StatementNode>>& { return const_cast<StatementNode*>(this)->lastNodes(); }
    
    /**
     * @brief: 重置前节点列表
     * @param {std::vector<std::weak_ptr<StatementNode>>&} last_nodes 前节点列表
     * @remark last_nodes中的每个元素必须是有效的节点指针
     */    
    auto resetLastNodes(const std::vector<std::weak_ptr<StatementNode>> &last_nodes = {})->void;
 
    //! 获取后节点列表
    auto nextNodes() noexcept->std::vector<std::weak_ptr<StatementNode>>&;
    auto nextNodes() const noexcept->const std::vector<std::weak_ptr<StatementNode>>& { return const_cast<StatementNode*>(this)->nextNodes(); }
    
    /**
     * @brief: 重置后节点列表
     * @param {const std::vector<std::weak_ptr<StatementNode>>&} next_nodes 后节点列表
     * @remark next_nodes中的每个元素必须是有效的节点指针
     */    
    auto resetNextNodes(const std::vector<std::weak_ptr<StatementNode>> &next_nodes = {})->void;

    /**
     * @brief: 方便函数，获取后真节点
     * @return 后真节点
     * @pre 节点的后节点列表大小大于等于1，小于等于2
     */    
    auto nextNodeTrue()->std::weak_ptr<StatementNode>&;
    auto nextNodeTrue() const->const std::weak_ptr<StatementNode>& { return const_cast<StatementNode*>(this)->nextNodeTrue(); }
    
    /**
     * @brief: 方便函数，重置后真节点
     * @param {const std::weak_ptr<StatementNode>&} node 后真节点
     * @remark 1. node必须是有效的节点指针
     * <BR>2. 当前的后节点列表大小必须小于等于2
     * <BR>3. 如当前后节点列表等于0，则将node添加到后节点列表，否则执行替换
     */    
    auto resetNextNodeTrue(const std::weak_ptr<StatementNode> &node)->void;
    
    /**
     * @brief: 方便函数，获取后假节点
     * @return 后假节点
     * @pre 节点的后节点列表大小等于2
     */    
    auto nextNodeFalse()->std::weak_ptr<StatementNode>&;
    auto nextNodeFalse() const->const std::weak_ptr<StatementNode>& { return const_cast<StatementNode*>(this)->nextNodeFalse(); }
    
    /**
     * @brief: 方便函数，重置后假节点
     * @param {const std::weak_ptr<StatementNode>&} node 后假节点
     * @remark 1. node必须是有效的节点指针
     * <BR>2. 当前的后节点列表大小必须大于等于1，小于等于2
     * <BR>3. 如当前后节点列表等于1，则将node添加到后节点列表，否则执行替换
     */   
    auto resetNextNodeFalse(const std::weak_ptr<StatementNode> &node)->void;

    /**
     * @brief: 备份节点
     * @remark 会备份当前节点的语句、类型、上下文及连接属性
     */    
    auto backup() noexcept->void;

    /**
     * @brief: 恢复节点
     * @remark 如未曾备份过节点, 则函数行为未定义
     */
    auto recover() noexcept->void;

    /**
     * @brief: 按语句类型注册解析规则
     * @param {StatementType} type 语句类型
     * @param {const StatementParseFunc&} rule 语句解析规则
     * @remark 1. 如规则为空, 则忽略
     * <BR>2. 如规则已存在，则替换
     */    
    static auto registerRule(StatementType type, const StatementParseFunc &rule) noexcept->void;

    /**
     * @brief: 根据语句类型获取对应的解析规则
     * @param {StatementType} type 语句类型
     * @return {StatementParseFunc} 解析函数对象
     * @remark 如规则不存在，返回空
     */    
    static auto getRule(StatementType type) noexcept->StatementParseFunc;

    //! 获取解析规则表
    static auto rules() noexcept->const std::map<StatementType, StatementParseFunc>&;

    //! 重置解析规则表
    static auto resetRules(const std::map<StatementType, StatementParseFunc> &rules= {}) noexcept->void;

private:
    struct Imp;
    aris::core::ImpPtr<Imp> imp_;

public:
    explicit StatementNode(std::string_view statement,
                  const std::vector<std::weak_ptr<StatementNode>> &last_nodes = {},
                  const std::vector<std::weak_ptr<StatementNode>> &next_nodes = {});
    virtual ~StatementNode();

    KAANH_DECLARE_BIG_FOUR(StatementNode)
};

//! 工程元信息
struct KAANH_API ProjectContent {
    std::string name_;              //!< 工程名称
    std::string data_content_;      //!< 工程变量定义文本
    std::map<std::string, std::pair<std::string, std::string>> contents_;   //!< 程序文本<程序名称, <变量定义文本, 源代码文本>>
};

//! plan上下文
struct KAANH_API PlanContext {
    PgmTranslator::TransResCell trans_cell_;    //!< plan翻译后的元信息
    PlanCell plan_cell_;                        //!< plan元信息
};

class DataPkg {
public:
    auto space() const->std::shared_ptr<const NameSpace>;
    auto iniVals() const->const std::map<std::string, RValue>&;
    auto content() const->std::string;

    auto addVar(const std::string &name, const std::string &val)->void;
    auto addVar(const std::string &name, const RValue &val)->void;
    auto updateVarInMem(const std::string &name, const std::string &val)->void;
    auto updateVarInMem(const std::string &name, const RValue &val)->void;
    auto updateVar(const std::string &name, const std::string &val)->void;
    auto updateVar(const std::string &name, const RValue &val)->void;
    auto deleteVar(const std::string &name)->void;
    auto renameVar(const std::string &old_name, const std::string &new_name)->void;
    auto resetVars()->void;

    static auto isKeyword(const std::string &word) noexcept->bool;

private:
    auto genDefStr(const std::string &name, const RValue &val)->std::string;

private:
    std::shared_ptr<NameSpace> space_;          // 作用域
    std::map<std::string, RValue> ini_vals_;    // 初值表
    std::map<std::string, std::string> content_;// 定义文本

    static std::set<std::string> keywords_;     // 关键字集合

public:
    // content每个变量的定义中, 值必须是字面量(不能包含变量)
    DataPkg(const std::string &space_name, const std::string &content);
};

class KAANH_API PgmExecuter {
public:
    auto init(PgmCalculator *calculator, std::shared_ptr<DataPkg> gdatas)->void;

    /**
     * @brief: 编译工程, 校验合法性
     * @param {const ProjectContent} &prj 工程元信息
     * @remark 校验失败则抛异常
     */    
    auto check(const ProjectContent &prj)->void;

    /**
     * @brief: 编译并加载工程或程序
     * @param {const ProjectContent} &prj 工程元信息
     * @param {const std::string} &pgm 程序名称, 默认为空, 加载工程
     */    
    auto load(const ProjectContent &prj, const std::string &pgm = "")->void;

    /**
     * @brief: 卸载工程
     * @remark 如当前无加载工程, 则什么都不做
     */    
    auto unload() noexcept->void;

    /**
     * @brief: 获取是否处于加载状态
     */
    auto isLoaded() const noexcept->bool;

    /**
     * @brief: 获取加载工程名称
     * @return {std::pair<std::string, std::string>} <工程名称, 程序名称>
     * @remark 1. 如当前处于未加载状态, 则返回空
     * <BR>2. 如工程名称不为空, 程序名称为空, 则加载的是工程
     */    
    auto loadedInfo() const noexcept->const std::pair<std::string, std::string>&;

    /**
     * @brief: 判断当前是否已达程序末尾
     * @retval true 已达程序末尾
     * @retval false 未达程序末尾
     * @remark 1. 如到达END_MAIN, 则返回true
     * <BR>2. 如到达END_FUNCTION, 如同时函数栈为空, 则返回true, 否则返回false
     * @pre 当前处于加载状态
     */    
    auto isEnd() const noexcept->bool;

    /**
     * @brief: 判断是否可以下一步
     * @pre 当前处于加载状态
     */    
    auto canForward() const noexcept->bool;

    /**
     * @brief: 当前程序前进一步
     * @note 如当前的语句为Plan, 则仅前进, 不计算
     * @remark 1. 会跳过空行和注释
     * <BR>2. 如当前已达程序末尾, 则抛异常
     * @pre 当前处于加载状态
     */    
    auto arpForward()->void;

    /**
     * @brief: 判断是否可以上一步
     * @pre 当前处于加载状态
     */    
    auto canBackward() const noexcept->bool;

    /**
     * @brief: 当前程序后退一步
     * @remark 1. 会跳过空行和注释
     * <BR>2. 当且仅当当前语句和上一条语句均可后退时, 才可以执行后退
     * <BR>3. 如不满足后退条件时, 则抛异常
     * @pre 当前处于加载状态
     */
    auto backward()->void;

    /**
     * @brief: 重置当前工程
     * @note 1. 如加载的是工程, 则退回到MAIN, 如加载的是程序, 则退回到第一个非空或非注释的行
     * <BR>2. 变量恢复到初始值, 清空函数栈
     * @pre 当前处于加载状态
     */    
    auto reset()->void;

    /**
     * @brief: PC切换到对应的程序, 对应的行号
     * @param {const std::string} &pgm_name 程序名称
     * @param {int} line 行号
     * @remark 1. 如当前切换跳出了LOOP分支, 则清空LOOP栈
     * <BR>2. 如当前切换跳出了函数, 则清空函数栈
     * <BR>3. 如非法切换(空行或者注释行), 则抛异常
     * @pre 当前处于加载状态
     */    
    auto setPc(const std::string &pgm_name, int line)->void;

    /**
     * @brief: 获取PC指向的语句节点
     * @return {StatementNode&} 语句节点
     * @pre 当前处于加载状态
     */    
    auto curStatementNode() noexcept->StatementNode&;
    auto curStatementNode() const noexcept->const StatementNode& { return const_cast<PgmExecuter*>(this)->curStatementNode(); }
    
    /**
     * @brief: 获取当前PC所指向的文件和行号
     * @return {std::pair<std::string, int>} <程序名, 行号>, 如处于未加载状态, 则返回<"", 0>
     */    
    auto pc() const noexcept->std::pair<std::string, int>;

    /**
     * @brief: 添加变量
     * @param {const std::string&} space 命名空间名称("":机器人命名空间 "工程名称":工程命名空间 "程序":程序命名空间)
     * @param {const std::string&} name 变量名称
     * @param {const std::string&} val 变量值
     */    
    auto addVar(const std::string &space, const std::string &name, const std::string &val)->void;

    /**
     * @brief: 更新内存中的变量
     * @param {const std::string&} space 命名空间名称("":机器人命名空间 "工程名称":工程命名空间 "程序":程序命名空间)
     * @param {const std::string&} name 变量名称
     * @param {const std::string&} val 变量值
     */
    auto updateVarInMem(const std::string &space, const std::string &name, const std::string &val)->void;

    /**
     * @brief: 更新变量的初值和内存中的值
     * @param {const std::string&} space 命名空间名称("":机器人命名空间 "工程名称":工程命名空间 "程序":程序命名空间)
     * @param {const std::string&} name 变量名称
     * @param {const std::string&} val 变量值
     */
    auto updateVar(const std::string &space, const std::string &name, const std::string &val)->void;

    /**
     * @brief: 删除变量
     * @param {const std::string&} space 命名空间名称("":机器人命名空间 "工程名称":工程命名空间 "程序":程序命名空间)
     * @param {const std::string&} name 变量名称
     * @remark 会检查预删除的变量在工程中是否用到, 如已使用, 则抛异常
     */
    auto deleteVar(const std::string &space, const std::string &name)->void;

    /**
     * @brief: 重命名变量
     * @param {const std::string&} space 命名空间名称("":机器人命名空间 "工程名称":工程命名空间 "程序":程序命名空间)
     * @param {const std::string&} old_name 变量旧名称
     * @param {const std::string&} new_name 变量新名称
     * @remark 会同步更新代码中的变量名称
     */    
    auto renameVar(const std::string &space, const std::string &old_name, const std::string &new_name)->void;

    /**
     * @brief: 获取变量
     * @param {const std::string&} space 命名空间名称("":机器人命名空间 "工程名称":工程命名空间 "程序":程序命名空间)
     * @param {const std::string&} name 变量名称
     * @return {Var&} 变量的引用
     */    
    auto getVar(const std::string &space, const std::string &name)->Var&;
    auto getVar(const std::string &space, const std::string &name) const->const Var& { return const_cast<PgmExecuter*>(this)->getVar(space, name); }
    
    /**
     * @brief: 获取在代码中第一个检测到变量的程序和行号
     * @param {const std::string&} space 命名空间名称("":机器人命名空间 "工程名称":工程命名空间 "程序":程序命名空间)
     * @param {const std::string&} name 变量名称
     * @return {std::pair<std::string, int>} <程序名称, 行号> 如处于未加载状态或未查找到, 则返回<"", 0>
     */    
    auto varUsed(const std::string &space, const std::string &name) const->std::pair<std::string, int>;

    /**
     * @brief: 插入语句块
     * @param {const std::string &} pgm_name 程序名称
     * @param {int} before_line 插入行, 如大于已有行数, 则默认在程序末尾插入
     * @param {const std::string &} content 语句块
     * @remark 如失败, 可安全回退
     * @pre 当前处于加载状态
     */    
    auto insertStmts(const std::string &pgm_name, int before_line, const std::string &content)->void;

    /**
     * @brief: 删除语句块
     * @param {const std::string &} pgm_name 程序名称
     * @param {int} start_line 开始行
     * @param {int} end_line 结束行, 如大于已有行数, 则默认删除到末尾
     * @remark 如失败, 可安全回退
     * @pre 当前处于加载状态
     */    
    auto removeStmts(const std::string &pgm_name, int start_line, int end_line)->void;

    /**
     * @brief: 更新语句
     * @param {const std::string &} pgm_name 程序名称
     * @param {int} line 待更新行号
     * @param {const std::string &} content 语句
     * @remark 如失败, 可安全回退
     * @pre 当前处于加载状态
     */    
    auto updateStmt(const std::string &pgm_name, int line, const std::string &content)->void;

    /**
     * @brief: 注释语句块
     * @param {const std::string &} pgm_name 程序名称
     * @param {int} start_line 语句块开始行号
     * @param {int} end_line 语句块结束行号, 如大于已有行数, 则默认注释到末尾
     * @remark 如失败, 可安全回退
     * @pre 当前处于加载状态
     */    
    auto commentStmts(const std::string &pgm_name, int start_line, int end_line)->void;

    /**
     * @brief: 取消注释语句块
     * @param {const std::string &} pgm_name 程序名称
     * @param {int} start_line 语句块开始行号
     * @param {int} end_line 语句块结束行号, 如大于已有行数, 则默认取消注释到末尾
     * @remark 如失败, 可安全回退
     * @pre 当前处于加载状态
     */    
    auto uncommentStmts(const std::string &pgm_name, int start_line, int end_line)->void;

    //! 获取命名空间变量定义文本
    auto getDataContent(const std::string &space) const->std::string;

    //! 获取程序代码文本, 必须处于加载状态
    auto getStmtContent(const std::string &pgm_name) const->std::string;

    /**
     * @brief: 获取当前变量的初始值表
     * @return <命名空间名称, <变量名称, <变量类型名称, 变量值简单字符串>>>
     */    
    auto getCurInitVars() const->std::vector<std::pair<std::string, std::map<std::string, std::pair<std::string, std::string>>>>;
    
    /**
     * @brief: 获取当前语句列表
     * @return <程序名称, <语句类型, 语句字符串>列表>
     */    
    auto getCurStatements() const->std::map<std::string, std::vector<std::pair<StatementType, std::string>>>;

    /**
     * @brief: 获取语句列表
     * @return <语句类型, 语句字符串>
     */    
    auto getStatements(const std::string &pgm_name) const->std::vector<std::pair<StatementType, std::string>>;

    /**
     * @brief: 获取函数内可goto的Labels
     * @return Label列表
     */
    auto canGoto(const std::string &pgm_name, int line) const->std::vector<std::string>;

    /**
     * @brief: 获取函数内可call的函数
     * @return <程序名称, 函数列表>
     */
    auto canCall(const std::string &pgm_name, int line) const->std::map<std::string, std::vector<std::string>>;

    /**
     * @brief: 获取当前函数栈
     * @return <程序名称, 程序行号>
     * @remark 仅限开发人员调试使用
     */
    auto funcStack() const->std::vector<std::pair<std::string, int>>;

    /**
     * @brief: 获取当前loop栈
     * @return <当前次数>
     * @remark 仅限开发人员调试使用
     */
    auto loopStack() const->std::vector<int>;

    static auto instanceInCs()->PgmExecuter&;

    /**
     * @brief: 获取LOOP是否需要为了连续规划而展开
     * @return <展开次数, 连续规划的节点>
     * @remark 针对LOOP展开连续规划需求定制
     */
    auto loopSpread()->std::pair<int, std::vector<std::weak_ptr<StatementNode>>>;

    auto registerExecCbk(StatementType st, std::function<bool(const StatementNode &)> cbk)->void;

    auto isAllowAr() const->bool;

    auto allowAr()->void;

    auto stopAr()->void;

    auto stopArAndSyncArpToMrp()->void;

    auto arSize() const->std::uint64_t;

    auto arpIndex() const->std::uint64_t;

    auto mrpIndex() const->std::uint64_t;

    auto arQueue() const->std::vector<std::weak_ptr<StatementNode>>;

    auto arSizeAndQueueTop() const->std::pair<int, StatementNode>;

    auto moveMrpToArp()->void;

private:
    struct Imp;
    std::unique_ptr<Imp> imp_;

public:
    PgmExecuter();
    virtual ~PgmExecuter();
    KAANH_DELETE_BIG_FOUR(PgmExecuter)
};

}   // namespace kaanh::program

#endif // KAANH_PROGRAM_PGM_EXECUTER_HPP_