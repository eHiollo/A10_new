#ifndef KAANH_PROGRAM_PGM_TRANSLATOR_HPP_
#define KAANH_PROGRAM_PGM_TRANSLATOR_HPP_

#include <string>
#include <vector>
#include <map>
#include <memory>
#include <string_view>

#include "kaanh/program/pgm_config.hpp"
#include "kaanh_lib_export.h"
#include "aris.hpp"

namespace kaanh::program {

class KAANH_API PgmTranslator {
public:
    struct TransResCell {
        bool is_old_;
        std::string plan_;
        std::string name_;
        std::map<std::string, std::string> params_;
    };

public:
    virtual auto translateFrom(const std::string &new_plan) const->TransResCell;
    virtual auto translateTo(const std::string &old_plan) const->TransResCell;
    virtual auto toOldFormat(const std::string &old_name, const std::map<std::string, std::string> &params)->std::string;
    virtual auto toNewFormat(const std::string &new_name, const std::map<std::string, std::string> &params)->std::string;

    auto addPlanCell(const PlanCell &plan)->void;
    auto removeByOldName(const std::string &old_name)->void;
    auto removeByNewName(const std::string &new_name)->void;
    auto removeAll()->void;
    auto getByOldName(const std::string &old_name) const->const PlanCell&;
    auto getByNewName(const std::string &new_name) const->const PlanCell&;
    auto getAll() const->std::vector<PlanCell>;
    auto hasByOldName(const std::string &old_name) const->bool;
    auto hasByNewName(const std::string &new_name) const->bool;

    static auto instanceInCs()->PgmTranslator&;

private:
    auto splitOld(const std::string &old_plan) const->std::pair<std::string, std::map<std::string, std::string>>;
    auto splitNew(const std::string &new_plan) const->std::pair<std::string, std::vector<std::string>>;

private:
    struct Imp;
    aris::core::ImpPtr<Imp> imp_;

public:
    PgmTranslator();
    virtual ~PgmTranslator();

    ARIS_DELETE_BIG_FOUR(PgmTranslator)
};

} // namespace kaanh::program

#endif // KAANH_PROGRAM_PGM_TRANSLATOR_HPP_