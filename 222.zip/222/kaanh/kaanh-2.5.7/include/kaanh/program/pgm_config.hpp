#ifndef KAANH_PROGRAM_PGM_CONFIG_HPP_
#define KAANH_PROGRAM_PGM_CONFIG_HPP_

#include <string>
#include <vector>
#include <map>
#include "kaanh/general/macro.hpp"
#include "kaanh/general/json.hpp"

namespace kaanh::program {

//! 变量配置胞元
struct VarCell {
    std::string name_;          //!< 变量名称
    std::string simple_desc_;   //!< 简要描述--UI使用
    std::string desc_;          //!< 描述--UI使用
    std::string type_;          //!< 变量类型
    std::string unit_;          //!< 单位
    std::string default_val_;   //!< 变量默认值，接受表达式，如字符串为空，则采用type_的默认值
    std::string min_val_;       //!< 变量最小值，接受表达式，如字符串为空，则不做限制(仅适用于数值类型)--UI使用
    std::string max_val_;       //!< 变量最大值，接受表达式，如字符串为空，则不做限制(仅适用于数值类型)--UI使用
    std::string val_set_;       //!< 变量可选值的集合，如字符串为空，则不做限制(仅针对基础类型，格式'{v1,v2}'. 此项指定时，忽略最小/大值限制, 仅适用于数值类型和字符串类型, 不接受表达式输入)--UI使用
    bool editable_{true};       //!< 是否可以编辑--UI使用
};

//! 函数配置胞元
struct FuncCell {
    std::string name_;                      //!< 函数名称
    std::string simple_desc_;               //!< 简要描述--UI使用
    std::string desc_;                      //!< 函数描述
    std::vector<VarCell> params_;           //!< 参数列表，其中default仅对基础类型有效， 忽略editable属性
    std::string ret_type_;                  //!< 返回值类型，如为"NULL"或字符串为空，则为无返回值
    std::string ret_desc_;                  //!< 返回值描述
    std::string menu_;                      //!< 全局函数所属菜单(如字符串为空，则函数不可见;如为多级菜单，则用‘;’隔开，如"lvl1;lvl2")--UI使用， 仅针对全局函数有效
};

/**
 * @brief: 类配置胞元
 * @warning 成员函数配置仅供前端使用，后端仅做校验(类成员函数注册仍需采用hard-code)
 */
struct ClassCell {
    std::string name_;              //!< 类名称
    std::string simple_desc_;       //!< 简要描述--UI使用
    std::string desc_;              //!< 类描述
    std::vector<VarCell> vars_;     //!< 成员变量
    std::vector<FuncCell> funcs_;   //!< 成员函数
    std::string prefix_;            //!< 变量名称默认前缀，如为空，则采用类名称
    bool visible{false};          //!< 可见类
};

//! plan参数配置胞元
struct ParamCell {
    std::string old_name_;      //!< 参数原始名称
    std::string new_name_;      //!< 参数翻译后的名称，如为空，则默认为old_name_
    std::string simple_desc_;   //!< 参数简要描述--UI使用
    std::string desc_;          //!< 参数描述
    std::string type_;          //!< 参数类型
    std::string unit_;          //!< 单位
    std::string default_val_;   //!< 参数默认值，接受表达式，如字符串为空，则采用type_的默认值（暂仅支持基础类型）
    std::string min_val_;       //!< 变量最小值，接受表达式，如字符串为空，则不做限制(仅适用于数值类型)--UI使用
    std::string max_val_;       //!< 变量最大值，接受表达式，如字符串为空，则不做限制(仅适用于数值类型)--UI使用
    std::string val_set_;       //!< 变量可选值的集合，如字符串为空，则不做限制(仅针对基础类型，格式'{v1,v2}'. 此项指定时，忽略最小/大值限制, 仅适用于数值类型和字符串类型, 不接受表达式输入)--UI使用
    bool visiable_{true};       //!< 参数可见性--UI使用
};

//!< plan配置胞元
struct PlanCell {
    std::string old_name_;          //!< plan原始名称
    std::string new_name_;          //!< plan翻译后的名称，如为空，则默认为old_name_
    std::string simple_desc_;       //!< plan简要描述--UI使用
    std::string desc_;              //!< plan描述--UI使用
    std::string menu_;              //!< plan所属菜单(如字符串为空，则plan不可见;如为多级菜单，则用‘;’隔开，如"lvl1;lvl2")--UI使用
    bool interrupt_{true};          //!< plan打断属性
    bool backward_{false};          //!< plan后退属性
    std::vector<ParamCell> params_; //!< plan参数列表
};

//! 程序模块配置
class PgmConfig {
public:
    auto classes()->std::vector<ClassCell>& { return classes_; }
    auto classes() const->const std::vector<ClassCell>& { return const_cast<PgmConfig*>(this)->classes(); }
    auto resetClasses(const std::vector<ClassCell> &classes)->void { classes_ = classes; }
    auto funcs()->std::vector<FuncCell>& { return funcs_; }
    auto funcs() const->const std::vector<FuncCell>& { return const_cast<PgmConfig*>(this)->funcs(); }
    auto resetFuncs(const std::vector<FuncCell> &funcs)->void { funcs_ = funcs; }
    auto plans()->std::vector<PlanCell>& { return plans_; }
    auto plans() const->const std::vector<PlanCell>& { return const_cast<PgmConfig*>(this)->plans(); }
    auto resetPlans(const std::vector<PlanCell> &plans)->void { plans_ = plans; }

    static auto instanceInCs()->PgmConfig&;

private:
    std::vector<ClassCell> classes_;//!< 注册的类类型列表
    std::vector<FuncCell> funcs_;   //!< 注册的全局函数列表
    std::vector<PlanCell> plans_;   //!< 注册的plan列表(前端编程可使用的列表)
};

KAANH_API void to_json(nlohmann::json& j, const VarCell& cell);
KAANH_API void to_json(nlohmann::json& j, const FuncCell& cell);
KAANH_API void to_json(nlohmann::json& j, const ClassCell& cell);
KAANH_API void to_json(nlohmann::json& j, const ParamCell& cell);
KAANH_API void to_json(nlohmann::json& j, const PlanCell& cell);

} // namespace kaanh::program

#endif // KAANH_PROGRAM_PGM_CONFIG_HPP_