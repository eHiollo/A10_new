#ifndef KAANH_PROMGRAM_PGM_CALCULATOR_HPP_
#define KAANH_PROMGRAM_PGM_CALCULATOR_HPP_

#include <string>
#include <vector>
#include <deque>
#include <stack>
#include <map>
#include <set>
#include <any>
#include <memory>
#include <tuple>
#include <functional>
#include <variant>
#include "kaanh/general/macro.hpp"
#include "kaanh_lib_export.h"
#define CALCULATOR_THROW(error) throw std::runtime_error(std::string(__FILE__) + "_" + std::to_string(__LINE__)+ ":" + std::string(error))

namespace kaanh::program {

template<typename T> 
class ImpPtr
{
public:
    auto reset(T* p)->void { data_unique_ptr_.reset(p); }
    auto get()const->const T* { return data_unique_ptr_.get(); }
    auto get()->T* { return data_unique_ptr_.get(); }
    auto operator->()const->const T* { return data_unique_ptr_.get(); }
    auto operator->()->T* { return data_unique_ptr_.get(); }
    auto operator*()const->const T& { return *data_unique_ptr_; }
    auto operator*()->T& { return *data_unique_ptr_; }

    ~ImpPtr() = default;
    explicit ImpPtr(T *data_ptr) :data_unique_ptr_(data_ptr) {}
    explicit ImpPtr() :data_unique_ptr_(new T) {}
    ImpPtr(const ImpPtr &other) :data_unique_ptr_(new T(*other.data_unique_ptr_)) {}
    ImpPtr(ImpPtr &&other)noexcept = default;
    ImpPtr& operator=(const ImpPtr &other) { *data_unique_ptr_ = *other.data_unique_ptr_; return *this; }
    ImpPtr& operator=(ImpPtr &&other)noexcept = default;

private:
    std::unique_ptr<T> data_unique_ptr_;
};

using OperatorName = std::string;
using TypeName = std::string;
using ParaTypeName = std::string;
using RetTypeName = std::string;
using MemberName = std::string;
using FuncName = std::string;
using VarName = std::string;
using SpaceName = std::string;

enum class BasicTypeId : int {
    kNull = -1,
    kStart = 0,
    kBoolean,
    kInt8,
    kUint8,
    kInt16,
    kUint16,
    kInt32,
    kUint32,
    kInt64,
    kUint64,
    kFloat,
    kDouble,
    kString,
    // reserved
    kEnd = 31
};

class UType;

class KAANH_API Type {
public:
    auto utype() const->const std::shared_ptr<const UType>&;
    auto isArray() const->bool;
    auto dim() const->unsigned;
    auto dims() const->const std::deque<unsigned>&;
    auto size() const->unsigned;
    auto itemType() const->Type;
    auto name() const->std::string;
    auto canCastFrom(const Type &t) const->bool;
    auto canCastTo(const Type &t) const->bool;
    auto canPromoteFrom(const Type &t) const->bool;
    auto canPromoteTo(const Type &t) const->bool;
    auto operator==(const Type &t) const->bool;
    operator bool() const;

public:
    Type();
    explicit Type(const TypeName &ut_name, std::deque<unsigned> dims = {});
    explicit Type(int ut_id, std::deque<unsigned> dims = {});
    explicit Type(const std::shared_ptr<const UType> &ut_ptr, std::deque<unsigned> dims = {});
    virtual ~Type();
    Type(const Type &);
    Type& operator=(const Type &);
    Type& operator=(const std::shared_ptr<const UType> &ut_ptr);
    Type(Type&&);
    Type& operator=(Type&&);

private:
    struct Imp;
    ImpPtr<Imp> imp_;

    friend class RValue;
    friend class LValue;
};

class KAANH_API Value {
public:
    auto type() const->const Type&;
    auto utype() const->const std::shared_ptr<const UType>;

    operator bool() const;
    auto isNull() const->bool;
    auto typeEqualTo(const Type &t) const->bool;
    auto typeEqualTo(const Value &v) const->bool;
    auto isArray() const->bool;
    auto size() const->unsigned;
    
    // basic type access
#ifdef UNIX
    template <typename T = int32_t>
    auto num() const->std::decay_t<T>;
#endif // UNIX

#ifdef WIN32
    template <typename T = int32_t>
    auto num() const->std::decay_t<T> {
        if (isNull() || isArray() || !utype()->isNumeric())
            LOCALE_THROW("illegal numeric value access", "非法的数值访问");

#define CALHELPER(T) \
switch (utype()->id()) { \
case (int)BasicTypeId::kBoolean : \
   return static_cast<T>(std::any_cast<bool>(getAnyRef())); break; \
case (int)BasicTypeId::kInt8 : \
   return static_cast<T>(std::any_cast<int8_t>(getAnyRef())); break; \
case (int)BasicTypeId::kUint8 : \
   return static_cast<T>(std::any_cast<uint8_t>(getAnyRef())); break; \
case (int)BasicTypeId::kInt16 : \
   return static_cast<T>(std::any_cast<int16_t>(getAnyRef())); break; \
case (int)BasicTypeId::kUint16 : \
   return static_cast<T>(std::any_cast<uint16_t>(getAnyRef())); break; \
case (int)BasicTypeId::kInt32 : \
   return static_cast<T>(std::any_cast<int32_t>(getAnyRef())); break; \
case (int)BasicTypeId::kUint32 : \
   return static_cast<T>(std::any_cast<uint32_t>(getAnyRef())); break; \
case (int)BasicTypeId::kInt64 : \
   return static_cast<T>(std::any_cast<int64_t>(getAnyRef())); break; \
case (int)BasicTypeId::kUint64 : \
   return static_cast<T>(std::any_cast<uint64_t>(getAnyRef())); break; \
case (int)BasicTypeId::kFloat : \
   return static_cast<T>(std::any_cast<float>(getAnyRef())); break; \
case (int)BasicTypeId::kDouble : \
   return static_cast<T>(std::any_cast<double>(getAnyRef())); break; \
default : \
   CALCULATOR_THROW("Basic numeric type required."); \
}

#define TYPEIS(TT) std::is_same<std::decay_t<T>, TT>::value

        if (TYPEIS(bool)) {
            CALHELPER(bool)
        }
        else if (TYPEIS(uint8_t)) {
            CALHELPER(uint8_t)
        }
        else if (TYPEIS(int8_t)) {
            CALHELPER(int8_t)
        }
        else if (TYPEIS(uint16_t)) {
            CALHELPER(uint16_t)
        }
        else if (TYPEIS(int16_t)) {
            CALHELPER(int16_t)
        }
        else if (TYPEIS(uint32_t)) {
            CALHELPER(uint32_t)
        }
        else if (TYPEIS(int32_t)) {
            CALHELPER(int32_t)
        }
        else if (TYPEIS(uint64_t)) {
            CALHELPER(uint64_t)
        }
        else if (TYPEIS(int64_t)) {
            CALHELPER(int64_t)
        }
        else if (TYPEIS(float)) {
            CALHELPER(float)
        }
        else if (TYPEIS(double)) {
            CALHELPER(double)
        }
        else {
            CALCULATOR_THROW("Unknown basic type '" + std::string(typeid(std::decay_t<T>).name()) + "'.");
        }

#undef TYPEIS
#undef CALHELPER
    }
#endif // WIN32

    auto str() const->std::string;
    

protected:
    auto getAnyRef()->std::any&;
    auto getAnyRef() const->const std::any& { return const_cast<std::decay_t<decltype(*this)> *>(this)->getAnyRef(); }

protected:
    Type type_;
    std::any val_;

protected:
    Value() = default;
    Value(const Value &obj) = delete;
    Value& operator=(const Value &obj) = delete;
    Value(Value &&obj) = delete;
    Value& operator=(Value &&obj) = delete;

public:
    virtual ~Value() = default;
};
class KAANH_API RValue : public Value {
public:
    // basic type access
    template <typename T>
    auto getRef() const->const std::decay_t<T>& { return std::any_cast<const std::decay_t<T>&>(getAnyRef()); }

    // array access
    auto operator[](int ary_id) const->const RValue&;
    auto at(int ary_id) const->const RValue&;

    // class access
    auto operator[](const char *name) const->const RValue&;
    auto operator[](const MemberName &name) const->const RValue&;
    auto at(const char *name) const->const RValue&;
    auto at(const MemberName &name) const->const RValue&; 

    auto castTo(const Type &t) const->RValue;

    auto toSimpleStr() const->std::string;

    auto toStr() const->std::string;

#ifdef UNIX
    template <typename T>
    static auto brv(const std::decay_t<T>& val)->RValue;
#endif // UNIX

#ifdef WIN32
    template <typename T>
    static auto brv(const std::decay_t<T>& val)->RValue {
#define TYPEIS(TT) std::is_same<std::decay_t<T>, TT>::value
#define CALHELPER(ID) ret.type_ = Type(UType::get((int)BasicTypeId::ID));
        RValue ret;
        if (TYPEIS(bool)) {
            CALHELPER(kBoolean)
        }
        else if (TYPEIS(uint8_t)) {
            CALHELPER(kUint8)
        }
        else if (TYPEIS(int8_t)) {
            CALHELPER(kInt8)
        }
        else if (TYPEIS(uint16_t)) {
            CALHELPER(kUint16)
        }
        else if (TYPEIS(int16_t)) {
            CALHELPER(kInt16)
        }
        else if (TYPEIS(uint32_t)) {
            CALHELPER(kUint32)
        }
        else if (TYPEIS(int32_t)) {
            CALHELPER(kInt32)
        }
        else if (TYPEIS(uint64_t)) {
            CALHELPER(kUint64)
        }
        else if (TYPEIS(int64_t)) {
            CALHELPER(kInt64)
        }
        else if (TYPEIS(float)) {
            CALHELPER(kFloat)
        }
        else if (TYPEIS(double)) {
            CALHELPER(kDouble)
        }
        else if (TYPEIS(std::string)) {
            CALHELPER(kString)
        }
        else {
            CALCULATOR_THROW("Basic type required.");
        }

        ret.val_ = val;

#undef CALHELPER
#undef TYPEIS

        return ret;
    }
#endif // WIN32
    static auto rv(const TypeName &name, const std::deque<unsigned> &dims = {})->RValue;
    static auto rv(int ut_id, const std::deque<unsigned> &dims = {})->RValue;
    static auto rv(const std::shared_ptr<const UType> &ut, const std::deque<unsigned> &dims = {})->RValue;
    static auto rv(const Type &t)->RValue;

protected:
    std::vector<RValue> subvals_;

public:
    RValue() = default;
    RValue(bool val);
    RValue(int val);
    RValue(double val);
    RValue(const char *str);
    RValue(const std::string &str);
    explicit RValue(const std::vector<RValue>& items);
    explicit RValue(const TypeName &ut_name, const std::vector<RValue> &members);
    explicit RValue(int ut_id, const std::vector<RValue> &members);
    explicit RValue(const std::shared_ptr<const UType> &ut, const std::vector<RValue> &members);
    virtual ~RValue() = default;
    RValue(const RValue &obj);
    RValue& operator=(const RValue &) = delete;
    RValue(RValue &&obj);
    RValue& operator=(RValue &&) = delete;

    friend class LValue;
};

class KAANH_API LValue : public Value {
public:
    // basic type access
    template <typename T>
    auto getRef()->std::decay_t<T>& { return std::any_cast<std::decay_t<T>&>(getAnyRef()); }

    template <typename T>
    auto getRef() const->const std::decay_t<T>& { return const_cast<std::decay_t<decltype(*this)> *>(this)->getRef<T>(); }

    // array access
    auto operator[](int ary_id)->LValue& { return at(ary_id); }
    auto operator[](int ary_id) const->const LValue& { return const_cast<std::decay_t<decltype(*this)> *>(this)->at(ary_id); }
    auto at(int ary_id)->LValue&;
    auto at(int ary_id) const->const LValue& { return const_cast<std::decay_t<decltype(*this)> *>(this)->at(ary_id); }

    // class access
    auto operator[](const char *name)->LValue& { return at(std::string(name)); }
    auto operator[](const char *name) const->const LValue& { return const_cast<std::decay_t<decltype(*this)> *>(this)->at(std::string(name)); }
    auto operator[](const MemberName &name)->LValue& { return at(name); }
    auto operator[](const MemberName &name) const->const LValue& { return const_cast<std::decay_t<decltype(*this)> *>(this)->at(name); }
    auto at(const char *name)->LValue& { return at(std::string(name)); }
    auto at(const char *name) const->const LValue& { return const_cast<std::decay_t<decltype(*this)> *>(this)->at(std::string(name)); }
    auto at(const MemberName &name)->LValue&;
    auto at(const MemberName &name) const->const LValue& { return const_cast<std::decay_t<decltype(*this)> *>(this)->at(name); }
    auto call(const FuncName &name, const std::vector<RValue> &paras)->RValue;

    auto context()->std::any& { return std::any_cast<std::any*>(&context_)? *std::any_cast<std::any*>(context_) : context_; }
    auto context() const->const std::any& { return const_cast<std::decay_t<decltype(*this)> *>(this)->context(); }

    operator RValue() const;

    auto toSimpleStr() const->std::string;
    
    auto toStr() const->std::string;

private:
    std::vector<LValue> subvals_;
    std::any context_;

protected:
    LValue(const RValue &obj);
    
public:
    LValue(const LValue &obj);
    virtual ~LValue();
    LValue& operator=(const LValue&) = delete;
    LValue& operator=(const RValue &obj);
    LValue(LValue &&obj);
    LValue& operator=(LValue &&obj) = delete;
};

using FuncT = std::function<RValue(const std::vector<RValue>&)>;
using MemberFuncT = std::function<RValue(LValue&, const std::vector<RValue>&)>;
using UnaryOprFuncT = std::function<RValue(const RValue&)>;
using BinaryOprFuncT = std::function<RValue(const RValue&, const RValue&)>;
using Constructor = std::function<void(LValue&)>;
using Destructor = std::function<void(LValue&)>;

class MemberFunction {
public:
    auto name() const->const FuncName&;
    auto classType() const->const std::shared_ptr<const UType>&;
    auto addOverloadFunc(const std::vector<Type> &paras, const Type &ret, MemberFuncT func)->MemberFunction&;
    auto hasFunc(const std::vector<Type> &paras) const->bool;
    auto get() const->MemberFuncT;
    auto get(const std::vector<Type> &paras) const->MemberFuncT;
    auto canCall(const std::vector<Type> &paras) const->bool;
    auto canCall(const std::vector<RValue> &paras) const->bool;
    auto getMatched(const std::vector<Type> &paras) const->std::tuple<std::vector<Type>, Type, MemberFuncT>;
    auto operator()(LValue &obj, const std::vector<RValue> &paras) const->RValue;
    auto call(LValue &obj, const std::vector<RValue> &paras) const->RValue;

private:
    struct Imp;
    ImpPtr<Imp> imp_;

public:
    KAANH_API explicit MemberFunction(const std::shared_ptr<const UType> &type, const FuncName &name);
    KAANH_API explicit MemberFunction(const std::shared_ptr<const UType> &type, const FuncName &name, const std::vector<Type> &paras, const Type &ret, MemberFuncT func);
    KAANH_API explicit MemberFunction(const std::shared_ptr<const UType> &type, const FuncName &name, const std::vector<std::tuple<std::vector<Type>, Type, MemberFuncT>> &funcs);
    KAANH_API ~MemberFunction();
    MemberFunction(const MemberFunction&) = default;
    MemberFunction& operator=(const MemberFunction&) = default;
    MemberFunction(MemberFunction&&) = default;
    MemberFunction& operator=(MemberFunction&&) = default;
};

class UnaryOprFunction {
public:
    auto opr() const->const OperatorName&;
    auto classType() const->const std::shared_ptr<const UType>&;
    auto get() const->UnaryOprFuncT;
    auto getRetType() const->const Type&;
    auto operator()(const RValue &obj) const->RValue;
    auto call(const RValue &obj) const->RValue;

    static auto isSupported(const OperatorName &opr)->bool;
    static auto isSupported(int id)->bool;
    static auto getOprId(const OperatorName &opr)->int;
    static auto getOprName(int id)->const OperatorName&;

private:
    struct Imp;
    ImpPtr<Imp> imp_;

public:
    KAANH_API explicit UnaryOprFunction(const std::shared_ptr<const UType> &type, OperatorName &opr, const Type &ret, UnaryOprFuncT func);
    KAANH_API ~UnaryOprFunction();
    UnaryOprFunction(const UnaryOprFunction&) = default;
    UnaryOprFunction& operator=(const UnaryOprFunction&) = default;
    UnaryOprFunction(UnaryOprFunction&&) = default;
    UnaryOprFunction& operator=(UnaryOprFunction&&) = default;
};

class BinaryOprFunction {
public:
    auto opr() const->const OperatorName&;
    auto classType() const->const std::shared_ptr<const UType>&;
    auto addOverloadFunc(const Type &para, const Type &ret, BinaryOprFuncT func)->BinaryOprFunction&;
    auto hasFunc(const Type &para) const->bool;
    auto get() const->BinaryOprFuncT;
    auto get(const Type &para) const->BinaryOprFuncT;
    auto canCall(const Type &para) const->bool;
    auto canCall(const RValue &para) const->bool;
    auto getMatched(const Type &para) const->std::tuple<Type, Type, BinaryOprFuncT>;
    auto operator()(const RValue &obj, const RValue &para) const->RValue;
    auto call(const RValue &obj, const RValue &para) const->RValue;

    static auto isSupported(const OperatorName &opr)->bool;
    static auto isSupported(int id)->bool;
    static auto getOprId(const OperatorName &opr)->int;
    static auto getOprName(int id)->const OperatorName&;

private:
    struct Imp;
    ImpPtr<Imp> imp_;

public:
    KAANH_API explicit BinaryOprFunction(const std::shared_ptr<const UType> &type, const OperatorName &opr);
    KAANH_API explicit BinaryOprFunction(const std::shared_ptr<const UType> &type, const OperatorName &opr, const Type &para, const Type &ret, BinaryOprFuncT func);
    KAANH_API explicit BinaryOprFunction(const std::shared_ptr<const UType> &type, const OperatorName &opr, const std::vector<std::tuple<Type, Type, BinaryOprFuncT>> &funcs);
    KAANH_API ~BinaryOprFunction();
    BinaryOprFunction(const BinaryOprFunction&) = default;
    BinaryOprFunction& operator=(const BinaryOprFunction&) = default;
    BinaryOprFunction(BinaryOprFunction&&) = default;
    BinaryOprFunction& operator=(BinaryOprFunction&&) = default;
};

class UType {
public:
    auto isNull() const->bool;
    KAANH_API auto isNumeric() const->bool;
    auto isBoolean() const->bool;
    auto isInteger() const->bool;
    auto isFloating() const->bool;
    auto isString() const->bool;
    auto isBasic() const->bool;
    auto isClass() const->bool;
    operator bool() const;
    auto operator==(const UType &t) const->bool;

    auto name() const->const std::string&;
    KAANH_API auto id() const->int;
    KAANH_API auto addMember(const MemberName &name, const RValue &val)->UType&;
    KAANH_API auto hasMember(const MemberName &name) const->bool;
    KAANH_API auto getMemberCount() const->unsigned;
    KAANH_API auto getMemberName(int index) const->const MemberName&;
    KAANH_API auto getMemberIndex(const MemberName &name) const->int;
    KAANH_API auto getMemberType(const MemberName &name) const->const Type&;
    KAANH_API auto getMemberTypeList() const->std::vector<Type>;
    KAANH_API auto getMemberValList() const->const std::vector<RValue>&;
    auto allMembers() const->std::map<std::string, RValue>;
    KAANH_API auto addMemberFunc(const MemberFunction &mfunc)->UType&;
    auto hasMemberFunc(const FuncName &name) const->bool;
    auto getMemberFunc(const FuncName &name)->MemberFunction&;
    auto getMemberFunc(const FuncName &name) const->const MemberFunction& { return const_cast<std::decay_t<decltype(*this)> *>(this)->getMemberFunc(name); }
    auto allMemberFuncs() const->const std::map<FuncName, MemberFunction>;
    KAANH_API auto addUnaryOprFunc(const UnaryOprFunction &ufunc)->UType&;
    auto hasUnaryOprFunc(const OperatorName &opr) const->bool;
    auto getUnaryOprFunc(const OperatorName &opr)->UnaryOprFunction&;
    auto getUnaryOprFunc(const OperatorName &opr) const->const UnaryOprFunction& { return const_cast<std::decay_t<decltype(*this)> *>(this)->getUnaryOprFunc(opr); }
    KAANH_API auto addBinaryOprFunc(const BinaryOprFunction &bfunc)->UType&;
    auto hasBinaryOprFunc(const OperatorName &opr) const->bool;
    auto getBinaryOprFunc(const OperatorName &opr)->BinaryOprFunction&;
    auto getBinaryOprFunc(const OperatorName &opr) const->const BinaryOprFunction& { return const_cast<std::decay_t<decltype(*this)> *>(this)->getBinaryOprFunc(opr); }
    KAANH_API auto addConstructor(const Constructor &cs)->UType&;
    auto getConstructor()->Constructor&;
    auto getConstructor() const->const Constructor& { return const_cast<std::decay_t<decltype(*this)> *>(this)->getConstructor(); }
    KAANH_API auto addDestructor(const Destructor &ds)->UType&;
    auto getDestructor()->Destructor&;
    auto getDestructor() const->const Destructor& { return const_cast<std::decay_t<decltype(*this)> *>(this)->getDestructor(); }

public:
    KAANH_API static auto registerType(const TypeName &name,
                             std::vector<std::pair<MemberName, RValue>> members = {},
                             std::vector<MemberFunction> mfuncs= {},
                             std::vector<UnaryOprFunction> ufuncs = {},
                             std::vector<BinaryOprFunction> bfuncs = {}
                             )->UType&;
    KAANH_API static auto has(const TypeName &name)->bool;
    KAANH_API static auto has(int id)->bool;
    KAANH_API static auto get(int id)->std::shared_ptr<const UType>;
    KAANH_API static auto get(const TypeName &name)->std::shared_ptr<const UType>;
    KAANH_API static auto getId(const TypeName &name)->int;
    KAANH_API static auto getName(int id)->const std::string&;
    KAANH_API static auto canPromote(const std::shared_ptr<const UType> &pro_to, const std::shared_ptr<const UType> &pro_from)->bool;
    KAANH_API static auto promote(std::shared_ptr<const UType> &pro_to, const std::shared_ptr<const UType> &pro_from)->void;
    KAANH_API static auto canCast(const std::shared_ptr<const UType> &cast_to, const std::shared_ptr<const UType> &cast_from)->bool;
    KAANH_API static auto allTypes()->std::map<int, std::shared_ptr<const UType>>;
    
private:
    struct Imp;
    ImpPtr<Imp> imp_;

private:
    KAANH_API explicit UType(const std::string &name, int id);

public:
    KAANH_API virtual ~UType();
};

class NameSpace;
class KAANH_API Var : public LValue{
public:
    auto name() const->const VarName& { return name_; }

private:
    auto rename(const std::string &new_name)->void { name_ = new_name; }
    
protected:
    std::string name_;

public:
    // variable definition using specific value
    explicit Var(const VarName &name, const RValue &val);
    // variable definition using default value
    explicit Var(const VarName &name, const Type &t);
    virtual ~Var() = default;

    Var(const Var&) = delete;
    Var& operator=(const RValue &obj);
    Var& operator=(const Var &obj);
    Var(Var &&) = delete;
    Var& operator=(Var &&) = delete;

    friend class NameSpace;
};

class Function {
public:
    auto name() const->const FuncName&;
    auto addOverloadFunc(const std::vector<Type> &paras, const Type &ret, FuncT func)->Function&;
    auto hasFunc(const std::vector<Type> &paras) const->bool;
    auto get() const->FuncT;
    auto get(const std::vector<Type> &paras) const->FuncT;
    auto canCall(const std::vector<Type> &paras) const->bool;
    auto canCall(const std::vector<RValue> &paras) const->bool;
    auto getMatched(const std::vector<Type> &paras) const->std::tuple<std::vector<Type>, Type, FuncT>;
    auto operator()(const std::vector<RValue> &paras) const->RValue;
    auto call(const std::vector<RValue> &paras) const->RValue;

    KAANH_API static auto registerFunc(const FuncName &name, const std::vector<Type> &paras, const Type &ret, FuncT func)->Function&;
    KAANH_API static auto registerFunc(const FuncName &name, const std::vector<std::tuple<std::vector<Type>, Type, FuncT>> &funcs)->Function&;
    KAANH_API static auto has(const FuncName &name)->bool;
    KAANH_API static auto get(const FuncName &name)->std::shared_ptr<const Function>;

private:
    struct Imp;
    ImpPtr<Imp> imp_;

private:
    KAANH_API explicit Function(const FuncName &name);
    KAANH_API explicit Function(const FuncName &name, const std::vector<Type> &paras, const Type &ret, FuncT func);
    KAANH_API explicit Function(const FuncName &name, const std::vector<std::tuple<std::vector<Type>, Type, FuncT>> &funcs);
    
public:
    KAANH_API ~Function();
    Function(const Function&) = default;
    Function& operator=(const Function&) = default;
    Function(Function&&) = default;
    Function& operator=(Function&&) = default;
};

class KAANH_API NameSpace {
public:
    auto name() const noexcept->const SpaceName&;
    auto rename(const SpaceName &name) noexcept->void;
    auto addVar(const std::shared_ptr<Var> &var)->NameSpace&;
    auto addVar(const VarName &name, const RValue &val)->NameSpace&;
    auto addVar(const VarName &name, const Type &t)->NameSpace&;
    auto hasVar(const VarName &name) const noexcept->bool;
    auto getVar(const VarName &name) const->Var&;
    auto allVars() const noexcept->std::map<VarName, std::shared_ptr<Var>>;
    auto removeVar(const VarName &name) noexcept->void;
    auto renameVar(const VarName &old_name, const VarName &new_name)->void;
    auto removeAllVars() noexcept->void;

private:
    struct Imp;
    ImpPtr<Imp> imp_;

public:
    explicit NameSpace(const SpaceName &name, const std::vector<std::shared_ptr<Var>> &vars = {});
    virtual ~NameSpace();
    NameSpace(const NameSpace&) = delete;
    NameSpace& operator=(const NameSpace&) = delete;
    NameSpace(NameSpace&&) = delete;
    NameSpace& operator=(NameSpace&&) = delete;
};

class KAANH_API SpaceStack {
public:
    auto push(const std::shared_ptr<const NameSpace> &space)->SpaceStack&;
    auto has(const SpaceName &name) const noexcept->bool;
    auto get(const SpaceName &name) const->const NameSpace&;
    auto top() const->const NameSpace&;
    auto pop()->void;
    auto clear() noexcept->void;
    auto empty() const noexcept->bool;
    auto hasVar(const VarName &name) const noexcept->bool;
    auto getVar(const VarName &name) const->std::pair<SpaceName, Var&>;

private:
    std::vector<std::shared_ptr<const NameSpace>> ss_;
    
public:
    SpaceStack() = default;
    virtual ~SpaceStack() = default;
    SpaceStack(const SpaceStack&) = delete;
    SpaceStack& operator=(const SpaceStack&) = delete;
    SpaceStack(SpaceStack&&) = delete;
    SpaceStack& operator=(SpaceStack&&) = delete;
};

class PgmCalculator {
public:
    /**
     * @brief: 计算表达式
     * @param {const std::string&} expr 表达式
     * @return {RValue} 表达式的值
     */
    KAANH_API auto eval(const std::string &expr) const->RValue;

    /**
     * @brief: 计算表达式, 并捕捉可能会改变的变量
     * @param {const std::string&} expr 表达式
     * @return pair.first: 表达式的值
     * <BR>pair.second: 可能被更改的变量的名称(作用域名称:变量名称)
     */
    auto evalAndCapture(const std::string &expr) const->std::pair<RValue, std::set<std::string>>;

    /**
     * @brief: 解析变量定义, 返回变量
     * @param {const std::string&} str 变量定义
     * @return {std::shared_ptr<Var>} Var对象
     * @remark 1. 返回值永远有效, 如解析失败则抛异常
     * <BR>2. 作用域栈仅用来计算变量的初始值
     */  
    auto select(const std::string &var_def) const->std::shared_ptr<Var>;

    /**
     * @brief: 检查字符串的合法性
     * @param {const std::string&} str 字符串: 变量定义或表达式
     * @return 如执行该字符串返回的类型
     * @remark 检查不会产生任何副作用, 即:
     * <BR>1. 如字符串为变量定义, 不会在作用域栈的栈顶添加变量
     * <BR>2. 如字符串为表达式, 不会执行真正的赋值或函数调用
     * <BR>3. 如字符串为变量定义, 则返回值为变量的类型
     * <BR>4. 如字符串为表达式, 则返回值为表达式值的类型
     * <BR>5. 如检查失败, 则抛异常
     */
    auto check(const std::string &str) const->Type;

    /**
     * @brief: 绑定作用域栈
     * @param {const std::shared_ptr<const SpaceStack>&} ss 作用域栈
     * @remark 绑定后非静态成员函数均会使用此栈
     */    
    auto bindSpaceStack(const std::shared_ptr<const SpaceStack> &ss)->void;

    /**
     * @brief: 解绑作用域栈
     */    
    auto UnbindSpaceStack() noexcept->void;

    /**
     * @brief: 判断字符串是否为变量定义
     * @param {const std::string&} str 字符串
     * @remark 1. 仅从语法上判断字符串是否为变量定义(包括默认初始化、列表初始化和拷贝初始化)
     * <BR>2. 如字符串非法或者字符串为表达式, 均返回false
     */
    static auto isVarDef(const std::string &str) noexcept->bool;

    /**
     * @brief: 判断字符串是否为表达式
     * @param {const std::string&} str 字符串
     * @remark 1. 仅从语法上判断字符串是否为表达式
     * <BR>2. 如字符串非法或者字符串为变量定义, 均返回false
     */
    static auto isExpr(const std::string &str) noexcept->bool;

    /**
     * @brief: 计算表达式
     * @note: eval的静态版本, 区别是seval使用外部指定的栈
     * @param {const std::string&} expr 表达式
     * @param {const std::shared_ptr<const SpaceStack>} ss 作用域栈, 默认为空
     * @return {RValue} 表达式的值
     */
    static auto seval(const std::string &expr, const std::shared_ptr<const SpaceStack> &ss = nullptr)->RValue;

    /**
     * @brief: 计算表达式, 并捕捉可能会改变的变量
     * @note: evalAndCapture的静态版本, 区别是sevalAndCapture使用外部指定的栈
     * @param {const std::string&} expr 表达式
     * @param {const std::shared_ptr<const SpaceStack>} ss 作用域栈, 默认为空
     * @return pair.first: 表达式的值
     * <BR>pair.second: 可能被更改的变量的名称(作用域名称:变量名称)
     */
    static auto sevalAndCapture(const std::string &expr, const std::shared_ptr<const SpaceStack> &ss= nullptr)->std::pair<RValue, std::set<std::string>>;

    /**
     * @brief: 解析变量定义, 返回变量
     * @note: select的静态版本, 区别是sselect使用外部指定的栈
     * @param {const std::string&} var_def 变量定义
     * @param {const std::shared_ptr<const SpaceStack>&} ss 作用域栈, 默认为空
     * @return {std::shared_ptr<Var>} Var对象
     * @remark 1. 返回值永远有效, 如解析失败则抛异常
     * <BR>2. 作用域栈仅用来计算变量的初始值
     */  
    static auto sselect(const std::string &var_def, const std::shared_ptr<const SpaceStack> &ss=nullptr)->std::shared_ptr<Var>;
    
    /**
     * @brief: 检查字符串的合法性
     * @note: check的静态版本, 区别是scheck使用外部指定的栈
     * @param {const std::string&} str 字符串: 变量定义或表达式
     * @param {const std::shared_ptr<const SpaceStack>} ss 作用域栈, 默认为空
     * @return 如执行该字符串返回的类型
     * @remark 检查不会产生任何副作用, 即:
     * <BR>1. 如字符串为变量定义, 不会在作用域栈的栈顶添加变量
     * <BR>2. 如字符串为表达式, 不会执行真正的赋值或函数调用
     * <BR>3. 如字符串为变量定义, 则返回值为变量的类型
     * <BR>4. 如字符串为表达式, 则返回值为表达式值的类型
     * <BR>5. 如检查失败, 则抛异常
     */
    static auto scheck(const std::string &str, const std::shared_ptr<const SpaceStack> &ss = nullptr)->Type;

    /**
     * @brief: 获取浮点型比较运算时的精度
     * @note: select的静态版本, 区别是sselect使用外部指定的栈
     * @return {int} 小数点后几位
     * @remark 默认小数点后3位精度
     */  
    static auto getPrecision()->int;

    /**
     * @brief: 设置浮点型比较运算时的精度
     * @param {int} precision 小数点后几位, 默认为3, 最小为1
     * @remark 如设置不合理, 则什么都不做
     */ 
    static auto setPrecision(int precision=3)->void;
    
    KAANH_API static auto instanceInCs()->PgmCalculator&;

private:
    struct Imp;
    mutable ImpPtr<Imp> imp_;

public:
    KAANH_API PgmCalculator();
    KAANH_API virtual ~PgmCalculator();
};

} // namespace kaanh::program

#endif // KAANH_PROMGRAM_PGM_CALCULATOR_HPP_