
#ifndef KAANH_API_H
#define KAANH_API_H

#ifdef KAANH_LIB_STATIC_DEFINE
#  define KAANH_API
#  define KAANH_LIB_NO_EXPORT
#else
#  ifndef KAANH_API
#    ifdef kaanh_lib_EXPORTS
        /* We are building this library */
#      define KAANH_API __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define KAANH_API __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef KAANH_LIB_NO_EXPORT
#    define KAANH_LIB_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef KAANH_LIB_DEPRECATED
#  define KAANH_LIB_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef KAANH_LIB_DEPRECATED_EXPORT
#  define KAANH_LIB_DEPRECATED_EXPORT KAANH_API KAANH_LIB_DEPRECATED
#endif

#ifndef KAANH_LIB_DEPRECATED_NO_EXPORT
#  define KAANH_LIB_DEPRECATED_NO_EXPORT KAANH_LIB_NO_EXPORT KAANH_LIB_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef KAANH_LIB_NO_DEPRECATED
#    define KAANH_LIB_NO_DEPRECATED
#  endif
#endif

#endif /* KAANH_API_H */
