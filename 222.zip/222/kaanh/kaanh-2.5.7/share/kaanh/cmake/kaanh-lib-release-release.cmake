#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "kaanh::release::kaanh_lib" for configuration "Release"
set_property(TARGET kaanh::release::kaanh_lib APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(kaanh::release::kaanh_lib PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/release/libkaanh_lib.so"
  IMPORTED_SONAME_RELEASE "libkaanh_lib.so"
  )

list(APPEND _IMPORT_CHECK_TARGETS kaanh::release::kaanh_lib )
list(APPEND _IMPORT_CHECK_FILES_FOR_kaanh::release::kaanh_lib "${_IMPORT_PREFIX}/lib/release/libkaanh_lib.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
