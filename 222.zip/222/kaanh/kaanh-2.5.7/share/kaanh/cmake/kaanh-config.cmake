
####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was kaanh-config.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../" ABSOLUTE)

macro(set_and_check _var _file)
  set(${_var} "${_file}")
  if(NOT EXISTS "${_file}")
    message(FATAL_ERROR "File or directory ${_file} referenced by variable ${_var} does not exist !")
  endif()
endmacro()

macro(check_required_components _NAME)
  foreach(comp ${${_NAME}_FIND_COMPONENTS})
    if(NOT ${_NAME}_${comp}_FOUND)
      if(${_NAME}_FIND_REQUIRED_${comp})
        set(${_NAME}_FOUND FALSE)
      endif()
    endif()
  endforeach()
endmacro()

#################################################################################### 

include(CMakeFindDependencyMacro)
if(UNIX)
	find_dependency(aris PATHS /usr/aris)
elseif(WIN32)
	find_dependency(aris PATHS C:/aris)
endif()

set(kaanh_INCLUDE_DIRS "/usr/aris/aris-2.5.7/include;/usr/kaanh/kaanh-2.5.7/include")
set(kaanh_LIBRARIES "optimized;kaanh::release::kaanh_lib;debug;kaanh::debug::kaanh_lib;-Wl,--start-group;optimized;aris::aris_lib;debug;aris::debug::aris_lib;ethercat;atomic;pthread;stdc++fs;dl;-Wl,--end-group")

include("${CMAKE_CURRENT_LIST_DIR}/kaanh-lib-debug.cmake")
include("${CMAKE_CURRENT_LIST_DIR}/kaanh-lib-release.cmake")




